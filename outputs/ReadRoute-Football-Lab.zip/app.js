const skillPositions = [
  { id: "X", x: 78, y: 482 },
  { id: "H", x: 255, y: 482 },
  { id: "Y", x: 645, y: 482 },
  { id: "Z", x: 822, y: 482 },
  { id: "RB", x: 520, y: 575 },
];

const offensiveLine = [
  { id: "LT", label: "LT", x: 370, y: 476 },
  { id: "LG", label: "LG", x: 410, y: 476 },
  { id: "C", label: "C", x: 450, y: 476 },
  { id: "RG", label: "RG", x: 490, y: 476 },
  { id: "RT", label: "RT", x: 530, y: 476 },
];

const quarterback = { id: "QB", label: "QB", x: 450, y: 540 };
const routeableOffense = [...skillPositions, quarterback];
const defensePositionLabels = ["DE", "DT", "DT", "DE", "OLB", "MLB", "OLB", "CB", "FS", "SS", "CB"];
const offensePositionColors = {
  X: "#ffcc4d",
  H: "#55c7ff",
  Y: "#b892ff",
  Z: "#ff7b92",
  RB: "#64d96b",
  QB: "#f8f4e8",
  LT: "#f5a24b",
  LG: "#f7b85c",
  C: "#ffd166",
  RG: "#f7b85c",
  RT: "#f5a24b"
};
const defensePositionColors = [
  "#ff6b4a", "#ff8c42", "#f4a62a", "#ff6b4a",
  "#4cc9f0", "#4895ef", "#4cc9f0",
  "#9d4edd", "#5a7dff", "#7b61ff", "#9d4edd"
];
const lineOfScrimmage = 476;
const fieldWidth = 900;
const fieldHeight = 700;
const fieldPadding = 18;
const scrimmageSnapDistance = 16;
const storageKeys = {
  plays: "readroute-drawn-plays",
  formations: "readroute-formations",
  defenses: "readroute-defenses",
  snapshot: "readroute-playbook-snapshot",
  previousSnapshot: "readroute-playbook-snapshot-previous",
  draft: "readroute-play-draft",
  folders: "readroute-custom-folders",
  folderAssignments: "readroute-folder-assignments",
  savedAt: "readroute-last-saved-at",
  trenches: "readroute-trenches"
};

function zoneRadii(zone) {
  const legacyRadius = Number(zone?.radius) || 130;
  return {
    x: Math.max(40, Math.min(300, Number(zone?.radiusX) || legacyRadius)),
    y: Math.max(40, Math.min(300, Number(zone?.radiusY) || legacyRadius))
  };
}

const trenchesFronts = {
  starter: {
    name: "Starter Front",
    defenders: [
      { label: "E", x: 330, y: 210 }, { label: "T", x: 410, y: 215 },
      { label: "N", x: 488, y: 215 }, { label: "E", x: 570, y: 210 },
      { label: "M", x: 430, y: 145 }, { label: "W", x: 520, y: 145 }
    ]
  }
};

function trenchesFrontOptions() {
  return {
    ...trenchesFronts,
    ...((typeof trenchesState !== "undefined" && trenchesState?.customFronts) || {})
  };
}

const fieldStandards = {
  highSchool: {
    label: "High School",
    hashFromSidelineFeet: 160 / 3,
    numberCenterFromSidelineFeet: 24
  },
  college: {
    label: "College",
    hashFromSidelineFeet: 60,
    numberCenterFromSidelineFeet: 24
  },
  nfl: {
    label: "NFL",
    hashFromSidelineFeet: 70.75,
    numberCenterFromSidelineFeet: 39
  }
};

function defaultOffensePositions() {
  return [...skillPositions, ...offensiveLine, quarterback].reduce((positions, player) => {
    positions[player.id] = { x: player.x, y: player.y };
    return positions;
  }, {});
}

function keepOffensiveLineOnScrimmage(positions = {}) {
  offensiveLine.forEach(lineman => {
    const saved = positions[lineman.id] || lineman;
    positions[lineman.id] = {
      x: Number(saved.x) || lineman.x,
      y: lineOfScrimmage
    };
  });
  return positions;
}

function normalizedOffensePositions(saved = {}) {
  return keepOffensiveLineOnScrimmage({
    ...defaultOffensePositions(),
    ...(saved || {})
  });
}

function defaultDefensePositions() {
  return [
    [330, 438], [410, 438], [490, 438], [570, 438],
    [300, 350], [450, 330], [600, 350],
    [100, 250], [335, 170], [565, 170], [800, 250]
  ].reduce((positions, [x, y], index) => {
    positions[`D${index}`] = { x, y };
    return positions;
  }, {});
}

function createNote(text = "", x = 350, y = 250) {
  return { id: crypto.randomUUID(), text, x, y, width: 38, height: 44 };
}

function defaultPlayIntent() {
  return {
    playAction: false,
    rpo: false
  };
}

function normalizePlayIntent(intent = {}) {
  return {
    ...defaultPlayIntent(),
    playAction: Boolean(intent.playAction),
    rpo: Boolean(intent.rpo)
  };
}

function defaultDefenseRealism() {
  return {
    personality: "balanced",
    eyes: "balanced",
    awareness: 70,
    discipline: 70,
    aggression: 55,
    mistakes: 35
  };
}

function defaultDefenderTechnique() {
  return "balanced";
}

function normalizeDefenderTechnique(value) {
  const allowed = ["balanced", "keepDepth", "midpoint", "matchVertical", "jumpFirst", "robInside", "wallCrosser"];
  return allowed.includes(value) ? value : defaultDefenderTechnique();
}

function normalizeDefenderTechniques(techniques = {}) {
  return Object.fromEntries(
    Object.entries(techniques || {}).map(([id, technique]) => [
      id,
      normalizeDefenderTechnique(technique)
    ])
  );
}

function normalizePercent(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.min(100, number)) : fallback;
}

function normalizeDefenseRealism(realism = {}) {
  const defaults = defaultDefenseRealism();
  const personalities = ["balanced", "conservative", "aggressive", "match", "spot", "undisciplined"];
  const eyes = ["balanced", "receiver", "backfield", "landmark", "nearest"];
  return {
    personality: personalities.includes(realism.personality) ? realism.personality : defaults.personality,
    eyes: eyes.includes(realism.eyes) ? realism.eyes : defaults.eyes,
    awareness: normalizePercent(realism.awareness, defaults.awareness),
    discipline: normalizePercent(realism.discipline, defaults.discipline),
    aggression: normalizePercent(realism.aggression, defaults.aggression),
    mistakes: normalizePercent(realism.mistakes, defaults.mistakes)
  };
}

function createBlankPlay(name = "Untitled Play") {
  return {
    id: crypto.randomUUID(),
    name,
    intent: defaultPlayIntent(),
    labels: { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" },
    routes: { X: [], H: [], Y: [], Z: [], RB: [], QB: [] },
    routeOptions: { X: [], H: [], Y: [], Z: [], RB: [] },
    motions: { X: [], H: [], Y: [], Z: [], RB: [], QB: [] },
    offensePositions: defaultOffensePositions(),
    formationId: null,
    notes: []
  };
}

function createBlankDefense(name = "Untitled Defense", labels = {}) {
  return {
    id: crypto.randomUUID(),
    name,
    realism: defaultDefenseRealism(),
    positions: defaultDefensePositions(),
    routes: {},
    manAssignments: {},
    zoneAssignments: {},
    techniques: {},
    formationAlignments: {},
    labels: structuredClone(labels),
    notes: []
  };
}

let plays = loadPlays();
let formations = loadFormations();
let defenses = loadDefenses();
let libraryFolders = loadLibraryFolders();
let libraryAssignments = loadLibraryAssignments();
let recoveredDraft = loadDraftPlay();
let selectedPlayId = plays[0].id;
let draftPlay = recoveredDraft;
let selectedFormationId = recoveredDraft?.formationId || plays[0].formationId || formations[0].id;
let selectedDefenseId = defenses[0].id;
let appTab = "create";
let createScreen = recoveredDraft ? "play" : "formation";
let activeRouteId = "X";
let activeRouteSide = "offense";
let boardMode = "move";
let playPathType = "route";
let selectedRouteOptionId = "base";
let dragState = null;
let suppressFieldClickUntil = 0;
let animationFrame = null;
let animationState = null;
let animationPlayback = null;
let runSpeed = 1;
let runDefenseMovement = true;
let runScenario = null;
let scenarioEditing = false;
let scenarioTool = "move";
let defenseAlignmentMode = false;
let defenseAlignmentFormationId = selectedFormationId;
let testSourceId = "all";
let testPlayIds = new Set(plays.map(play => play.id));
let testDefenseIds = new Set(defenses.map(defense => defense.id));
let testAnswerRevealed = false;
let testRoundReady = false;
let testSessionPlayIds = [];
let testSessionIndex = -1;
let testQbLookPoint = null;
let testThrowState = null;
let testThrowFrame = null;
let testPlayResult = null;
let defenseAssignmentMode = "path";
let libraryPreview = { type: "play", id: selectedPlayId };
let libraryPreviewContext = null;
let playbookTab = "all";
let playbookSearchQuery = "";
let printPlaybookOpen = false;
let activeFolderPickerId = null;
let activeFolderPickerSearch = "";
let trenchesState = loadTrenchesState();
let trenchesDrag = null;
let trenchesAnimation = null;
let trenchesAnimationFrame = null;
const libraryFolderOpenState = new Map();
const folderPickerOpenState = new Map();
const runFolderOpenState = new Map();
let libraryDragState = null;
let saveToastTimer = null;
let autosaveTimer = null;
let lastSavedSignature = "";
let cloudAccessRole = "owner";
let fieldStandard = localStorage.getItem("readroute-field-standard") || "highSchool";
if (!fieldStandards[fieldStandard]) fieldStandard = "highSchool";
let showDefenderFieldOfView = localStorage.getItem("readroute-show-defender-fov") === "true";

const els = {
  playName: document.querySelector("#playName"),
  playActionToggle: document.querySelector("#playActionToggle"),
  rpoToggle: document.querySelector("#rpoToggle"),
  playbookLibrary: document.querySelector("#playbookLibrary"),
  playEditorStatus: document.querySelector("#playEditorStatus"),
  formationSelect: document.querySelector("#formationSelect"),
  formationName: document.querySelector("#formationName"),
  playFormationSelect: document.querySelector("#playFormationSelect"),
  mirrorPlayFormationSelect: document.querySelector("#mirrorPlayFormationSelect"),
  runPlaySelect: document.querySelector("#runPlaySelect"),
  runFormationSelect: document.querySelector("#runFormationSelect"),
  runDefenseSelect: document.querySelector("#runDefenseSelect"),
  runSpeedSelect: document.querySelector("#runSpeedSelect"),
  runDefenseMovementSelect: document.querySelector("#runDefenseMovementSelect"),
  runPlayBrowser: document.querySelector("#runPlayBrowser"),
  runPlayBrowserContent: document.querySelector("#runPlayBrowserContent"),
  testSourceSelect: document.querySelector("#testSourceSelect"),
  testPlayOptions: document.querySelector("#testPlayOptions"),
  testPlaySummary: document.querySelector("#testPlaySummary"),
  testSpeedSelect: document.querySelector("#testSpeedSelect"),
  testDefenseOptions: document.querySelector("#testDefenseOptions"),
  testDefenseSummary: document.querySelector("#testDefenseSummary"),
  testStatus: document.querySelector("#testStatus"),
  defenseSelect: document.querySelector("#defenseSelect"),
  defenseName: document.querySelector("#defenseName"),
  coveragePersonalitySelect: document.querySelector("#coveragePersonalitySelect"),
  eyeDisciplineSelect: document.querySelector("#eyeDisciplineSelect"),
  awarenessInput: document.querySelector("#awarenessInput"),
  disciplineInput: document.querySelector("#disciplineInput"),
  aggressionInput: document.querySelector("#aggressionInput"),
  mistakeInput: document.querySelector("#mistakeInput"),
  defenseAlignmentControls: document.querySelector("#defenseAlignmentControls"),
  defenseAlignmentFormationSelect: document.querySelector("#defenseAlignmentFormationSelect"),
  defenseAlignmentProgress: document.querySelector("#defenseAlignmentProgress"),
  defenseLabels: document.querySelector("#defenseLabels"),
  assignments: document.querySelector("#assignments"),
  coachCue: document.querySelector("#coachCue"),
  boardTitle: document.querySelector("#boardTitle"),
  playCount: document.querySelector("#playCount"),
  routes: document.querySelector("#routes"),
  defenders: document.querySelector("#defenders"),
  players: document.querySelector("#players"),
  zones: document.querySelector("#zones"),
  markings: document.querySelector("#fieldMarkings"),
  activeRouteLabel: document.querySelector("#activeRouteLabel"),
  boardModeStatus: document.querySelector("#boardModeStatus"),
  routeHelp: document.querySelector("#routeHelp"),
  fieldOfViewToggle: document.querySelector("#fieldOfViewToggle"),
  field: document.querySelector("#field"),
  fieldCard: document.querySelector(".field-card"),
  fieldStandardSelect: document.querySelector("#fieldStandardSelect"),
  leftPanelEyebrow: document.querySelector("#leftPanelEyebrow"),
  leftPanelTitle: document.querySelector("#leftPanelTitle"),
  assignmentActionHeading: document.querySelector("#assignmentActionHeading"),
  fieldNote: document.querySelector("#fieldNote"),
  notes: document.querySelector("#notes"),
  saveToast: document.querySelector("#saveToast"),
  scenarioStatus: document.querySelector("#scenarioStatus"),
  scenarioZoneSizeControl: document.querySelector("#scenarioZoneSizeControl"),
  scenarioZoneSizeRange: document.querySelector("#scenarioZoneSizeRange"),
  scenarioZoneSizeInput: document.querySelector("#scenarioZoneSizeInput"),
  defensePathHelp: document.querySelector("#defensePathHelp"),
  zoneSizeControl: document.querySelector("#zoneSizeControl"),
  zoneSizeRange: document.querySelector("#zoneSizeRange"),
  zoneSizeInput: document.querySelector("#zoneSizeInput"),
  routeOptionsEditor: document.querySelector("#routeOptionsEditor"),
  routeOptionPlayer: document.querySelector("#routeOptionPlayer"),
  routeOptionSelect: document.querySelector("#routeOptionSelect"),
  routeOptionDetails: document.querySelector("#routeOptionDetails"),
  routeOptionName: document.querySelector("#routeOptionName"),
  routeOptionDefense: document.querySelector("#routeOptionDefense"),
  allRouteOptions: document.querySelector("#allRouteOptions"),
  trenchesFrontSelect: document.querySelector("#trenchesFrontSelect"),
  trenchesFrontSelectMirror: document.querySelector("#trenchesFrontSelectMirror"),
  trenchesFrontName: document.querySelector("#trenchesFrontName"),
  trenchesPlayName: document.querySelector("#trenchesPlayName"),
  trenchesPlaySelect: document.querySelector("#trenchesPlaySelect"),
  newTrenchesPlayButton: document.querySelector("#newTrenchesPlayButton"),
  saveTrenchesPlayButton: document.querySelector("#saveTrenchesPlayButton"),
  newTrenchesFrontButton: document.querySelector("#newTrenchesFrontButton"),
  saveTrenchesFrontButton: document.querySelector("#saveTrenchesFrontButton"),
  deleteTrenchesFrontButton: document.querySelector("#deleteTrenchesFrontButton"),
  addTrenchesOffenseButton: document.querySelector("#addTrenchesOffenseButton"),
  addTrenchesDefenderButton: document.querySelector("#addTrenchesDefenderButton"),
  addTrenchesFrontDefenderButton: document.querySelector("#addTrenchesFrontDefenderButton"),
  undoTrenchesDefensePointButton: document.querySelector("#undoTrenchesDefensePointButton"),
  clearTrenchesDefensePathButton: document.querySelector("#clearTrenchesDefensePathButton"),
  clearTrenchesOffenseButton: document.querySelector("#clearTrenchesOffenseButton"),
  clearTrenchesDefenseButton: document.querySelector("#clearTrenchesDefenseButton"),
  trenchesMoveButton: document.querySelector("#trenchesMoveButton"),
  trenchesDrawButton: document.querySelector("#trenchesDrawButton"),
  addTrenchesNoteButton: document.querySelector("#addTrenchesNoteButton"),
  trenchesBoard: document.querySelector("#trenchesBoard"),
  trenchesSelectedName: document.querySelector("#trenchesSelectedName"),
  trenchesSpeedSelect: document.querySelector("#trenchesSpeedSelect"),
  undoTrenchesPointButton: document.querySelector("#undoTrenchesPointButton"),
  clearTrenchesPathButton: document.querySelector("#clearTrenchesPathButton"),
  trenchesAssignmentsList: document.querySelector("#trenchesAssignmentsList"),
  trenchesDefenderList: document.querySelector("#trenchesDefenderList"),
  trenchesFrontDefenderList: document.querySelector("#trenchesFrontDefenderList"),
  resetTrenchesButton: document.querySelector("#resetTrenchesButton"),
  runTrenchesButton: document.querySelector("#runTrenchesButton"),
  resetTrenchesPlayButton: document.querySelector("#resetTrenchesPlayButton"),
  resetTrenchesAlignmentButton: document.querySelector("#resetTrenchesAlignmentButton"),
};

function readJsonStorage(key) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

function defaultTrenchesAssignments() {
  return defaultTrenchesOffensePlayers().reduce((assignments, player) => {
    assignments[player.id] = {
      path: [],
      targetId: "",
      speed: 1
    };
    return assignments;
  }, {});
}

function defaultTrenchesOffensePlayers() {
  return [
    ...offensiveLine.map(lineman => ({ id: lineman.id, label: lineman.id })),
    { id: "QB", label: "QB" }
  ];
}

function createBlankTrenchesPlay(name = "Untitled Trench Play") {
  return {
    id: crypto.randomUUID(),
    name,
    frontId: "starter",
    assignments: defaultTrenchesAssignments(),
    defensePaths: {},
    fronts: {},
    notes: []
  };
}

function loadTrenchesState() {
  const saved = readJsonStorage(storageKeys.trenches) || {};
  const customFronts = saved.customFronts || {};
  const allFronts = { ...trenchesFronts, ...customFronts };
  const plays = Array.isArray(saved.plays) ? saved.plays : [];
  const selectedPlayId = plays.some(play => play.id === saved.selectedPlayId) ? saved.selectedPlayId : plays[0]?.id || null;
  const savedPlay = plays.find(play => play.id === selectedPlayId);
  const assignments = {
    ...defaultTrenchesAssignments(),
    ...((savedPlay?.assignments || saved.assignments) || {})
  };
  defaultTrenchesOffensePlayers().forEach(player => {
    assignments[player.id] ||= { path: [], targetId: "", speed: 1 };
    assignments[player.id] = {
      path: Array.isArray(assignments[player.id]?.path)
        ? assignments[player.id].path.map(point => ({
            x: Number(point.x),
            y: Number(point.y),
            rounded: Boolean(point.rounded)
          }))
        : [],
      targetId: assignments[player.id]?.targetId || "",
      speed: Number(assignments[player.id]?.speed) || 1
    };
  });
  const defensePathsSource = savedPlay?.defensePaths || saved.defensePaths || {};
  const defensePaths = Object.fromEntries(Object.entries(defensePathsSource).map(([id, item]) => [
    id,
    {
      path: Array.isArray(item?.path)
        ? item.path.map(point => ({ x: Number(point.x), y: Number(point.y), rounded: Boolean(point.rounded) }))
        : [],
      speed: Number(item?.speed) || 1
    }
  ]));
  const requestedFrontId = savedPlay?.frontId || saved.frontId;
  const frontId = allFronts[requestedFrontId]
    ? requestedFrontId
    : requestedFrontId === "even"
      ? "starter"
      : "starter";
  return {
    mode: saved.mode === "draw" ? "draw" : "move",
    panelTab: ["offense", "defense", "front"].includes(saved.panelTab) ? saved.panelTab : "offense",
    playbackSpeed: Number(savedPlay?.playbackSpeed || saved.playbackSpeed) || 1,
    playName: savedPlay?.name || saved.playName || "",
    selectedPlayId,
    plays,
    frontId,
    selectedSide: saved.selectedSide === "defense" ? "defense" : "offense",
    selectedId: saved.selectedId || "LT",
    assignments,
    defensePaths,
    fronts: savedPlay?.fronts || saved.fronts || {},
    notes: Array.isArray(savedPlay?.notes || saved.notes) ? (savedPlay?.notes || saved.notes) : [],
    customFronts
  };
}

function saveTrenchesState() {
  localStorage.setItem(storageKeys.trenches, JSON.stringify(trenchesState));
}

function recoverySnapshot() {
  const current = readJsonStorage(storageKeys.snapshot);
  if (current?.plays?.length && current?.formations?.length && current?.defenses?.length) {
    return current;
  }
  const previous = readJsonStorage(storageKeys.previousSnapshot);
  return previous?.plays?.length && previous?.formations?.length && previous?.defenses?.length
    ? previous
    : null;
}

function loadPlays() {
  const saved = readJsonStorage(storageKeys.plays);
  const recovered = Array.isArray(saved) && saved.length
    ? saved
    : recoverySnapshot()?.plays;
  return Array.isArray(recovered) && recovered.length
    ? recovered.map(normalizePlay)
    : [createBlankPlay()];
}

function normalizePlay(play) {
  const normalizePath = path => Array.isArray(path)
    ? path.map(point => ({
      x: Number(point.x),
      y: Number(point.y),
      rounded: Boolean(point.rounded),
      speed: [1, .75, .5, .25, .1].includes(Number(point.speed))
        ? Number(point.speed)
        : 1
      }))
    : [];
  return {
    ...play,
    intent: normalizePlayIntent(play.intent),
    labels: skillPositions.reduce((labels, position) => {
      labels[position.id] = play.labels?.[position.id] || position.id;
      return labels;
    }, {}),
    routes: routeableOffense.reduce((routes, position) => {
      const savedRoute = play.routes?.[position.id];
      routes[position.id] = normalizePath(savedRoute);
      return routes;
    }, {}),
    routeOptions: skillPositions.reduce((options, position) => {
      const savedOptions = play.routeOptions?.[position.id];
      options[position.id] = Array.isArray(savedOptions)
        ? savedOptions.map((option, index) => ({
            id: option.id || crypto.randomUUID(),
            name: option.name || `Option ${index + 1}`,
            defenseIds: Array.isArray(option.defenseIds)
              ? [...new Set(option.defenseIds.filter(Boolean))]
              : (option.defenseId ? [option.defenseId] : []),
            anchor: option.anchor
              ? {
                  segmentIndex: Math.max(0, Number(option.anchor.segmentIndex) || 0),
                  t: Math.max(0, Math.min(1, Number(option.anchor.t) || 0))
                }
              : (Array.isArray(option.points) && option.points.length
                  ? { segmentIndex: 0, t: 0 }
                  : null),
            points: normalizePath(option.points)
          }))
        : [];
      return options;
    }, {}),
    motions: routeableOffense.reduce((motions, position) => {
      const savedMotion = play.motions?.[position.id];
      motions[position.id] = normalizePath(savedMotion);
      return motions;
    }, {}),
    offensePositions: normalizedOffensePositions(play.offensePositions),
    formationId: play.formationId || null,
    notes: Array.isArray(play.notes) ? play.notes : [],
    legacyDefensePositions: play.defensePositions || {},
    legacyDefenseRoutes: play.defenseRoutes || {},
    legacyCoverageId: play.coverageId || "cover1",
  };
}

function loadFormations() {
  const saved = readJsonStorage(storageKeys.formations);
  const recovered = Array.isArray(saved) && saved.length
    ? saved
    : recoverySnapshot()?.formations;
  if (Array.isArray(recovered) && recovered.length) {
    return recovered.map(formation => ({
      ...formation,
      labels: formation.labels || { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" },
      offensePositions: normalizedOffensePositions(formation.offensePositions),
      notes: Array.isArray(formation.notes) ? formation.notes : []
    }));
  }
  const source = plays[0];
  const formation = {
    id: crypto.randomUUID(),
    name: "Base Formation",
    labels: structuredClone(source.labels),
    offensePositions: structuredClone(source.offensePositions),
    notes: []
  };
  source.formationId = formation.id;
  return [formation];
}

function normalizeDefense(defense) {
  return {
    ...defense,
    realism: normalizeDefenseRealism(defense.realism),
    positions: { ...defaultDefensePositions(), ...(defense.positions || {}) },
    routes: defense.routes || {},
    manAssignments: defense.manAssignments || {},
    techniques: normalizeDefenderTechniques(defense.techniques),
    zoneAssignments: Object.fromEntries(
      Object.entries(defense.zoneAssignments || {}).map(([id, assignment]) => {
        const legacyRadius = Number(assignment?.radius) || 130;
        return [id, {
          ...assignment,
          radiusX: Math.max(40, Math.min(300, Number(assignment?.radiusX) || legacyRadius)),
          radiusY: Math.max(40, Math.min(300, Number(assignment?.radiusY) || legacyRadius))
        }];
      })
    ),
    formationAlignments: Object.fromEntries(
      Object.entries(defense.formationAlignments || {}).map(([formationId, positions]) => [
        formationId,
        { ...defaultDefensePositions(), ...(positions || {}) }
      ])
    ),
    labels: defense.labels || {},
    notes: Array.isArray(defense.notes) ? defense.notes : []
  };
}

function loadDefenses() {
  const saved = readJsonStorage(storageKeys.defenses);
  const recovered = Array.isArray(saved) && saved.length
    ? saved
    : recoverySnapshot()?.defenses;
  if (Array.isArray(recovered) && recovered.length) {
    return recovered.map(normalizeDefense);
  }
  const source = plays[0];
  return [{
    id: crypto.randomUUID(),
    name: "Base Defense",
    positions: {
      ...defaultDefensePositions(),
      ...structuredClone(source.legacyDefensePositions?.[source.legacyCoverageId] || {})
    },
    routes: structuredClone(source.legacyDefenseRoutes?.[source.legacyCoverageId] || {}),
    manAssignments: {},
    zoneAssignments: {},
    techniques: {},
    formationAlignments: {},
    realism: defaultDefenseRealism(),
    labels: {},
    notes: []
  }];
}

function loadDraftPlay() {
  const saved = readJsonStorage(storageKeys.draft);
  const recovered = saved?.play || recoverySnapshot()?.draftPlay;
  return recovered ? normalizePlay(recovered) : null;
}

function normalizeLibraryFolders(folders) {
  return Array.isArray(folders)
    ? folders.filter(folder => folder?.id && folder?.name).map((folder, index) => ({
        id: folder.id,
        name: String(folder.name),
        parentId: folder.parentId || null,
        order: Number.isFinite(Number(folder.order)) ? Number(folder.order) : index,
        itemOrder: Array.isArray(folder.itemOrder)
          ? [...new Set(folder.itemOrder.filter(Boolean))]
          : []
      }))
    : [];
}

function loadLibraryFolders() {
  const saved = readJsonStorage(storageKeys.folders);
  const recovered = Array.isArray(saved) ? saved : recoverySnapshot()?.libraryFolders;
  return normalizeLibraryFolders(recovered);
}

function normalizeLibraryAssignments(assignments) {
  if (!assignments || typeof assignments !== "object") return {};
  return Object.fromEntries(
    Object.entries(assignments).map(([key, value]) => [
      key,
      [...new Set((Array.isArray(value) ? value : [value]).filter(Boolean))]
    ])
  );
}

function loadLibraryAssignments() {
  const saved = readJsonStorage(storageKeys.folderAssignments);
  const recovered = saved && typeof saved === "object"
    ? saved
    : recoverySnapshot()?.libraryAssignments;
  return normalizeLibraryAssignments(recovered);
}

function playbookSnapshot() {
  return {
    version: 3,
    savedAt: new Date().toISOString(),
    fieldStandard,
    formations,
    plays,
    defenses,
    libraryFolders,
    libraryAssignments,
    draftPlay: draftPlay ? structuredClone(draftPlay) : null
  };
}

function openRecoveryDatabase() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error("IndexedDB is unavailable"));
      return;
    }
    const request = indexedDB.open("ReadRouteRecovery", 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("snapshots")) {
        database.createObjectStore("snapshots");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function persistIndexedDbSnapshot(snapshot) {
  try {
    const database = await openRecoveryDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction("snapshots", "readwrite");
      transaction.objectStore("snapshots").put(snapshot, "latest");
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });
    database.close();
  } catch (error) {
    console.warn("ReadRoute secondary backup unavailable", error);
  }
}

async function readIndexedDbSnapshot() {
  try {
    const database = await openRecoveryDatabase();
    const snapshot = await new Promise((resolve, reject) => {
      const transaction = database.transaction("snapshots", "readonly");
      const request = transaction.objectStore("snapshots").get("latest");
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
    database.close();
    return snapshot;
  } catch {
    return null;
  }
}

function persistPlaybook({ rotateBackup = true } = {}) {
  const snapshot = playbookSnapshot();
  try {
    const signature = JSON.stringify({
      formations,
      plays,
      defenses,
      libraryFolders,
      libraryAssignments,
      draftPlay,
      fieldStandard
    });
    if (signature === lastSavedSignature) return true;

    const currentSnapshot = localStorage.getItem(storageKeys.snapshot);
    if (rotateBackup && currentSnapshot) {
      localStorage.setItem(storageKeys.previousSnapshot, currentSnapshot);
    }
    localStorage.setItem(storageKeys.plays, JSON.stringify(plays));
    localStorage.setItem(storageKeys.formations, JSON.stringify(formations));
    localStorage.setItem(storageKeys.defenses, JSON.stringify(defenses));
    localStorage.setItem(storageKeys.folders, JSON.stringify(libraryFolders));
    localStorage.setItem(storageKeys.folderAssignments, JSON.stringify(libraryAssignments));
    localStorage.setItem(storageKeys.snapshot, JSON.stringify(snapshot));
    localStorage.setItem(storageKeys.savedAt, snapshot.savedAt);
    if (draftPlay) {
      localStorage.setItem(storageKeys.draft, JSON.stringify({
        savedAt: snapshot.savedAt,
        play: draftPlay
      }));
    } else {
      localStorage.removeItem(storageKeys.draft);
    }
    lastSavedSignature = signature;
    if (els.playCount) els.playCount.textContent = plays.length;
    persistIndexedDbSnapshot(snapshot);
    if (cloudAccessRole !== "viewer") {
      window.dispatchEvent(new CustomEvent("readroute:playbook-saved", {
        detail: structuredClone(snapshot)
      }));
    }
    return true;
  } catch (error) {
    console.error("ReadRoute autosave failed", error);
    persistIndexedDbSnapshot(snapshot);
    if (els.saveToast) showSaveSuccess("Autosave failed - export your playbook");
    return false;
  }
}

function scheduleAutosave() {
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => persistPlaybook(), 120);
}

function savePlays() {
  scheduleAutosave();
  if (els.playCount) els.playCount.textContent = plays.length;
}

function saveFormations() {
  scheduleAutosave();
}

function saveDefenses() {
  scheduleAutosave();
}

function currentPlay() {
  if (draftPlay && appTab === "create" && createScreen === "play") return draftPlay;
  return plays.find(play => play.id === selectedPlayId) || plays[0];
}

function currentFormation() {
  return formations.find(formation => formation.id === selectedFormationId) || formations[0];
}

function currentDefense() {
  return defenses.find(defense => defense.id === selectedDefenseId) || defenses[0];
}

function defensePositionsForFormation(defense, formationId) {
  return defense.formationAlignments?.[formationId] || defense.positions;
}

function currentDefenseEditorPositions() {
  const defense = currentDefense();
  if (appTab === "create" && createScreen === "defense" && defenseAlignmentMode) {
    defense.formationAlignments ||= {};
    defense.formationAlignments[defenseAlignmentFormationId] ||= structuredClone(defense.positions);
    return defense.formationAlignments[defenseAlignmentFormationId];
  }
  return defense.positions;
}

function isRunLikeMode() {
  return appTab === "run" || appTab === "test";
}

function createRunScenario() {
  return {
    offensePositions: structuredClone(normalizedOffensePositions(currentPlay().offensePositions)),
    offenseRoutes: routeableOffense.reduce((routes, position) => {
      routes[position.id] = structuredClone(
        isSkillPosition(position.id)
          ? resolvedRouteForDefense(currentPlay(), position.id, selectedDefenseId)
          : currentPlay().routes[position.id] || []
      );
      return routes;
    }, {}),
    offenseMotions: structuredClone(currentPlay().motions),
    defensePositions: structuredClone(
      defensePositionsForFormation(currentDefense(), selectedFormationId)
    ),
    defenseRoutes: structuredClone(currentDefense().routes),
    manAssignments: structuredClone(currentDefense().manAssignments || {}),
    zoneAssignments: structuredClone(currentDefense().zoneAssignments || {}),
    techniques: structuredClone(currentDefense().techniques || {}),
    playIntent: normalizePlayIntent(currentPlay().intent),
    defenseRealism: normalizeDefenseRealism(currentDefense().realism)
  };
}

function resetRunScenario() {
  runScenario = createRunScenario();
  animationState = null;
  activeRouteSide = "offense";
  activeRouteId = "X";
}

function runScenarioRoute(side, id) {
  if (!runScenario) resetRunScenario();
  return side === "offense"
    ? (runScenario.offenseRoutes[id] ||= [])
    : (runScenario.defenseRoutes[id] ||= []);
}

function currentManAssignments() {
  if (isRunLikeMode()) {
    if (!runScenario) resetRunScenario();
    return runScenario.manAssignments;
  }
  currentDefense().manAssignments ||= {};
  return currentDefense().manAssignments;
}

function currentZoneAssignments() {
  if (isRunLikeMode()) {
    if (!runScenario) resetRunScenario();
    return runScenario.zoneAssignments ||= {};
  }
  currentDefense().zoneAssignments ||= {};
  return currentDefense().zoneAssignments;
}

function currentDefenderTechniques() {
  if (isRunLikeMode()) {
    if (!runScenario) resetRunScenario();
    return runScenario.techniques ||= {};
  }
  currentDefense().techniques ||= {};
  return currentDefense().techniques;
}

function assignMan(defenderId, offenseId) {
  const assignments = currentManAssignments();
  assignments[defenderId] = offenseId;
  delete currentZoneAssignments()[defenderId];
  if (isRunLikeMode()) {
    runScenario.defenseRoutes[defenderId] = [];
  } else {
    currentDefense().routes[defenderId] = [];
  }
}

function clearDefenderAssignment(defenderId) {
  delete currentManAssignments()[defenderId];
  delete currentZoneAssignments()[defenderId];
  if (isRunLikeMode()) {
    runScenario.defenseRoutes[defenderId] = [];
  } else {
    currentDefense().routes[defenderId] = [];
  }
}

function currentMotion(id) {
  if (isRunLikeMode()) {
    if (!runScenario) resetRunScenario();
    return runScenario.offenseMotions[id] ||= [];
  }
  return currentPlay().motions[id] ||= [];
}

function routeOptionsFor(play, id) {
  play.routeOptions ||= {};
  return play.routeOptions[id] ||= [];
}

function selectedRouteOption(id = activeRouteId) {
  if (selectedRouteOptionId === "base") return null;
  return routeOptionsFor(currentPlay(), id)
    .find(option => option.id === selectedRouteOptionId) || null;
}

function editablePlayRoute(id) {
  if (createScreen === "play" && id === activeRouteId) {
    return selectedRouteOption(id)?.points || currentPlay().routes[id];
  }
  return currentPlay().routes[id] || [];
}

function routeAnchorPoint(start, route, anchor) {
  if (!anchor) return null;
  const path = [start, ...route];
  const segmentIndex = Math.min(anchor.segmentIndex, Math.max(0, path.length - 2));
  const from = path[segmentIndex];
  const to = path[segmentIndex + 1] || from;
  return {
    x: from.x + ((to.x - from.x) * anchor.t),
    y: from.y + ((to.y - from.y) * anchor.t)
  };
}

function branchedRoute(play, id, option, start = play.offensePositions[id]) {
  const baseRoute = play.routes[id] || [];
  if (!option?.anchor || !option.points.length) return baseRoute;
  const segmentIndex = Math.min(
    option.anchor.segmentIndex,
    Math.max(0, baseRoute.length - 1)
  );
  const anchorPoint = routeAnchorPoint(start, baseRoute, option.anchor);
  const prefix = baseRoute.slice(0, segmentIndex);
  return [
    ...prefix,
    {
      ...anchorPoint,
      rounded: false,
      speed: baseRoute[segmentIndex]?.speed || 1
    },
    ...option.points
  ];
}

function routeBranchParts(play, id, option, start = play.offensePositions[id]) {
  const baseRoute = play.routes[id] || [];
  if (!option?.anchor) {
    return { stem: baseRoute, anchor: null, branch: [] };
  }
  const segmentIndex = Math.min(
    option.anchor.segmentIndex,
    Math.max(0, baseRoute.length - 1)
  );
  const anchor = routeAnchorPoint(start, baseRoute, option.anchor);
  return {
    stem: [
      ...baseRoute.slice(0, segmentIndex),
      {
        ...anchor,
        rounded: false,
        speed: baseRoute[segmentIndex]?.speed || 1
      }
    ],
    anchor,
    branch: option.points || []
  };
}

function resolvedRouteForDefense(play, id, defenseId) {
  const matchingOption = routeOptionsFor(play, id)
    .find(option => option.defenseIds?.includes(defenseId));
  return matchingOption
    ? branchedRoute(play, id, matchingOption)
    : play.routes[id] || [];
}

function matchedRouteOption(play, id, defenseId) {
  return routeOptionsFor(play, id)
    .find(option => option.defenseIds?.includes(defenseId)) || null;
}

function emptyPlayPaths(play) {
  play.routeOptions ||= {};
  routeableOffense.forEach(position => {
    play.routes[position.id] = [];
    play.motions[position.id] = [];
    if (isSkillPosition(position.id)) play.routeOptions[position.id] = [];
  });
}

function draftHasWork(play) {
  if (!play) return false;
  return Boolean(
    play.name?.trim()
    || play.notes?.length
    || routeableOffense.some(position =>
      play.routes[position.id]?.length
      || play.motions[position.id]?.length
      || (isSkillPosition(position.id) && play.routeOptions[position.id]?.length)
    )
  );
}

function preserveDraftBeforeReplacement() {
  if (!draftPlay) return;
  if (draftHasWork(draftPlay)) {
    draftPlay.name = draftPlay.name?.trim()
      || `Recovered Draft ${new Date().toLocaleString()}`;
    plays.push(draftPlay);
    selectedPlayId = draftPlay.id;
  }
  draftPlay = null;
  lastSavedSignature = "";
  persistPlaybook();
}

function currentNoteOwner() {
  if (createScreen === "formation") return currentFormation();
  if (createScreen === "defense") return currentDefense();
  return currentPlay();
}

function visibleNotes() {
  if (isRunLikeMode()) return [];
  return currentNoteOwner().notes || [];
}

function showSaveSuccess(message = "Saved successfully") {
  clearTimeout(saveToastTimer);
  els.saveToast.textContent = message;
  els.saveToast.classList.add("visible");
  saveToastTimer = setTimeout(() => els.saveToast.classList.remove("visible"), 1800);
}

function offenseLabel(id) {
  const labels = isRunLikeMode() || createScreen === "formation" || createScreen === "defense"
    ? currentFormation().labels
    : currentPlay().labels;
  return labels[id] || id;
}

function activeRouteDisplayLabel() {
  const label = activeRouteSide === "offense"
    ? offenseLabel(activeRouteId)
    : activeRouteId;
  const option = appTab === "create" && createScreen === "play"
    ? selectedRouteOption(activeRouteId)
    : null;
  return option ? `${label}: ${option.name}` : label;
}

function editorOffensePositions() {
  if (isRunLikeMode()) {
    if (!runScenario) resetRunScenario();
    return runScenario.offensePositions;
  }
  if (createScreen === "formation" || createScreen === "defense") {
    return currentFormation().offensePositions;
  }
  return currentPlay().offensePositions;
}

function isSkillPosition(id) {
  return skillPositions.some(position => position.id === id);
}

function isRouteableOffense(id) {
  return isSkillPosition(id) || id === "QB";
}

function isOffensiveLineman(id) {
  return offensiveLine.some(lineman => lineman.id === id);
}

function constrainOffenseStartPoint(id, point) {
  return isOffensiveLineman(id)
    ? { ...point, y: lineOfScrimmage }
    : point;
}

function snapPlayerToScrimmage(point, event) {
  const shouldSnap = !event.altKey
    && Math.abs(point.y - lineOfScrimmage) <= scrimmageSnapDistance;
  els.field.classList.toggle("scrimmage-snapping", shouldSnap);
  return shouldSnap ? { ...point, y: lineOfScrimmage } : point;
}

function svgEl(name, attrs = {}) {
  const element = document.createElementNS("http://www.w3.org/2000/svg", name);
  Object.entries(attrs).forEach(([key, value]) => element.setAttribute(key, value));
  return element;
}

function positionColor(id, side = "offense") {
  if (side === "defense") {
    const index = Number(String(id).replace(/\D/g, ""));
    return defensePositionColors[Number.isFinite(index) ? index % defensePositionColors.length : 0];
  }
  return offensePositionColors[id] || "#f2c35a";
}

function hexToRgb(hex) {
  const clean = String(hex || "").replace("#", "");
  const value = clean.length === 3
    ? clean.split("").map(char => char + char).join("")
    : clean;
  const number = Number.parseInt(value, 16);
  if (!Number.isFinite(number)) return { r: 242, g: 195, b: 90 };
  return {
    r: (number >> 16) & 255,
    g: (number >> 8) & 255,
    b: number & 255
  };
}

function rgba(hex, alpha) {
  const color = hexToRgb(hex);
  return `rgba(${color.r},${color.g},${color.b},${alpha})`;
}

function readableTextColor(hex) {
  const { r, g, b } = hexToRgb(hex);
  const luminance = ((r * 299) + (g * 587) + (b * 114)) / 1000;
  return luminance > 145 ? "#10231c" : "#fffdf7";
}

function zoneDistance(point, zone) {
  const radii = zoneRadii(zone);
  return Math.hypot(
    (point.x - zone.x) / radii.x,
    (point.y - zone.y) / radii.y
  );
}

function renderMarkings() {
  els.markings.innerHTML = "";
  const pixelsPerYard = 900 / (160 / 3);
  const pixelsPerFoot = 900 / 160;
  const standard = fieldStandards[fieldStandard];
  const hashLeft = standard.hashFromSidelineFeet * pixelsPerFoot;
  const hashRight = 900 - hashLeft;
  const numberLeft = standard.numberCenterFromSidelineFeet * pixelsPerFoot;
  const numberRight = 900 - numberLeft;

  els.markings.append(svgEl("line", { x1: 2, y1: 0, x2: 2, y2: fieldHeight, stroke: "rgba(255,255,255,.8)", "stroke-width": 4 }));
  els.markings.append(svgEl("line", { x1: 898, y1: 0, x2: 898, y2: fieldHeight, stroke: "rgba(255,255,255,.8)", "stroke-width": 4 }));

  for (let yard = -13; yard <= 32; yard += 1) {
    const y = lineOfScrimmage - (yard * pixelsPerYard);
    if (y < 0 || y > fieldHeight) continue;
    const isFive = yard % 5 === 0;
    els.markings.append(svgEl("line", {
      x1: isFive ? 0 : 9,
      y1: y,
      x2: isFive ? 900 : 891,
      y2: y,
      stroke: `rgba(255,255,255,${isFive ? ".30" : ".11"})`,
      "stroke-width": isFive ? 2 : 1
    }));
    [hashLeft, hashRight].forEach(hashX => {
      els.markings.append(svgEl("line", {
        x1: hashX - (pixelsPerYard / 3),
        y1: y,
        x2: hashX + (pixelsPerYard / 3),
        y2: y,
        stroke: "rgba(255,255,255,.68)",
        "stroke-width": 2
      }));
    });
    els.markings.append(svgEl("line", { x1: 0, y1: y, x2: 11, y2: y, stroke: "rgba(255,255,255,.65)", "stroke-width": 2 }));
    els.markings.append(svgEl("line", { x1: 889, y1: y, x2: 900, y2: y, stroke: "rgba(255,255,255,.65)", "stroke-width": 2 }));
  }

  [
    { yard: 0, value: "30" },
    { yard: 10, value: "40" },
    { yard: 20, value: "50" },
  ].forEach(mark => {
    const y = lineOfScrimmage - (mark.yard * pixelsPerYard);
    [numberLeft, numberRight].forEach((x, index) => {
      const number = svgEl("text", {
        x,
        y,
        fill: "rgba(255,255,255,.70)",
        "font-family": "Arial, sans-serif",
        "font-size": 34,
        "font-weight": 900,
        "text-anchor": "middle",
        "dominant-baseline": "central",
        transform: index === 0 ? `rotate(90 ${x} ${y})` : `rotate(-90 ${x} ${y})`
      });
      number.textContent = mark.value;
      els.markings.append(number);
    });
  });

  els.markings.append(svgEl("line", {
    id: "scrimmageLine",
    x1: 0,
    y1: lineOfScrimmage,
    x2: 900,
    y2: lineOfScrimmage,
    stroke: "#fff",
    "stroke-width": 4
  }));
  const label = svgEl("text", { x: 18, y: lineOfScrimmage - 10, fill: "rgba(255,255,255,.76)", "font-size": 10, "font-weight": 800 });
  label.textContent = "LINE OF SCRIMMAGE";
  els.markings.append(label);
}

function renderPlayControls() {
  els.playName.value = currentPlay().name;
  els.playEditorStatus.textContent = draftPlay ? "New unsaved play" : `Editing ${currentPlay().name}`;
  els.playFormationSelect.innerHTML = formations.map(formation =>
    `<option value="${formation.id}">${escapeHtml(formation.name)}</option>`
  ).join("");
  els.playFormationSelect.value = currentPlay().formationId || selectedFormationId;
  els.playFormationSelect.disabled = !draftPlay;
  const intent = normalizePlayIntent(currentPlay().intent);
  if (els.playActionToggle) els.playActionToggle.checked = intent.playAction;
  if (els.rpoToggle) els.rpoToggle.checked = intent.rpo;
  const sourceFormationId = currentPlay().formationId || selectedFormationId;
  const mirrorTargets = formations.filter(formation => formation.id !== sourceFormationId);
  els.mirrorPlayFormationSelect.innerHTML = mirrorTargets.length
    ? mirrorTargets.map(formation =>
        `<option value="${formation.id}">${escapeHtml(formation.name)}</option>`
      ).join("")
    : `<option value="">Create another formation first</option>`;
  els.mirrorPlayFormationSelect.disabled = !mirrorTargets.length;
  document.querySelector("#mirrorPlayButton").disabled = !mirrorTargets.length;
  els.assignmentActionHeading.textContent = createScreen === "formation" ? "Select" : "Route";
  const skillAssignmentRows = skillPositions.map(position => `
    <div class="assignment-row">
      <input data-label="${position.id}" value="${escapeHtml(offenseLabel(position.id))}" maxlength="4" aria-label="${position.id} display label">
      <button class="route-select-button ${activeRouteSide === "offense" && position.id === activeRouteId ? "active" : ""}" data-position="${position.id}">
        ${createScreen === "formation"
          ? "Select"
          : `R ${currentPlay().routes[position.id].length} / O ${routeOptionsFor(currentPlay(), position.id).length} / M ${currentPlay().motions[position.id].length}`}
      </button>
    </div>
  `).join("");
  const qbAssignmentRow = createScreen === "play"
    ? `
      <div class="assignment-row qb-assignment-row">
        <span class="fixed-assignment-label">QB</span>
        <button class="route-select-button ${activeRouteSide === "offense" && activeRouteId === "QB" ? "active" : ""}" data-position="QB">
          R ${(currentPlay().routes.QB || []).length}
        </button>
      </div>
    `
    : "";
  els.assignments.innerHTML = skillAssignmentRows + qbAssignmentRow;
  els.assignments.querySelectorAll(".route-select-button").forEach(button => {
    button.addEventListener("click", event => {
      activeRouteSide = "offense";
      activeRouteId = event.currentTarget.dataset.position;
      selectedRouteOptionId = "base";
      if (activeRouteId === "QB") playPathType = "route";
      if (createScreen === "formation") boardMode = "move";
      renderPlayControls();
      renderRoutesAndPlayers();
    });
  });
  els.assignments.querySelectorAll("input").forEach(input => {
    input.addEventListener("input", event => {
      const target = createScreen === "formation" ? currentFormation().labels : currentPlay().labels;
      target[event.target.dataset.label] = event.target.value.trim().toUpperCase() || event.target.dataset.label;
      render();
    });
  });
  els.playCount.textContent = plays.length;
  els.activeRouteLabel.textContent = activeRouteDisplayLabel();
  renderRouteOptionControls();
  renderFormationControls();
  renderDefenseControls();
  renderRunControls();
}

function renderRouteOptionControls() {
  const available = createScreen === "play" && activeRouteSide === "offense"
    && isSkillPosition(activeRouteId);
  els.routeOptionsEditor.classList.toggle("unavailable", !available);
  if (!available) return;

  const options = routeOptionsFor(currentPlay(), activeRouteId);
  if (selectedRouteOptionId !== "base"
    && !options.some(option => option.id === selectedRouteOptionId)) {
    selectedRouteOptionId = "base";
  }
  const selected = selectedRouteOption(activeRouteId);
  els.routeOptionPlayer.textContent = `${offenseLabel(activeRouteId)} options`;
  els.routeOptionSelect.innerHTML = [
    `<option value="base">Base Route</option>`,
    ...options.map(option =>
      `<option value="${option.id}">${escapeHtml(option.name)}</option>`
    )
  ].join("");
  els.routeOptionSelect.value = selectedRouteOptionId;
  els.routeOptionDetails.classList.toggle("hidden", !selected);
  if (selected) {
    els.routeOptionName.value = selected.name;
    els.routeOptionDefense.innerHTML = defenses.map(defense =>
      `<label class="route-defense-choice">
        <input type="checkbox" value="${defense.id}" ${selected.defenseIds.includes(defense.id) ? "checked" : ""}>
        <span>${escapeHtml(defense.name)}</span>
      </label>`
    ).join("");
  }

  const allOptions = skillPositions.flatMap(position =>
    routeOptionsFor(currentPlay(), position.id).map(option => ({
      positionId: position.id,
      player: currentPlay().labels[position.id] || position.id,
      option
    }))
  );
  els.allRouteOptions.innerHTML = `
    <p class="all-route-options-title">All options in this play</p>
    ${allOptions.length
      ? allOptions.map(item => `
          <div class="route-option-file ${
            activeRouteId === item.positionId && selectedRouteOptionId === item.option.id
              ? "active"
              : ""
          }">
            <span>${escapeHtml(item.player)}: ${escapeHtml(item.option.name)}</span>
            <button class="route-tool-button" data-edit-route-option="${item.option.id}" data-option-player="${item.positionId}">Edit</button>
            <button class="route-tool-button danger" data-remove-route-option="${item.option.id}" data-option-player="${item.positionId}">Delete</button>
          </div>
        `).join("")
      : `<p class="route-option-help">No saved route options yet.</p>`}
  `;
  els.allRouteOptions.querySelectorAll("[data-edit-route-option]").forEach(button => {
    button.addEventListener("click", () => {
      activeRouteSide = "offense";
      activeRouteId = button.dataset.optionPlayer;
      selectedRouteOptionId = button.dataset.editRouteOption;
      playPathType = "route";
      renderPlayControls();
      render();
    });
  });
  els.allRouteOptions.querySelectorAll("[data-remove-route-option]").forEach(button => {
    button.addEventListener("click", () => {
      const positionId = button.dataset.optionPlayer;
      const option = routeOptionsFor(currentPlay(), positionId)
        .find(candidate => candidate.id === button.dataset.removeRouteOption);
      if (!option || !window.confirm(`Delete route option "${option.name}"?`)) return;
      currentPlay().routeOptions[positionId] = routeOptionsFor(currentPlay(), positionId)
        .filter(candidate => candidate.id !== option.id);
      if (selectedRouteOptionId === option.id) selectedRouteOptionId = "base";
      lastSavedSignature = "";
      persistPlaybook();
      renderPlayControls();
      render();
    });
  });
}

function libraryItemKey(type, id) {
  return `${type}:${id}`;
}

function libraryItems() {
  return [
    ...formations.map(item => ({ type: "formation", id: item.id, name: item.name, icon: "F" })),
    ...plays.map(item => ({ type: "play", id: item.id, name: item.name, icon: "P" })),
    ...defenses.map(item => ({ type: "defense", id: item.id, name: item.name, icon: "D" }))
  ];
}

function playFormationName(play) {
  return formations.find(formation => formation.id === play.formationId)?.name || "No Formation";
}

function normalizedPlaybookSearch() {
  return playbookSearchQuery.trim().toLowerCase();
}

function playMatchesPlaybookSearch(play) {
  const query = normalizedPlaybookSearch();
  if (!query) return true;
  return `${play.name} ${playFormationName(play)}`.toLowerCase().includes(query);
}

function formationMatchesPlaybookSearch(formation) {
  const query = normalizedPlaybookSearch();
  if (!query) return true;
  return formation.name.toLowerCase().includes(query);
}

function formationLibraryRowMarkup(formation) {
  const formationPlayCount = plays.filter(play => play.formationId === formation.id).length;
  return `
    <div class="library-file-row">
      <button class="library-file ${libraryPreview.type === "formation" && libraryPreview.id === formation.id ? "active" : ""}" data-library-formation="${formation.id}">
        <span class="library-file-icon">F</span>
        <span>${escapeHtml(formation.name)}</span>
        <small>${formationPlayCount} ${formationPlayCount === 1 ? "play" : "plays"}</small>
      </button>
      <button class="library-action-button" data-edit-formation="${formation.id}">Edit</button>
      <button class="library-action-button danger" data-delete-formation="${formation.id}" ${formations.length === 1 || formationPlayCount ? "disabled" : ""}>Delete</button>
    </div>
  `;
}

function playLibraryRowMarkup(play) {
  const formationName = playFormationName(play);
  return `
    <div class="library-file-row">
      <button class="library-file ${libraryPreview.type === "play" && libraryPreview.id === play.id ? "active" : ""}" data-library-play="${play.id}">
        <span class="library-file-icon">P</span>
        <span>${escapeHtml(formationName)} / ${escapeHtml(play.name)}</span>
      </button>
      <button class="library-action-button" data-edit-play="${play.id}">Edit</button>
      <button class="library-action-button danger" data-delete-play="${play.id}" ${plays.length === 1 ? "disabled" : ""}>Delete</button>
    </div>
  `;
}

function itemFolderIds(key) {
  const saved = libraryAssignments[key];
  return Array.isArray(saved) ? saved : saved ? [saved] : [];
}

function libraryFolderChildren(parentId) {
  return libraryFolders
    .filter(folder => (folder.parentId || null) === (parentId || null))
    .sort((a, b) => {
      const orderCompare = (Number(a.order) || 0) - (Number(b.order) || 0);
      return orderCompare || a.name.localeCompare(b.name);
    });
}

function sortLibraryFolderList(folders) {
  return [...folders].sort((a, b) => {
    const orderCompare = (Number(a.order) || 0) - (Number(b.order) || 0);
    return orderCompare || a.name.localeCompare(b.name);
  });
}

function normalizeFolderSiblingOrder(parentId) {
  libraryFolderChildren(parentId).forEach((folder, index) => {
    folder.order = index;
  });
}

function sortedFolderItems(folder) {
  const order = Array.isArray(folder.itemOrder) ? folder.itemOrder : [];
  return libraryItems()
    .filter(item => itemFolderIds(libraryItemKey(item.type, item.id)).includes(folder.id))
    .sort((a, b) => {
      const keyA = libraryItemKey(a.type, a.id);
      const keyB = libraryItemKey(b.type, b.id);
      const indexA = order.indexOf(keyA);
      const indexB = order.indexOf(keyB);
      if (indexA >= 0 && indexB >= 0) return indexA - indexB;
      if (indexA >= 0) return -1;
      if (indexB >= 0) return 1;
      return a.name.localeCompare(b.name);
    });
}

function setItemFolderMembership(key, folderId, included) {
  const memberships = new Set(itemFolderIds(key));
  if (included) memberships.add(folderId);
  else memberships.delete(folderId);
  if (memberships.size) libraryAssignments[key] = [...memberships];
  else delete libraryAssignments[key];
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder) return;
  folder.itemOrder ||= [];
  if (included && !folder.itemOrder.includes(key)) {
    folder.itemOrder.push(key);
  } else if (!included) {
    folder.itemOrder = folder.itemOrder.filter(itemKey => itemKey !== key);
  }
}

function updateFormationPickerState(input) {
  const group = input.closest(".folder-formation-picker");
  if (!group) return;
  const playInputs = [...group.querySelectorAll("[data-folder-membership][data-membership-item^='play:']")];
  const selectedCount = playInputs.filter(playInput => playInput.checked).length;
  const allPlaysInput = group.querySelector("[data-folder-formation-plays-membership]");
  const count = group.querySelector(".folder-formation-picker-header small");
  if (allPlaysInput) {
    allPlaysInput.checked = playInputs.length > 0 && selectedCount === playInputs.length;
    allPlaysInput.indeterminate = selectedCount > 0 && selectedCount < playInputs.length;
  }
  if (count) count.textContent = `${selectedCount}/${playInputs.length} selected`;
}

function rememberLibraryFolderState() {
  els.playbookLibrary
    ?.querySelectorAll("[data-library-folder-state]")
    .forEach(folder => {
      libraryFolderOpenState.set(folder.dataset.libraryFolderState, folder.open);
    });
  els.playbookLibrary
    ?.querySelectorAll("[data-folder-picker-state]")
    .forEach(folder => {
      folderPickerOpenState.set(folder.dataset.folderPickerState, folder.open);
    });
}

function libraryFolderOpenAttribute(key) {
  return libraryFolderOpenState.get(key) === true ? " open" : "";
}

function folderPickerOpenAttribute(key, hasSearchMatch = false) {
  return folderPickerOpenState.get(key) === true || (normalizedFolderPickerSearch() && hasSearchMatch)
    ? " open"
    : "";
}

function normalizedFolderPickerSearch() {
  return activeFolderPickerSearch.trim().toLowerCase();
}

function folderPickerPlayMatches(play, formationName) {
  const query = normalizedFolderPickerSearch();
  if (!query) return true;
  return `${play.name} ${formationName}`.toLowerCase().includes(query);
}

function customLibraryFileMarkup(item, folderId) {
  const key = libraryItemKey(item.type, item.id);
  const formationName = item.type === "play"
    ? formations.find(formation =>
        formation.id === plays.find(play => play.id === item.id)?.formationId
      )?.name
    : "";
  const displayName = formationName
    ? `${formationName} / ${item.name}`
    : item.name;
  const previewAttribute = item.type === "play"
    ? `data-library-play="${item.id}"`
    : item.type === "defense"
      ? `data-library-defense="${item.id}"`
      : "";
  const editAttribute = `data-edit-${item.type}="${item.id}"`;
  return `
    <div class="custom-library-file" data-folder-item-row="${key}" data-folder-item-folder="${folderId}">
      <span class="library-drag-handle" draggable="${cloudAccessRole !== "viewer"}" data-drag-folder-item="${key}" data-drag-folder-item-folder="${folderId}" title="Drag to reorder" aria-label="Drag to reorder"></span>
      <button class="library-file ${item.type === "defense" ? "defense-file" : ""} ${libraryPreview.type === item.type && libraryPreview.id === item.id ? "active" : ""}" ${previewAttribute} ${item.type === "play" ? `data-library-folder-context="${folderId}"` : ""} ${item.type === "formation" ? editAttribute : ""}>
        <span class="library-file-icon">${item.icon}</span>
        <span>${escapeHtml(displayName)}</span>
      </button>
      ${item.type !== "formation" ? `<button class="library-action-button" ${editAttribute}>Edit</button>` : ""}
      <button class="library-action-button danger" data-remove-folder-item="${key}" data-remove-from-folder="${folderId}">Remove</button>
    </div>
  `;
}

function folderPlayPickerMarkup(folderId) {
  const searchQuery = normalizedFolderPickerSearch();
  const folderItemButton = (key, included, addLabel = "Add", removeLabel = "Remove") => `
    <button
      type="button"
      class="folder-picker-action ${included ? "is-selected" : ""}"
      data-toggle-folder-item="${key}"
      data-folder-id="${folderId}"
      data-folder-included="${included ? "true" : "false"}"
    >${included ? removeLabel : addLabel}</button>
  `;
  const playSearchResults = searchQuery
    ? plays
        .map(play => ({
          play,
          formation: formations.find(candidate => candidate.id === play.formationId)
        }))
        .filter(({ play, formation }) => folderPickerPlayMatches(play, formation?.name || ""))
        .sort((a, b) => {
          const formationCompare = (a.formation?.name || "").localeCompare(b.formation?.name || "");
          return formationCompare || a.play.name.localeCompare(b.play.name);
        })
    : [];
  const playSearchMarkup = searchQuery
    ? `
      <section class="folder-search-results">
        <p class="folder-picker-heading">Matching plays</p>
        ${playSearchResults.length
          ? playSearchResults.map(({ play, formation }) => {
              const key = libraryItemKey("play", play.id);
              const included = itemFolderIds(key).includes(folderId);
              return `
                <div class="folder-pick-row folder-search-result-row">
                  <span class="folder-pick-badge">Play</span>
                  <span class="folder-result-name">
                    <strong>${escapeHtml(formation?.name || "No formation")}</strong>
                    <em>${escapeHtml(play.name)}</em>
                  </span>
                  ${folderItemButton(key, included, "Add", "Remove")}
                </div>
              `;
            }).join("")
          : `<p class="library-empty">No plays match that search.</p>`}
      </section>
    `
    : "";

  const formationCards = formations.map(formation => {
    const formationKey = libraryItemKey("formation", formation.id);
    const formationSelected = itemFolderIds(formationKey).includes(folderId);
    const allFormationPlays = plays
      .filter(play => play.formationId === formation.id)
      .sort((a, b) => a.name.localeCompare(b.name));
    const formationNameMatches = searchQuery && formation.name.toLowerCase().includes(searchQuery);
    const formationPlays = searchQuery && !formationNameMatches
      ? allFormationPlays.filter(play => folderPickerPlayMatches(play, formation.name))
      : allFormationPlays;
    if (searchQuery && !formationNameMatches && !formationPlays.length) return "";
    const selectedCount = allFormationPlays.filter(play =>
      itemFolderIds(libraryItemKey("play", play.id)).includes(folderId)
    ).length;
    const visibleSelectedCount = formationPlays.filter(play =>
      itemFolderIds(libraryItemKey("play", play.id)).includes(folderId)
    ).length;
    const allSelected = allFormationPlays.length > 0 && selectedCount === allFormationPlays.length;
    const visibleAllSelected = formationPlays.length > 0 && visibleSelectedCount === formationPlays.length;
    const pickerKey = `picker:${folderId}:${formation.id}`;
    return `
      <details class="folder-pick-card" data-folder-picker-state="${pickerKey}"${folderPickerOpenAttribute(pickerKey, Boolean(searchQuery))}>
        <summary class="folder-pick-card-header">
          <span class="folder-pick-badge">Formation</span>
          <span class="folder-pick-title">
            <strong>${escapeHtml(formation.name)}</strong>
            <em>${allFormationPlays.length ? `${allFormationPlays.length} saved plays` : "No saved plays yet"}</em>
          </span>
          <small>${selectedCount}/${allFormationPlays.length} plays</small>
          ${folderItemButton(formationKey, formationSelected, "Add Form", "Remove")}
        </summary>
        <div class="folder-pick-card-body">
          ${formationPlays.length ? `
            <div class="folder-pick-row all">
              <span class="folder-pick-spacer"></span>
              <strong>${searchQuery && !formationNameMatches ? `All matching plays in ${escapeHtml(formation.name)}` : `All plays in ${escapeHtml(formation.name)}`}</strong>
              <button
                type="button"
                class="folder-picker-action ${(searchQuery && !formationNameMatches ? visibleAllSelected : allSelected) ? "is-selected" : ""}"
                data-toggle-formation-plays="${formation.id}"
                data-folder-id="${folderId}"
                data-folder-visible-play-ids="${formationPlays.map(play => play.id).join(",")}"
                data-folder-included="${(searchQuery && !formationNameMatches ? visibleAllSelected : allSelected) ? "true" : "false"}"
              >${(searchQuery && !formationNameMatches ? visibleAllSelected : allSelected) ? "Remove All" : "Add All"}</button>
            </div>
            ${formationPlays.map(play => {
              const key = libraryItemKey("play", play.id);
              const included = itemFolderIds(key).includes(folderId);
              return `
                <div class="folder-pick-row">
                  <span class="folder-pick-badge">Play</span>
                  <span class="folder-result-name">
                    <strong>${escapeHtml(formation.name)}</strong>
                    <em>${escapeHtml(play.name)}</em>
                  </span>
                  ${folderItemButton(key, included, "Add", "Remove")}
                </div>
              `;
            }).join("")}
          ` : `
            <p class="library-empty">${searchQuery ? "No matching plays in this formation." : "No plays saved for this formation. You can still add the formation above."}</p>
          `}
        </div>
      </details>
    `;
  }).join("");

  return `
    <div class="folder-membership-list">
      <div class="folder-picker-search">
        <label for="folderPickerSearchInput">Search plays to add</label>
        <div class="folder-picker-search-row">
          <input
            id="folderPickerSearchInput"
            type="search"
            placeholder="Search by play or formation..."
            value="${escapeHtml(activeFolderPickerSearch)}"
            autocomplete="off"
          >
          <button class="library-action-button" data-clear-folder-picker-search ${activeFolderPickerSearch ? "" : "disabled"}>Clear</button>
        </div>
      </div>
      ${playSearchMarkup}
      <div class="folder-picker-scroll">
        <p class="folder-picker-heading">Plays by formation</p>
        ${formationCards || `<p class="library-empty">${searchQuery ? "No plays match that search." : "No formations saved yet."}</p>`}
      </div>
    </div>
  `;
}
function customFolderMarkup(folder, depth = 0) {
  const children = libraryFolderChildren(folder.id);
  const items = sortedFolderItems(folder);
  return `
    <details class="custom-library-folder"${libraryFolderOpenAttribute(`custom:${folder.id}`)} style="--folder-depth:${depth}" data-folder-drop="${folder.id}" data-folder-row="${folder.id}" data-library-folder-state="custom:${folder.id}">
      <summary>
        <span class="library-drag-handle folder-handle" draggable="${cloudAccessRole !== "viewer"}" data-drag-library-folder="${folder.id}" title="Drag folder to reorder" aria-label="Drag folder to reorder"></span>
        <span class="library-folder-icon">F</span>
        <span>${escapeHtml(folder.name)}</span>
        <small>${children.length + items.length}</small>
      </summary>
      <div class="custom-folder-actions">
        <button class="library-action-button" data-add-subfolder="${folder.id}">+ Subfolder</button>
        <button class="library-action-button" data-open-folder-picker="${folder.id}">Manage Items</button>
        <button class="library-action-button" data-rename-folder="${folder.id}">Rename</button>
        <button class="library-action-button danger" data-delete-folder="${folder.id}">Delete</button>
      </div>
      <div class="custom-folder-content" data-folder-content="${folder.id}">
        ${children.map(child => customFolderMarkup(child, depth + 1)).join("")}
        ${items.map(item => customLibraryFileMarkup(item, folder.id)).join("")}
        ${!children.length && !items.length ? `<p class="library-empty">This folder is empty.</p>` : ""}
      </div>
    </details>
  `;
}

function customFolderBrowserMarkup() {
  const roots = sortLibraryFolderList(libraryFolders.filter(folder =>
    !folder.parentId || !libraryFolders.some(candidate => candidate.id === folder.parentId)
  ));
  return `
    <section class="custom-folder-browser">
      <div class="custom-folder-heading">
        <div>
          <p class="eyebrow">Custom organization</p>
          <h3>Folders</h3>
          <p class="custom-folder-help">A play can belong to several folders. Drag it onto a folder or use Add or remove files.</p>
        </div>
        <button id="addRootFolderButton" class="library-action-button">+ New Folder</button>
      </div>
      ${roots.map(folder => customFolderMarkup(folder)).join("")}
      ${!roots.length ? `<p class="library-empty">Create a folder such as Week 1 or Cover 2 Beaters.</p>` : ""}
    </section>
  `;
}

function folderPickerPanelMarkup() {
  if (playbookTab !== "folders" || !activeFolderPickerId) return "";
  const folder = libraryFolders.find(candidate => candidate.id === activeFolderPickerId);
  if (!folder) {
    activeFolderPickerId = null;
    return "";
  }
  return `
    <section class="folder-picker-panel">
      <div class="folder-picker-panel-heading">
        <div>
          <p class="eyebrow">Add to folder</p>
          <h3>${escapeHtml(folder.name)}</h3>
          <p class="custom-folder-help">Use these rows to add formations, all plays in a formation, or individual plays.</p>
        </div>
        <button class="library-action-button folder-picker-close-button" data-close-folder-picker>Done</button>
      </div>
      ${folderPlayPickerMarkup(folder.id)}
    </section>
  `;
}

function printFolderOptionMarkup(folder, depth = 0) {
  const children = libraryFolderChildren(folder.id);
  const printCount = collectFolderPrintPlayIds(folder.id).size;
  const directItems = sortedFolderItems(folder);
  const directPlayRows = directItems.flatMap(item => {
    if (item.type === "play") {
      const play = plays.find(candidate => candidate.id === item.id);
      if (!play) return [];
      return [{
        play,
        label: playFormationName(play)
      }];
    }
    if (item.type === "formation") {
      const formation = formations.find(candidate => candidate.id === item.id);
      if (!formation) return [];
      return plays
        .filter(play => play.formationId === formation.id)
        .sort((a, b) => a.name.localeCompare(b.name))
        .map(play => ({
          play,
          label: formation.name
        }));
    }
    return [];
  });
  return `
    <details class="print-folder-option print-playbook-group" style="--print-folder-depth:${depth}">
      <summary>
        <div class="print-playbook-check">
          <input type="checkbox" data-print-folder="${folder.id}" ${printCount ? "" : "disabled"}>
          <span>
            <strong>${escapeHtml(folder.name)}</strong>
            <small>${printCount} ${printCount === 1 ? "play" : "plays"}</small>
          </span>
        </div>
      </summary>
      <div class="print-playbook-options">
        ${directPlayRows.length
          ? directPlayRows.map(({ play, label }) => `
            <label class="print-playbook-check compact">
              <input type="checkbox" data-print-play="${play.id}">
              <span>
                <strong>${escapeHtml(label)}</strong>
                <em>${escapeHtml(play.name)}</em>
              </span>
            </label>
          `).join("")
          : `<p class="library-empty">No direct plays in this folder.</p>`}
        ${children.map(child => printFolderOptionMarkup(child, depth + 1)).join("")}
      </div>
    </details>
  `;
}

function printPlaybookPanelMarkup() {
  if (!printPlaybookOpen) return "";
  const rootFolders = sortLibraryFolderList(libraryFolders.filter(folder =>
    !folder.parentId || !libraryFolders.some(candidate => candidate.id === folder.parentId)
  ));
  const formationGroups = formations
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(formation => {
      const formationPlays = plays
        .filter(play => play.formationId === formation.id)
        .sort((a, b) => a.name.localeCompare(b.name));
      return `
        <details class="print-playbook-group">
          <summary>
            <div class="print-playbook-check">
              <input type="checkbox" data-print-formation="${formation.id}" ${formationPlays.length ? "" : "disabled"}>
              <span>
                <strong>${escapeHtml(formation.name)}</strong>
                <small>${formationPlays.length} ${formationPlays.length === 1 ? "play" : "plays"}</small>
              </span>
            </div>
          </summary>
          <div class="print-playbook-options">
            ${formationPlays.length
              ? formationPlays.map(play => `
                <label class="print-playbook-check compact">
                  <input type="checkbox" data-print-play="${play.id}">
                  <span>${escapeHtml(play.name)}</span>
                </label>
              `).join("")
              : `<p class="library-empty">No plays saved in this formation yet.</p>`}
          </div>
        </details>
      `;
    }).join("");
  const unassignedPlays = plays
    .filter(play => !formations.some(formation => formation.id === play.formationId))
    .sort((a, b) => a.name.localeCompare(b.name));
  const unassignedGroup = unassignedPlays.length
    ? `
      <details class="print-playbook-group">
        <summary>
          <span class="print-playbook-check">
            <span class="library-file-icon">P</span>
            <span>
              <strong>Plays Without Formation</strong>
              <small>${unassignedPlays.length} ${unassignedPlays.length === 1 ? "play" : "plays"}</small>
            </span>
          </span>
        </summary>
        <div class="print-playbook-options">
          ${unassignedPlays.map(play => `
            <label class="print-playbook-check compact">
              <input type="checkbox" data-print-play="${play.id}">
              <span>${escapeHtml(play.name)}</span>
            </label>
          `).join("")}
        </div>
      </details>
    `
    : "";

  return `
    <section class="print-playbook-panel">
      <div class="print-playbook-heading">
        <div>
          <p class="eyebrow">Print out playbook</p>
          <h3>Choose Plays For PDF</h3>
          <p>Select folders, whole formations, or individual plays. The printout is one play per landscape page.</p>
          <label class="print-playbook-toggle">
            <input id="printHideNotesInput" type="checkbox">
            <span>Hide notes on printout</span>
          </label>
        </div>
        <div class="print-playbook-actions">
          <button class="library-action-button" data-close-print-playbook>Cancel</button>
          <button class="library-action-button button-primary" data-generate-print-playbook ${plays.length ? "" : "disabled"}>Create Printout</button>
        </div>
      </div>
      <div class="print-playbook-grid">
        <div class="print-playbook-section">
          <p class="folder-picker-heading">Folders</p>
          ${rootFolders.length
            ? rootFolders.map(folder => printFolderOptionMarkup(folder)).join("")
            : `<p class="library-empty">No custom folders yet.</p>`}
        </div>
        <div class="print-playbook-section">
          <p class="folder-picker-heading">Formations & Plays</p>
          ${formationGroups}${unassignedGroup}
          ${!formationGroups && !unassignedGroup ? `<p class="library-empty">No plays saved yet.</p>` : ""}
        </div>
      </div>
    </section>
  `;
}

function collectFolderPrintPlayIds(folderId, collected = new Set()) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder) return collected;
  sortedFolderItems(folder).forEach(item => {
    if (item.type === "play") {
      collected.add(item.id);
    } else if (item.type === "formation") {
      plays
        .filter(play => play.formationId === item.id)
        .forEach(play => collected.add(play.id));
    }
  });
  libraryFolderChildren(folder.id).forEach(child => {
    collectFolderPrintPlayIds(child.id, collected);
  });
  return collected;
}

function selectedPrintPlayIds() {
  const selected = new Set();
  els.playbookLibrary
    .querySelectorAll("[data-print-folder], [data-print-formation], [data-print-play]")
    .forEach(input => {
      if (!input.checked) return;
      if (input.dataset.printFolder) {
        collectFolderPrintPlayIds(input.dataset.printFolder).forEach(id => selected.add(id));
      } else if (input.dataset.printFormation) {
        plays
          .filter(play => play.formationId === input.dataset.printFormation)
          .sort((a, b) => a.name.localeCompare(b.name))
          .forEach(play => selected.add(play.id));
      } else if (input.dataset.printPlay) {
        selected.add(input.dataset.printPlay);
      }
    });
  return [...selected]
    .map(id => plays.find(play => play.id === id))
    .filter(Boolean);
}

function printMarkerId(play, name) {
  return `${name}-${String(play.id).replace(/[^a-z0-9_-]/gi, "")}`;
}

function printablePlayDiagramMarkup(play, options = {}) {
  const formation = formations.find(savedFormation => savedFormation.id === play.formationId) || formations[0];
  const offensePositions = play.offensePositions || formation.offensePositions;
  const offenseLabels = play.labels || formation.labels;
  const routeMarkup = skillPositions.map(position => {
    const playerColor = positionColor(position.id, "offense");
    const route = play.routes[position.id] || [];
    const motion = play.motions?.[position.id] || [];
    const start = offensePositions[position.id];
    const snapStart = motionEnd(start, motion);
    const dx = snapStart.x - start.x;
    const dy = snapStart.y - start.y;
    const shiftedRoute = motion.length
      ? route.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }))
      : route;
    const motionPath = motion.length
      ? `<path d="${motion.length === 1 ? `M ${start.x} ${start.y} L ${motion[0].x} ${motion[0].y}` : routePathData(start, motion)}" fill="none" stroke="${playerColor}" stroke-width="4" stroke-dasharray="7 6" marker-end="url(#${printMarkerId(play, "motionArrow")})"></path>`
      : "";
    const routePath = shiftedRoute.length
      ? `<path d="${shiftedRoute.length === 1 ? `M ${snapStart.x} ${snapStart.y} L ${shiftedRoute[0].x} ${shiftedRoute[0].y}` : routePathData(snapStart, shiftedRoute)}" fill="none" stroke="${playerColor}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#${printMarkerId(play, "routeArrow")})"></path>`
      : "";
    return motionPath + routePath;
  }).join("");
  const qbRouteMarkup = (() => {
    const start = offensePositions.QB;
    const playerColor = positionColor("QB", "offense");
    const route = play.routes.QB || [];
    if (!route.length) return "";
    const pathData = route.length === 1
      ? `M ${start.x} ${start.y} L ${route[0].x} ${route[0].y}`
      : routePathData(start, route);
    return `<path d="${pathData}" fill="none" stroke="${playerColor}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#${printMarkerId(play, "routeArrow")})"></path>`;
  })();
  const optionRouteMarkup = skillPositions.map(position => {
    const playerColor = positionColor(position.id, "offense");
    const start = offensePositions[position.id];
    const motion = play.motions?.[position.id] || [];
    const snapStart = motionEnd(start, motion);
    const dx = snapStart.x - start.x;
    const dy = snapStart.y - start.y;
    return routeOptionsFor(play, position.id).map(option => {
      const storedAnchor = routeAnchorPoint(start, play.routes[position.id] || [], option.anchor);
      if (!storedAnchor || !option.points.length) return "";
      const displayAnchor = { x: storedAnchor.x + dx, y: storedAnchor.y + dy };
      const shifted = motion.length
        ? option.points.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }))
        : option.points;
      const pathData = shifted.length === 1
        ? `M ${displayAnchor.x} ${displayAnchor.y} L ${shifted[0].x} ${shifted[0].y}`
        : routePathData(displayAnchor, shifted);
      return `<path d="${pathData}" fill="none" stroke="${playerColor}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="8 6" marker-end="url(#${printMarkerId(play, "optionArrow")})" opacity=".82"></path>`;
    }).join("");
  }).join("");
  const offenseMarkup = [
    ...skillPositions.map(position => {
      const point = offensePositions[position.id];
      const playerColor = positionColor(position.id, "offense");
      return `<g transform="translate(${point.x} ${point.y})"><circle r="18" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></circle><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="10" font-weight="900">${escapeHtml(offenseLabels[position.id] || position.id)}</text></g>`;
    }),
    ...offensiveLine.map(player => {
      const point = offensePositions[player.id];
      const playerColor = positionColor(player.id, "offense");
      return `<g transform="translate(${point.x} ${point.y})"><rect x="-15" y="-15" width="30" height="30" rx="5" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></rect><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="9" font-weight="900">${player.label}</text></g>`;
    }),
    (() => {
      const point = offensePositions.QB;
      const playerColor = positionColor("QB", "offense");
      return `<g transform="translate(${point.x} ${point.y})"><circle r="19" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></circle><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="10" font-weight="900">QB</text></g>`;
    })()
  ].join("");
  const notes = options.hideNotes ? [] : [...(formation.notes || []), ...(play.notes || [])];
  const notesMarkup = notes.map(note => {
    const dimensions = noteDimensions(note.text);
    const x = Math.max(6, Math.min(note.x, fieldWidth - 6 - dimensions.width));
    const y = Math.max(6, Math.min(note.y, fieldHeight - 6 - dimensions.height));
    return `
      <g transform="translate(${x} ${y})">
        <rect width="${dimensions.width}" height="${dimensions.height}" rx="5" fill="rgba(255,253,247,.96)" stroke="#c9f45c" stroke-width="2"></rect>
        <foreignObject x="5" y="5" width="${Math.max(1, dimensions.width - 10)}" height="${Math.max(1, dimensions.height - 10)}">
          <div xmlns="http://www.w3.org/1999/xhtml" class="print-note">${escapeHtml(note.text || "")}</div>
        </foreignObject>
      </g>
    `;
  }).join("");
  const routeOptionSummary = skillPositions.flatMap(position =>
    routeOptionsFor(play, position.id).map(option => {
      const defenseNames = option.defenseIds
        .map(defenseId => defenses.find(candidate => candidate.id === defenseId)?.name)
        .filter(Boolean);
      return `<span><strong>${escapeHtml(offenseLabels[position.id] || position.id)}:</strong> ${escapeHtml(option.name)} vs. ${escapeHtml(defenseNames.join(", ") || "Unassigned defense")}</span>`;
    })
  ).join("");

  return `
    <article class="print-page" draggable="true">
      <div class="print-page-controls">
        <span class="print-page-handle" title="Drag to reorder">Drag</span>
        <button type="button" data-move-page="up">Up</button>
        <button type="button" data-move-page="down">Down</button>
      </div>
      <header>
        <div>
          <p>${escapeHtml(formation.name)}</p>
          <h1>${escapeHtml(play.name)}</h1>
        </div>
        <span>${escapeHtml(fieldStandards[fieldStandard].label)} field</span>
      </header>
      <main>
        <svg viewBox="0 0 ${fieldWidth} ${fieldHeight}" aria-label="${escapeHtml(play.name)} print diagram">
          <defs>
            <marker id="${printMarkerId(play, "routeArrow")}" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
            <marker id="${printMarkerId(play, "motionArrow")}" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
            <marker id="${printMarkerId(play, "optionArrow")}" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
          </defs>
          <rect width="${fieldWidth}" height="${fieldHeight}" rx="10" fill="#174c35"></rect>
          ${libraryFieldMarkingsMarkup()}
          ${routeMarkup}${qbRouteMarkup}${optionRouteMarkup}${offenseMarkup}${notesMarkup}
        </svg>
      </main>
      ${routeOptionSummary
        ? `<footer><strong>Route options</strong>${routeOptionSummary}</footer>`
        : ""}
    </article>
  `;
}

function printablePlaybookDocumentMarkup(selectedPlays, options = {}) {
  const title = `ReadRoute Playbook - ${new Date().toLocaleDateString()}`;
  return `<!doctype html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${escapeHtml(title)}</title>
        <style>
          @page { size: landscape; margin: .35in; }
          * { box-sizing: border-box; }
          body {
            margin: 0;
            color: #10231c;
            background: #eef1e8;
            font-family: Inter, Arial, sans-serif;
          }
          .print-toolbar {
            position: sticky;
            top: 0;
            z-index: 5;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #f4fff7;
            background: #091b14;
            box-shadow: 0 8px 24px rgba(0,0,0,.18);
          }
          .print-toolbar strong { font-size: 14px; }
          .print-toolbar span {
            color: #a8b5af;
            font-size: 11px;
            font-weight: 750;
          }
          .print-toolbar button {
            padding: 9px 14px;
            border: 0;
            border-radius: 7px;
            color: #06120d;
            background: #c9f45c;
            font-weight: 900;
            cursor: pointer;
          }
          .print-page {
            width: 10.6in;
            min-height: 7.3in;
            margin: 18px auto;
            padding: .22in;
            display: grid;
            grid-template-rows: auto 1fr auto;
            break-after: page;
            page-break-after: always;
            border: 1px solid #d9d7cd;
            border-radius: 12px;
            background: #fffdf7;
            box-shadow: 0 16px 45px rgba(11,30,22,.12);
          }
          .print-page.dragging {
            opacity: .45;
          }
          .print-page.drop-before {
            box-shadow: 0 -10px 0 #c9f45c, 0 16px 45px rgba(11,30,22,.12);
          }
          .print-page.drop-after {
            box-shadow: 0 10px 0 #c9f45c, 0 16px 45px rgba(11,30,22,.12);
          }
          .print-page-controls {
            margin: -2px 0 8px;
            display: flex;
            align-items: center;
            gap: 6px;
            color: #66736d;
            font-size: 9px;
            font-weight: 900;
            text-transform: uppercase;
          }
          .print-page-handle {
            padding: 5px 9px;
            border-radius: 999px;
            color: #06120d;
            background: #c9f45c;
            cursor: grab;
          }
          .print-page-controls button {
            padding: 5px 8px;
            border: 1px solid #d9d7cd;
            border-radius: 999px;
            color: #174c35;
            background: #fff;
            font-size: 9px;
            font-weight: 900;
            cursor: pointer;
          }
          .print-page:last-child {
            break-after: auto;
            page-break-after: auto;
          }
          header {
            margin-bottom: 8px;
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 16px;
          }
          header p {
            margin: 0 0 2px;
            color: #66736d;
            font-size: 10px;
            font-weight: 950;
            letter-spacing: .14em;
            text-transform: uppercase;
          }
          h1 {
            margin: 0;
            font: 800 24px Georgia, serif;
          }
          header span {
            color: #66736d;
            font-size: 9px;
            font-weight: 900;
            text-transform: uppercase;
          }
          main {
            min-height: 0;
            border: 5px solid #ffffff;
            border-radius: 10px;
            overflow: hidden;
            background: #174c35;
          }
          svg {
            width: 100%;
            height: 100%;
            min-height: 5.72in;
            display: block;
          }
          .print-note {
            width: 100%;
            height: 100%;
            overflow: hidden;
            color: #10231c;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
            font: 800 12px/1.3 Arial, sans-serif;
          }
          footer {
            margin-top: 8px;
            padding: 8px 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px 12px;
            border: 1px solid #dce8bc;
            border-radius: 8px;
            color: #10231c;
            background: #f4fadf;
            font-size: 10px;
          }
          footer strong { color: #174c35; text-transform: uppercase; letter-spacing: .12em; }
          @media print {
            body { background: #fff; }
            .print-toolbar { display: none; }
            .print-page-controls { display: none; }
            .print-page {
              width: auto;
              min-height: auto;
              margin: 0;
              border: 0;
              border-radius: 0;
              box-shadow: none;
            }
            main { min-height: 5.55in; }
          }
        </style>
      </head>
      <body>
        <div class="print-toolbar">
          <div>
            <strong>${selectedPlays.length} ${selectedPlays.length === 1 ? "play" : "plays"} ready</strong>
            <span>Drag pages or use Up/Down to set the order before printing.</span>
          </div>
          <button onclick="window.print()">Print / Save PDF</button>
        </div>
        ${selectedPlays.map(play => printablePlayDiagramMarkup(play, options)).join("")}
        <script>
          (() => {
            let draggedPage = null;
            const pages = () => [...document.querySelectorAll(".print-page")];
            function clearDropClasses() {
              pages().forEach(page => page.classList.remove("drop-before", "drop-after"));
            }
            function movePage(page, direction) {
              if (!page) return;
              if (direction === "up" && page.previousElementSibling?.classList.contains("print-page")) {
                page.parentNode.insertBefore(page, page.previousElementSibling);
              }
              if (direction === "down" && page.nextElementSibling?.classList.contains("print-page")) {
                page.parentNode.insertBefore(page.nextElementSibling, page);
              }
              page.scrollIntoView({ block: "center" });
            }
            document.addEventListener("click", event => {
              const button = event.target.closest("[data-move-page]");
              if (!button) return;
              movePage(button.closest(".print-page"), button.dataset.movePage);
            });
            document.addEventListener("dragstart", event => {
              const page = event.target.closest(".print-page");
              if (!page) return;
              draggedPage = page;
              page.classList.add("dragging");
              event.dataTransfer.effectAllowed = "move";
            });
            document.addEventListener("dragover", event => {
              const page = event.target.closest(".print-page");
              if (!page || !draggedPage || page === draggedPage) return;
              event.preventDefault();
              const rect = page.getBoundingClientRect();
              const before = event.clientY < rect.top + rect.height / 2;
              clearDropClasses();
              page.classList.add(before ? "drop-before" : "drop-after");
            });
            document.addEventListener("drop", event => {
              const page = event.target.closest(".print-page");
              if (!page || !draggedPage || page === draggedPage) return;
              event.preventDefault();
              const rect = page.getBoundingClientRect();
              const before = event.clientY < rect.top + rect.height / 2;
              page.parentNode.insertBefore(draggedPage, before ? page : page.nextSibling);
              clearDropClasses();
            });
            document.addEventListener("dragend", () => {
              draggedPage?.classList.remove("dragging");
              draggedPage = null;
              clearDropClasses();
            });
          })();
        </script>
      </body>
    </html>`;
}

function openPrintablePlaybook() {
  const selectedPlays = selectedPrintPlayIds();
  if (!selectedPlays.length) {
    window.alert("Choose at least one play to print.");
    return;
  }
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    window.alert("Your browser blocked the print window. Allow popups for this site and try again.");
    return;
  }
  const options = {
    hideNotes: Boolean(els.playbookLibrary.querySelector("#printHideNotesInput")?.checked)
  };
  printWindow.document.open();
  printWindow.document.write(printablePlaybookDocumentMarkup(selectedPlays, options));
  printWindow.document.close();
  printWindow.focus();
}

function allFilesBrowserMarkup() {
  const formationFolders = [...formations]
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(formation => {
      const formationPlays = plays
        .filter(play => play.formationId === formation.id)
        .sort((a, b) => a.name.localeCompare(b.name));
      return `
        <details class="library-folder formation-folder all-files-folder" data-library-folder-state="formation:${formation.id}"${libraryFolderOpenAttribute(`formation:${formation.id}`)}>
          <summary data-library-formation-summary="${formation.id}">
            <span class="library-folder-icon">F</span>
            <span class="library-folder-preview-button ${libraryPreview.type === "formation" && libraryPreview.id === formation.id ? "active" : ""}">${escapeHtml(formation.name)}</span>
            <small>${formationPlays.length} ${formationPlays.length === 1 ? "play" : "plays"}</small>
          </summary>
          <div class="library-folder-actions">
            <button class="library-action-button" data-edit-formation="${formation.id}">Edit Formation</button>
            <button class="library-action-button danger" data-delete-formation="${formation.id}" ${formations.length === 1 || formationPlays.length ? "disabled" : ""}>Delete Formation</button>
          </div>
          <div class="library-folder-content">
            ${formationPlays.length
              ? formationPlays.map(play => `
                <div class="library-file-row">
                  <button class="library-file ${libraryPreview.type === "play" && libraryPreview.id === play.id ? "active" : ""}" data-library-play="${play.id}">
                    <span class="library-file-icon">P</span>
                    <span>${escapeHtml(play.name)}</span>
                  </button>
                  <button class="library-action-button" data-edit-play="${play.id}">Edit</button>
                  <button class="library-action-button danger" data-delete-play="${play.id}" ${plays.length === 1 ? "disabled" : ""}>Delete</button>
                </div>
              `).join("")
              : `<p class="library-empty">No plays saved in this formation yet.</p>`}
          </div>
        </details>
      `;
    }).join("");

  const unassignedPlays = plays
    .filter(play => !formations.some(formation => formation.id === play.formationId))
    .sort((a, b) => a.name.localeCompare(b.name));

  return `
    <section class="all-files-browser">
      <div class="custom-folder-heading">
        <div>
          <p class="eyebrow">Complete library</p>
          <h3>All Files</h3>
          <p class="custom-folder-help">Every formation, play, and defense saved in your playbook.</p>
        </div>
      </div>
      ${formationFolders || `<p class="library-empty">No formations saved yet.</p>`}
      ${unassignedPlays.length ? `
        <details class="library-folder all-plays-folder all-files-folder" data-library-folder-state="unassigned-plays"${libraryFolderOpenAttribute("unassigned-plays")}>
          <summary>
            <span class="library-folder-icon">P</span>
            <span>Plays Without Formation</span>
            <small>${unassignedPlays.length}</small>
          </summary>
          <div class="library-folder-content">
            ${unassignedPlays.map(play => `
                <div class="library-file-row">
                  <button class="library-file ${libraryPreview.type === "play" && libraryPreview.id === play.id ? "active" : ""}" data-library-play="${play.id}">
                    <span class="library-file-icon">P</span>
                    <span>${escapeHtml(play.name)}</span>
                  </button>
                  <button class="library-action-button" data-edit-play="${play.id}">Edit</button>
                  <button class="library-action-button danger" data-delete-play="${play.id}" ${plays.length === 1 ? "disabled" : ""}>Delete</button>
                </div>
              `).join("")}
          </div>
        </details>
      ` : ""}
      <details class="library-folder defense-files-folder all-files-folder" data-library-folder-state="defenses"${libraryFolderOpenAttribute("defenses")}>
        <summary>
          <span class="library-folder-icon">D</span>
          <span>Defenses</span>
          <small>${defenses.length} ${defenses.length === 1 ? "defense" : "defenses"}</small>
        </summary>
        <div class="library-folder-content">
          ${defenses.length
            ? defenses
                .slice()
                .sort((a, b) => a.name.localeCompare(b.name))
                .map(defense => `
                  <div class="library-file-row">
                    <button class="library-file defense-file ${libraryPreview.type === "defense" && libraryPreview.id === defense.id ? "active" : ""}" data-library-defense="${defense.id}">
                      <span class="library-file-icon">D</span>
                      <span>${escapeHtml(defense.name)}</span>
                    </button>
                    <button class="library-action-button" data-edit-defense="${defense.id}">Edit</button>
                    <button class="library-action-button danger" data-delete-defense="${defense.id}" ${defenses.length === 1 ? "disabled" : ""}>Delete</button>
                  </div>
                `).join("")
            : `<p class="library-empty">No defenses saved yet.</p>`}
        </div>
      </details>
    </section>
  `;
}

function playbookSearchResultsMarkup() {
  const query = normalizedPlaybookSearch();
  const matchingFormations = formations
    .filter(formationMatchesPlaybookSearch)
    .sort((a, b) => a.name.localeCompare(b.name));
  const matchingPlays = plays
    .filter(playMatchesPlaybookSearch)
    .sort((a, b) => {
      const formationCompare = playFormationName(a).localeCompare(playFormationName(b));
      return formationCompare || a.name.localeCompare(b.name);
    });
  return `
    <section class="all-files-browser search-results-browser">
      <div class="custom-folder-heading">
        <div>
          <p class="eyebrow">Search results</p>
          <h3>${matchingFormations.length + matchingPlays.length} Result${matchingFormations.length + matchingPlays.length === 1 ? "" : "s"} Found</h3>
          <p class="custom-folder-help">Showing saved formations and plays that match "${escapeHtml(query)}".</p>
        </div>
      </div>
      ${matchingFormations.length
        ? `<p class="folder-picker-heading">Formations</p>${matchingFormations.map(formationLibraryRowMarkup).join("")}`
        : ""}
      ${matchingPlays.length
        ? `<p class="folder-picker-heading">Plays</p>${matchingPlays.map(playLibraryRowMarkup).join("")}`
        : ""}
      ${!matchingFormations.length && !matchingPlays.length
        ? `<p class="library-empty">No formations or plays match that search yet.</p>`
        : ""}
    </section>
  `;
}

function selectLibraryPreview(type, id, context = null) {
  const pageScroll = {
    x: window.scrollX,
    y: window.scrollY
  };
  const fileBrowser = els.playbookLibrary.querySelector(".library-files");
  const fileBrowserScroll = {
    left: fileBrowser?.scrollLeft || 0,
    top: fileBrowser?.scrollTop || 0
  };

  if (document.activeElement instanceof HTMLElement) {
    document.activeElement.blur();
  }
  libraryPreview = { type, id };
  libraryPreviewContext = type === "play" ? context : null;
  renderPlaybookLibrary();

  const restoreScroll = () => {
    const updatedFileBrowser = els.playbookLibrary.querySelector(".library-files");
    if (updatedFileBrowser) {
      updatedFileBrowser.scrollLeft = fileBrowserScroll.left;
      updatedFileBrowser.scrollTop = fileBrowserScroll.top;
    }
    window.scrollTo(pageScroll.x, pageScroll.y);
  };
  restoreScroll();
  requestAnimationFrame(restoreScroll);
}

function libraryPreviewFolderPlays() {
  if (libraryPreview.type !== "play" || libraryPreviewContext?.type !== "folder") return [];
  const folder = libraryFolders.find(candidate => candidate.id === libraryPreviewContext.folderId);
  if (!folder) return [];
  return sortedFolderItems(folder)
    .filter(item => item.type === "play")
    .map(item => plays.find(play => play.id === item.id))
    .filter(Boolean);
}

function libraryPreviewNavigation() {
  const folderPlays = libraryPreviewFolderPlays();
  const index = folderPlays.findIndex(play => play.id === libraryPreview.id);
  if (index < 0 || folderPlays.length < 2) return null;
  return {
    folderPlays,
    previous: folderPlays[index - 1] || null,
    next: folderPlays[index + 1] || null,
    index
  };
}

function stepLibraryPreview(direction) {
  const navigation = libraryPreviewNavigation();
  if (!navigation) return false;
  const target = direction === "previous"
    ? navigation.previous
    : navigation.next;
  if (!target) return false;
  selectLibraryPreview("play", target.id, libraryPreviewContext);
  return true;
}

function renderPlaybookLibrary() {
  rememberLibraryFolderState();
  els.playbookLibrary.innerHTML = `
    <div class="library-heading">
      <div>
        <p class="eyebrow">Saved files</p>
        <h2>Your Playbook</h2>
        <p>Open any saved play or defense to review and edit it.</p>
        <p class="autosave-status">Autosaved in this browser${
          localStorage.getItem(storageKeys.savedAt)
            ? ` • Last saved ${escapeHtml(new Date(localStorage.getItem(storageKeys.savedAt)).toLocaleString())}`
            : ""
        }. Download a backup before clearing browser data or changing computers.</p>
      </div>
      <div class="library-heading-actions">
        <div class="library-counts">
          <span><strong>${formations.length}</strong> Formations</span>
          <span><strong>${plays.length}</strong> Plays</span>
          <span><strong>${defenses.length}</strong> Defenses</span>
        </div>
        <div class="library-transfer-actions">
          <button id="printPlaybookButton" class="library-action-button">Print Playbook</button>
          <button id="saveBackupNowButton" class="library-action-button">Save Backup Now</button>
          <button id="exportPlaybookButton" class="library-action-button">Download Backup</button>
          <button id="restoreBackupButton" class="library-action-button">Restore Previous Backup</button>
          <label class="library-action-button import-playbook-button">
            Import Playbook
            <input id="importPlaybookInput" type="file" accept=".json,application/json">
          </label>
        </div>
      </div>
    </div>
    <div class="playbook-tabs" role="tablist" aria-label="Playbook sections">
      <button
        class="playbook-tab ${playbookTab === "all" ? "active" : ""}"
        data-playbook-section="all"
        role="tab"
        aria-selected="${playbookTab === "all" ? "true" : "false"}"
      >All Files</button>
      <button
        class="playbook-tab ${playbookTab === "folders" ? "active" : ""}"
        data-playbook-section="folders"
        role="tab"
        aria-selected="${playbookTab === "folders" ? "true" : "false"}"
      >My Folders</button>
    </div>
    <div class="playbook-search">
      <label for="playbookSearchInput">Search plays</label>
      <div class="playbook-search-row">
        <input
          id="playbookSearchInput"
          type="search"
          placeholder="Search by play or formation..."
          value="${escapeHtml(playbookSearchQuery)}"
          autocomplete="off"
        >
        <button class="library-action-button" data-clear-playbook-search ${playbookSearchQuery ? "" : "disabled"}>Clear</button>
      </div>
    </div>
    ${printPlaybookPanelMarkup()}
    ${folderPickerPanelMarkup()}
    <div class="library-browser">
      <div class="library-files">
        ${normalizedPlaybookSearch()
          ? playbookSearchResultsMarkup()
          : playbookTab === "all"
            ? allFilesBrowserMarkup()
            : customFolderBrowserMarkup()}
      </div>
      <div class="library-preview">${libraryPreviewMarkup()}</div>
    </div>
  `;

  const searchInput = els.playbookLibrary.querySelector("#playbookSearchInput");
  searchInput?.addEventListener("input", () => {
    playbookSearchQuery = searchInput.value;
    renderPlaybookLibrary();
    requestAnimationFrame(() => {
      const updatedInput = els.playbookLibrary.querySelector("#playbookSearchInput");
      if (!updatedInput) return;
      updatedInput.focus();
      updatedInput.setSelectionRange(updatedInput.value.length, updatedInput.value.length);
    });
  });
  els.playbookLibrary.querySelector("[data-clear-playbook-search]")
    ?.addEventListener("click", () => {
      playbookSearchQuery = "";
      renderPlaybookLibrary();
    });

  els.playbookLibrary.querySelectorAll("[data-playbook-section]").forEach(button => {
    button.addEventListener("click", () => {
      playbookTab = button.dataset.playbookSection;
      if (playbookTab !== "folders") activeFolderPickerId = null;
      renderPlaybookLibrary();
    });
  });

  els.playbookLibrary.querySelectorAll("[data-library-play]").forEach(button => {
    button.addEventListener("click", () => {
      selectLibraryPreview(
        "play",
        button.dataset.libraryPlay,
        button.dataset.libraryFolderContext
          ? { type: "folder", folderId: button.dataset.libraryFolderContext }
          : null
      );
    });
  });

  els.playbookLibrary.querySelectorAll("[data-library-formation-summary]").forEach(summary => {
    summary.addEventListener("click", event => {
      const folder = summary.closest("details");
      if (folder) {
        event.preventDefault();
        folder.open = !folder.open;
        if (folder.dataset.libraryFolderState) {
          libraryFolderOpenState.set(folder.dataset.libraryFolderState, folder.open);
        }
      }
      selectLibraryPreview("formation", summary.dataset.libraryFormationSummary);
    });
  });

  els.playbookLibrary.querySelectorAll("[data-library-formation]").forEach(button => {
    button.addEventListener("click", () => {
      selectLibraryPreview("formation", button.dataset.libraryFormation);
    });
  });

  els.playbookLibrary.querySelectorAll("[data-library-defense]").forEach(button => {
    button.addEventListener("click", () => {
      selectLibraryPreview("defense", button.dataset.libraryDefense);
    });
  });

  els.playbookLibrary.querySelectorAll("[data-library-preview-step]").forEach(button => {
    button.addEventListener("click", () => {
      stepLibraryPreview(button.dataset.libraryPreviewStep);
    });
  });

  els.playbookLibrary.querySelectorAll("[data-edit-play]").forEach(button => {
    button.addEventListener("click", () => openPlayEditor(button.dataset.editPlay));
  });

  els.playbookLibrary.querySelectorAll("[data-edit-formation]").forEach(button => {
    button.addEventListener("click", () => openFormationEditor(button.dataset.editFormation));
  });

  els.playbookLibrary.querySelectorAll("[data-edit-defense]").forEach(button => {
    button.addEventListener("click", () => openDefenseEditor(button.dataset.editDefense));
  });

  els.playbookLibrary.querySelectorAll("[data-delete-play]").forEach(button => {
    button.addEventListener("click", () => deleteSavedPlay(button.dataset.deletePlay));
  });

  els.playbookLibrary.querySelectorAll("[data-delete-formation]").forEach(button => {
    button.addEventListener("click", () => deleteSavedFormation(button.dataset.deleteFormation));
  });

  els.playbookLibrary.querySelectorAll("[data-delete-defense]").forEach(button => {
    button.addEventListener("click", () => deleteSavedDefense(button.dataset.deleteDefense));
  });

  els.playbookLibrary.querySelector("#addRootFolderButton")
    ?.addEventListener("click", () => createLibraryFolder(null));
  els.playbookLibrary.querySelectorAll("[data-add-subfolder]").forEach(button => {
    button.addEventListener("click", () => createLibraryFolder(button.dataset.addSubfolder));
  });
  els.playbookLibrary.querySelectorAll("[data-open-folder-picker]").forEach(button => {
    button.addEventListener("click", () => {
      activeFolderPickerId = button.dataset.openFolderPicker;
      activeFolderPickerSearch = "";
      playbookTab = "folders";
      renderPlaybookLibrary();
    });
  });
  els.playbookLibrary.querySelectorAll("[data-rename-folder]").forEach(button => {
    button.addEventListener("click", () => renameLibraryFolder(button.dataset.renameFolder));
  });
  els.playbookLibrary.querySelectorAll("[data-delete-folder]").forEach(button => {
    button.addEventListener("click", () => deleteLibraryFolder(button.dataset.deleteFolder));
  });
  els.playbookLibrary.querySelectorAll("[data-toggle-folder-item]").forEach(button => {
    button.addEventListener("click", event => {
      event.stopPropagation();
    });
    button.addEventListener("click", () => {
      const included = button.dataset.folderIncluded === "true";
      setItemFolderMembership(
        button.dataset.toggleFolderItem,
        button.dataset.folderId,
        !included
      );
      lastSavedSignature = "";
      persistPlaybook();
      renderPlaybookLibrary();
      showSaveSuccess(included ? "Removed from folder" : "Added to folder");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-toggle-formation-plays]").forEach(button => {
    button.addEventListener("click", () => {
      const included = button.dataset.folderIncluded === "true";
      const visiblePlayIds = (button.dataset.folderVisiblePlayIds || "")
        .split(",")
        .filter(Boolean);
      const targetPlays = visiblePlayIds.length
        ? plays.filter(play => visiblePlayIds.includes(play.id))
        : plays.filter(play => play.formationId === button.dataset.toggleFormationPlays);
      targetPlays
        .forEach(play => {
          setItemFolderMembership(
            libraryItemKey("play", play.id),
            button.dataset.folderId,
            !included
          );
        });
      lastSavedSignature = "";
      persistPlaybook();
      renderPlaybookLibrary();
      showSaveSuccess(included ? "Formation plays removed from folder" : "Formation plays added to folder");
    });
  });
  const folderPickerSearchInput = els.playbookLibrary.querySelector("#folderPickerSearchInput");
  folderPickerSearchInput?.addEventListener("input", () => {
    activeFolderPickerSearch = folderPickerSearchInput.value;
    renderPlaybookLibrary();
    requestAnimationFrame(() => {
      const updatedInput = els.playbookLibrary.querySelector("#folderPickerSearchInput");
      if (!updatedInput) return;
      updatedInput.focus();
      updatedInput.setSelectionRange(updatedInput.value.length, updatedInput.value.length);
    });
  });
  els.playbookLibrary.querySelector("[data-clear-folder-picker-search]")
    ?.addEventListener("click", () => {
      activeFolderPickerSearch = "";
      renderPlaybookLibrary();
    });
  els.playbookLibrary.querySelectorAll("[data-folder-membership]").forEach(input => {
    input.addEventListener("click", event => {
      if (input.closest("summary")) event.stopPropagation();
    });
    input.addEventListener("change", () => {
      setItemFolderMembership(
        input.dataset.membershipItem,
        input.dataset.folderMembership,
        input.checked
      );
      lastSavedSignature = "";
      persistPlaybook();
      updateFormationPickerState(input);
      showSaveSuccess("Folder membership updated");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-folder-formation-plays-membership]").forEach(input => {
    const formationPlays = plays.filter(
      play => play.formationId === input.dataset.membershipFormation
    );
    const selectedCount = formationPlays.filter(play =>
      itemFolderIds(libraryItemKey("play", play.id))
        .includes(input.dataset.folderFormationPlaysMembership)
    ).length;
    input.indeterminate = selectedCount > 0 && selectedCount < formationPlays.length;
    input.addEventListener("click", event => event.stopPropagation());
    input.addEventListener("change", () => {
      formationPlays.forEach(play => {
        setItemFolderMembership(
          libraryItemKey("play", play.id),
          input.dataset.folderFormationPlaysMembership,
          input.checked
        );
      });
      const group = input.closest(".folder-formation-picker");
      group?.querySelectorAll("[data-folder-membership][data-membership-item^='play:']").forEach(playInput => {
        playInput.checked = input.checked;
      });
      updateFormationPickerState(input);
      lastSavedSignature = "";
      persistPlaybook();
      showSaveSuccess(
        input.checked
          ? "Formation plays added to folder"
          : "Formation plays removed from folder"
      );
    });
  });
  els.playbookLibrary.querySelectorAll("[data-close-folder-picker]").forEach(button => {
    button.addEventListener("click", () => {
      if (button.closest(".folder-picker-panel")) {
        activeFolderPickerId = null;
        renderPlaybookLibrary();
        return;
      }
      const editor = button.closest(".folder-membership-editor");
      if (editor) editor.open = false;
      renderPlaybookLibrary();
    });
  });
  els.playbookLibrary.querySelectorAll(".folder-membership-editor").forEach(editor => {
    editor.addEventListener("toggle", () => {
      if (!editor.open) renderPlaybookLibrary();
    });
  });
  els.playbookLibrary.querySelectorAll("[data-remove-folder-item]").forEach(button => {
    button.addEventListener("click", () => {
      setItemFolderMembership(
        button.dataset.removeFolderItem,
        button.dataset.removeFromFolder,
        false
      );
      lastSavedSignature = "";
      persistPlaybook();
      renderPlaybookLibrary();
      showSaveSuccess("Removed from folder");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-drag-folder-item]").forEach(handle => {
    handle.addEventListener("click", event => event.stopPropagation());
    handle.addEventListener("dragstart", event => {
      const row = handle.closest(".custom-library-file");
      event.stopPropagation();
      event.dataTransfer.effectAllowed = "move";
      setLibraryDragData(event, {
        kind: "folder-item",
        key: handle.dataset.dragFolderItem,
        folderId: handle.dataset.dragFolderItemFolder
      });
      row?.classList.add("dragging");
    });
    handle.addEventListener("dragend", () => {
      clearLibraryDropIndicators();
      handle.closest(".custom-library-file")?.classList.remove("dragging");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-drag-library-folder]").forEach(handle => {
    handle.addEventListener("click", event => event.stopPropagation());
    handle.addEventListener("dragstart", event => {
      const folder = handle.closest(".custom-library-folder");
      event.stopPropagation();
      event.dataTransfer.effectAllowed = "move";
      setLibraryDragData(event, {
        kind: "folder",
        folderId: handle.dataset.dragLibraryFolder
      });
      folder?.classList.add("dragging");
    });
    handle.addEventListener("dragend", () => {
      clearLibraryDropIndicators();
      handle.closest(".custom-library-folder")?.classList.remove("dragging");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-folder-item-row]").forEach(row => {
    row.addEventListener("dragover", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      showRowDropIndicator(row, event);
    });
    row.addEventListener("dragleave", event => {
      if (!row.contains(event.relatedTarget)) row.classList.remove("drop-before", "drop-after");
    });
    row.addEventListener("drop", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      event.preventDefault();
      event.stopPropagation();
      const placement = dropPlacement(row, event);
      reorderFolderItem(
        row.dataset.folderItemFolder,
        drag.key,
        row.dataset.folderItemRow,
        placement
      );
    });
  });
  els.playbookLibrary.querySelectorAll("[data-folder-row]").forEach(row => {
    row.addEventListener("dragover", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder") return;
      const targetFolder = libraryFolders.find(folder => folder.id === row.dataset.folderRow);
      const draggedFolder = libraryFolders.find(folder => folder.id === drag.folderId);
      if (!targetFolder || !draggedFolder || targetFolder.parentId !== draggedFolder.parentId) return;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      showRowDropIndicator(row, event);
    });
    row.addEventListener("dragleave", event => {
      if (!row.contains(event.relatedTarget)) row.classList.remove("drop-before", "drop-after");
    });
    row.addEventListener("drop", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder") return;
      event.preventDefault();
      event.stopPropagation();
      const placement = dropPlacement(row, event);
      reorderLibraryFolder(drag.folderId, row.dataset.folderRow, placement);
    });
  });
  els.playbookLibrary.querySelectorAll("[data-folder-content]").forEach(content => {
    content.addEventListener("dragover", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      content.classList.add("drop-at-end");
    });
    content.addEventListener("dragleave", event => {
      if (!content.contains(event.relatedTarget)) content.classList.remove("drop-at-end");
    });
    content.addEventListener("drop", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      event.preventDefault();
      event.stopPropagation();
      reorderFolderItem(content.dataset.folderContent, drag.key, null, "after");
    });
  });
  els.playbookLibrary.querySelectorAll("[data-folder-drop]").forEach(folder => {
    folder.addEventListener("dragover", event => {
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      folder.classList.add("drop-target");
    });
    folder.addEventListener("dragleave", event => {
      if (!folder.contains(event.relatedTarget)) folder.classList.remove("drop-target");
    });
    folder.addEventListener("drop", event => {
      event.preventDefault();
      event.stopPropagation();
      const drag = libraryDragData(event);
      if (drag?.kind !== "folder-item") return;
      const key = drag.key;
      const folderId = folder.dataset.folderDrop;
      if (!key || !folderId) return;
      setItemFolderMembership(key, folderId, true);
      lastSavedSignature = "";
      persistPlaybook();
      renderPlaybookLibrary();
      showSaveSuccess("Added to folder");
    });
  });

  els.playbookLibrary.querySelector("#exportPlaybookButton")
    ?.addEventListener("click", exportPlaybook);
  els.playbookLibrary.querySelector("#printPlaybookButton")
    ?.addEventListener("click", () => {
      printPlaybookOpen = !printPlaybookOpen;
      renderPlaybookLibrary();
    });
  els.playbookLibrary.querySelector("[data-close-print-playbook]")
    ?.addEventListener("click", () => {
      printPlaybookOpen = false;
      renderPlaybookLibrary();
    });
  els.playbookLibrary.querySelector("[data-generate-print-playbook]")
    ?.addEventListener("click", openPrintablePlaybook);
  els.playbookLibrary.querySelectorAll(".print-playbook-check input").forEach(input => {
    input.addEventListener("click", event => event.stopPropagation());
  });
  els.playbookLibrary.querySelector("#saveBackupNowButton")
    ?.addEventListener("click", () => {
      lastSavedSignature = "";
      persistPlaybook();
      showSaveSuccess("Backup snapshot saved");
      renderPlaybookLibrary();
    });
  els.playbookLibrary.querySelector("#restoreBackupButton")
    ?.addEventListener("click", restorePreviousBackup);
  els.playbookLibrary.querySelector("#importPlaybookInput")
    ?.addEventListener("change", importPlaybook);
}

function createLibraryFolder(parentId) {
  const parent = parentId
    ? libraryFolders.find(folder => folder.id === parentId)
    : null;
  const name = window.prompt(
    parent ? `Name the subfolder inside "${parent.name}":` : "Name the new playbook folder:"
  )?.trim();
  if (!name) return;
  libraryFolders.push({
    id: crypto.randomUUID(),
    name: name.slice(0, 50),
    parentId: parent?.id || null,
    order: libraryFolderChildren(parent?.id || null).length,
    itemOrder: []
  });
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder created");
}

function renameLibraryFolder(folderId) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder) return;
  const name = window.prompt("Rename folder:", folder.name)?.trim();
  if (!name) return;
  folder.name = name.slice(0, 50);
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder renamed");
}

function moveLibraryFolder(folderId, direction) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder) return;
  const parentId = folder.parentId || null;
  normalizeFolderSiblingOrder(parentId);
  const siblings = libraryFolderChildren(parentId);
  const currentIndex = siblings.findIndex(candidate => candidate.id === folderId);
  const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
  if (currentIndex < 0 || targetIndex < 0 || targetIndex >= siblings.length) return;
  const currentOrder = siblings[currentIndex].order;
  siblings[currentIndex].order = siblings[targetIndex].order;
  siblings[targetIndex].order = currentOrder;
  normalizeFolderSiblingOrder(parentId);
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder order updated");
}

function moveFolderItem(folderId, key, direction) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder) return;
  const orderedKeys = sortedFolderItems(folder).map(item => libraryItemKey(item.type, item.id));
  const currentIndex = orderedKeys.indexOf(key);
  const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
  if (currentIndex < 0 || targetIndex < 0 || targetIndex >= orderedKeys.length) return;
  [orderedKeys[currentIndex], orderedKeys[targetIndex]] = [orderedKeys[targetIndex], orderedKeys[currentIndex]];
  folder.itemOrder = orderedKeys;
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder item order updated");
}

function setLibraryDragData(event, data) {
  libraryDragState = data;
  event.dataTransfer.setData("application/readroute-library-drag", JSON.stringify(data));
  if (data.key) event.dataTransfer.setData("text/plain", data.key);
}

function libraryDragData(event) {
  if (libraryDragState) return libraryDragState;
  try {
    const data = event.dataTransfer.getData("application/readroute-library-drag");
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

function clearLibraryDropIndicators() {
  libraryDragState = null;
  els.playbookLibrary
    ?.querySelectorAll(".drop-before, .drop-after, .drop-at-end, .drop-target, .dragging")
    .forEach(element => element.classList.remove(
      "drop-before",
      "drop-after",
      "drop-at-end",
      "drop-target",
      "dragging"
    ));
}

function dropPlacement(row, event) {
  const rect = row.getBoundingClientRect();
  return event.clientY < rect.top + (rect.height / 2) ? "before" : "after";
}

function showRowDropIndicator(row, event) {
  row.classList.remove("drop-before", "drop-after");
  row.classList.add(dropPlacement(row, event) === "before" ? "drop-before" : "drop-after");
}

function reorderFolderItem(folderId, key, targetKey, placement) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder || !key) return;
  setItemFolderMembership(key, folderId, true);
  let orderedKeys = sortedFolderItems(folder)
    .map(item => libraryItemKey(item.type, item.id))
    .filter(itemKey => itemKey !== key);
  if (targetKey && orderedKeys.includes(targetKey)) {
    const targetIndex = orderedKeys.indexOf(targetKey);
    orderedKeys.splice(placement === "before" ? targetIndex : targetIndex + 1, 0, key);
  } else {
    orderedKeys.push(key);
  }
  folder.itemOrder = orderedKeys;
  clearLibraryDropIndicators();
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder order updated");
}

function reorderLibraryFolder(folderId, targetFolderId, placement) {
  if (!folderId || !targetFolderId || folderId === targetFolderId) return;
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  const target = libraryFolders.find(candidate => candidate.id === targetFolderId);
  if (!folder || !target || (folder.parentId || null) !== (target.parentId || null)) return;
  const parentId = folder.parentId || null;
  let siblings = libraryFolderChildren(parentId).filter(candidate => candidate.id !== folderId);
  const targetIndex = siblings.findIndex(candidate => candidate.id === targetFolderId);
  if (targetIndex < 0) return;
  siblings.splice(placement === "before" ? targetIndex : targetIndex + 1, 0, folder);
  siblings.forEach((candidate, index) => {
    candidate.order = index;
  });
  clearLibraryDropIndicators();
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder order updated");
}

function deleteLibraryFolder(folderId) {
  const folder = libraryFolders.find(candidate => candidate.id === folderId);
  if (!folder || !window.confirm(
    `Delete folder "${folder.name}" only? No plays, formations, or defenses will be deleted.`
  )) return;
  const destinationId = folder.parentId || null;
  libraryFolders.forEach(candidate => {
    if (candidate.parentId === folderId) candidate.parentId = destinationId;
  });
  Object.keys(libraryAssignments).forEach(key => {
    const currentMemberships = itemFolderIds(key);
    if (!currentMemberships.includes(folderId)) return;
    const memberships = currentMemberships.filter(id => id !== folderId);
    if (memberships.length) libraryAssignments[key] = memberships;
    else delete libraryAssignments[key];
  });
  libraryFolders = libraryFolders.filter(candidate => candidate.id !== folderId);
  if (activeFolderPickerId === folderId) activeFolderPickerId = null;
  lastSavedSignature = "";
  persistPlaybook();
  renderPlaybookLibrary();
  showSaveSuccess("Folder deleted. No plays were deleted");
}

function exportPlaybook() {
  const data = {
    version: 3,
    exportedAt: new Date().toISOString(),
    fieldStandard,
    formations,
    plays,
    defenses,
    libraryFolders,
    libraryAssignments,
    draftPlay
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  const date = new Date().toISOString().slice(0, 10);
  link.href = URL.createObjectURL(blob);
  link.download = `ReadRoute-Playbook-${date}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
  showSaveSuccess("Playbook exported");
}

function restorePreviousBackup() {
  const backup = readJsonStorage(storageKeys.previousSnapshot);
  if (!backup?.formations?.length || !backup?.plays?.length || !backup?.defenses?.length) {
    window.alert("There is no previous backup available yet.");
    return;
  }
  if (!window.confirm(`Restore the backup saved ${backup.savedAt
    ? new Date(backup.savedAt).toLocaleString()
    : "previously"}? Your current playbook will remain as the newest recovery snapshot.`)) return;
  const current = JSON.stringify(playbookSnapshot());
  localStorage.setItem(storageKeys.previousSnapshot, current);
  formations = backup.formations.map(formation => ({
    ...formation,
    labels: formation.labels || { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" },
    offensePositions: normalizedOffensePositions(formation.offensePositions),
    notes: Array.isArray(formation.notes) ? formation.notes : []
  }));
  plays = backup.plays.map(normalizePlay);
  defenses = backup.defenses.map(normalizeDefense);
  libraryFolders = normalizeLibraryFolders(backup.libraryFolders);
  libraryAssignments = normalizeLibraryAssignments(backup.libraryAssignments);
  draftPlay = null;
  selectedPlayId = plays[0].id;
  selectedFormationId = draftPlay?.formationId || plays[0].formationId || formations[0].id;
  selectedDefenseId = defenses[0].id;
  lastSavedSignature = "";
  persistPlaybook({ rotateBackup: false });
  renderPlayControls();
  render();
  showSaveSuccess("Previous backup restored");
}

async function importPlaybook(event) {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!Array.isArray(data.formations) || !data.formations.length
      || !Array.isArray(data.plays) || !data.plays.length
      || !Array.isArray(data.defenses) || !data.defenses.length) {
      throw new Error("This file does not contain a complete ReadRoute playbook.");
    }
    if (!window.confirm("Import this playbook? This will replace the playbook saved in this browser.")) return;
    formations = data.formations.map(formation => ({
      ...formation,
      labels: formation.labels || { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" },
      offensePositions: normalizedOffensePositions(formation.offensePositions),
      notes: Array.isArray(formation.notes) ? formation.notes : []
    }));
    plays = data.plays.map(normalizePlay);
    defenses = data.defenses.map(normalizeDefense);
    libraryFolders = normalizeLibraryFolders(data.libraryFolders);
    libraryAssignments = normalizeLibraryAssignments(data.libraryAssignments);
    draftPlay = data.draftPlay ? normalizePlay(data.draftPlay) : null;
    selectedPlayId = plays[0].id;
    selectedFormationId = plays[0].formationId || formations[0].id;
    selectedDefenseId = defenses[0].id;
    libraryPreview = { type: "play", id: selectedPlayId };
    if (fieldStandards[data.fieldStandard]) {
      fieldStandard = data.fieldStandard;
      localStorage.setItem("readroute-field-standard", fieldStandard);
    }
    lastSavedSignature = "";
    persistPlaybook();
    renderMarkings();
    renderPlayControls();
    render();
    showSaveSuccess("Playbook imported");
  } catch (error) {
    window.alert(error.message || "That playbook file could not be imported.");
  }
}

function openPlayEditor(playId) {
  preserveDraftBeforeReplacement();
  selectedPlayId = playId;
  selectedFormationId = currentPlay().formationId || formations[0].id;
  draftPlay = null;
  appTab = "create";
  createScreen = "play";
  activeRouteSide = "offense";
  activeRouteId = "X";
  boardMode = "draw";
  playPathType = "route";
  selectedRouteOptionId = "base";
  syncTabButtons();
  renderPlayControls();
  render();
}

function openFormationEditor(formationId) {
  selectedFormationId = formationId;
  appTab = "create";
  createScreen = "formation";
  activeRouteSide = "offense";
  activeRouteId = "X";
  boardMode = "move";
  syncTabButtons();
  renderPlayControls();
  render();
}

function openDefenseEditor(defenseId) {
  selectedDefenseId = defenseId;
  appTab = "create";
  createScreen = "defense";
  activeRouteSide = "defense";
  activeRouteId = "D0";
  boardMode = "move";
  defenseAssignmentMode = "path";
  syncTabButtons();
  renderPlayControls();
  render();
}

function deleteSavedPlay(playId) {
  if (plays.length === 1) return;
  const play = plays.find(item => item.id === playId);
  if (!play || !window.confirm(`Delete "${play.name}"?`)) return;
  plays = plays.filter(item => item.id !== playId);
  delete libraryAssignments[libraryItemKey("play", playId)];
  if (selectedPlayId === playId) selectedPlayId = plays[0].id;
  if (libraryPreview.type === "play" && libraryPreview.id === playId) {
    libraryPreview = { type: "play", id: plays[0].id };
  }
  selectedFormationId = currentPlay().formationId || formations[0].id;
  savePlays();
  renderPlayControls();
  render();
}

function deleteSavedFormation(formationId) {
  const formation = formations.find(item => item.id === formationId);
  if (!formation || formations.length === 1) return;
  if (plays.some(play => play.formationId === formationId)) {
    window.alert("Delete the plays inside this formation first.");
    return;
  }
  if (!window.confirm(`Delete formation "${formation.name}"?`)) return;
  formations = formations.filter(item => item.id !== formationId);
  defenses.forEach(defense => {
    if (defense.formationAlignments) delete defense.formationAlignments[formationId];
  });
  delete libraryAssignments[libraryItemKey("formation", formationId)];
  if (selectedFormationId === formationId) selectedFormationId = formations[0].id;
  if (defenseAlignmentFormationId === formationId) {
    defenseAlignmentFormationId = formations[0].id;
  }
  saveFormations();
  renderPlayControls();
  render();
}

function deleteSavedDefense(defenseId) {
  if (defenses.length === 1) return;
  const defense = defenses.find(item => item.id === defenseId);
  if (!defense || !window.confirm(`Delete "${defense.name}"?`)) return;
  defenses = defenses.filter(item => item.id !== defenseId);
  delete libraryAssignments[libraryItemKey("defense", defenseId)];
  [...plays, ...(draftPlay ? [draftPlay] : [])].forEach(play => {
    skillPositions.forEach(position => {
      routeOptionsFor(play, position.id).forEach(option => {
        option.defenseIds = option.defenseIds.filter(id => id !== defenseId);
      });
    });
  });
  if (selectedDefenseId === defenseId) selectedDefenseId = defenses[0].id;
  if (libraryPreview.type === "defense" && libraryPreview.id === defenseId) {
    libraryPreview = { type: "defense", id: defenses[0].id };
  }
  saveDefenses();
  savePlays();
  renderPlayControls();
  render();
}

function libraryFieldMarkingsMarkup() {
  const pixelsPerYard = 900 / (160 / 3);
  const pixelsPerFoot = 900 / 160;
  const standard = fieldStandards[fieldStandard];
  const hashLeft = standard.hashFromSidelineFeet * pixelsPerFoot;
  const hashRight = 900 - hashLeft;
  const numberLeft = standard.numberCenterFromSidelineFeet * pixelsPerFoot;
  const numberRight = 900 - numberLeft;
  const markings = [
    `<line x1="2" y1="0" x2="2" y2="${fieldHeight}" stroke="rgba(255,255,255,.8)" stroke-width="4"></line>`,
    `<line x1="898" y1="0" x2="898" y2="${fieldHeight}" stroke="rgba(255,255,255,.8)" stroke-width="4"></line>`
  ];

  for (let yard = -13; yard <= 32; yard += 1) {
    const y = lineOfScrimmage - (yard * pixelsPerYard);
    if (y < 0 || y > fieldHeight) continue;
    const isFive = yard % 5 === 0;
    markings.push(`
      <line x1="${isFive ? 0 : 9}" y1="${y}" x2="${isFive ? 900 : 891}" y2="${y}" stroke="rgba(255,255,255,${isFive ? ".30" : ".11"})" stroke-width="${isFive ? 2 : 1}"></line>
      <line x1="${hashLeft - (pixelsPerYard / 3)}" y1="${y}" x2="${hashLeft + (pixelsPerYard / 3)}" y2="${y}" stroke="rgba(255,255,255,.68)" stroke-width="2"></line>
      <line x1="${hashRight - (pixelsPerYard / 3)}" y1="${y}" x2="${hashRight + (pixelsPerYard / 3)}" y2="${y}" stroke="rgba(255,255,255,.68)" stroke-width="2"></line>
      <line x1="0" y1="${y}" x2="11" y2="${y}" stroke="rgba(255,255,255,.65)" stroke-width="2"></line>
      <line x1="889" y1="${y}" x2="900" y2="${y}" stroke="rgba(255,255,255,.65)" stroke-width="2"></line>
    `);
  }

  [
    { yard: 0, value: "30" },
    { yard: 10, value: "40" },
    { yard: 20, value: "50" }
  ].forEach(mark => {
    const y = lineOfScrimmage - (mark.yard * pixelsPerYard);
    markings.push(`
      <text x="${numberLeft}" y="${y}" fill="rgba(255,255,255,.70)" font-family="Arial, sans-serif" font-size="34" font-weight="900" text-anchor="middle" dominant-baseline="central" transform="rotate(90 ${numberLeft} ${y})">${mark.value}</text>
      <text x="${numberRight}" y="${y}" fill="rgba(255,255,255,.70)" font-family="Arial, sans-serif" font-size="34" font-weight="900" text-anchor="middle" dominant-baseline="central" transform="rotate(-90 ${numberRight} ${y})">${mark.value}</text>
    `);
  });

  markings.push(`
    <line x1="0" y1="${lineOfScrimmage}" x2="900" y2="${lineOfScrimmage}" stroke="#fff" stroke-width="4"></line>
    <text x="18" y="${lineOfScrimmage - 10}" fill="rgba(255,255,255,.76)" font-size="10" font-weight="800">LINE OF SCRIMMAGE</text>
  `);
  return markings.join("");
}

function libraryPreviewMarkup() {
  const isDefense = libraryPreview.type === "defense";
  const isFormation = libraryPreview.type === "formation";
  const item = isFormation
    ? formations.find(formation => formation.id === libraryPreview.id) || formations[0]
    : isDefense
    ? defenses.find(defense => defense.id === libraryPreview.id) || defenses[0]
    : plays.find(play => play.id === libraryPreview.id) || plays[0];
  const formation = isFormation
    ? item
    : isDefense
    ? currentFormation()
    : formations.find(savedFormation => savedFormation.id === item.formationId) || formations[0];
  const offensePositions = isFormation || isDefense
    ? formation.offensePositions
    : item.offensePositions || formation.offensePositions;
  const offenseLabels = isFormation || isDefense
    ? formation.labels
    : item.labels || formation.labels;
  const navigation = libraryPreviewNavigation();
  const navigationMarkup = navigation ? `
    <button
      class="library-preview-nav previous"
      data-library-preview-step="previous"
      aria-label="Previous play in folder"
      ${navigation.previous ? "" : "disabled"}
    >&#8592;</button>
    <button
      class="library-preview-nav next"
      data-library-preview-step="next"
      aria-label="Next play in folder"
      ${navigation.next ? "" : "disabled"}
    >&#8594;</button>
  ` : "";
  const routeMarkup = isDefense || isFormation ? "" : skillPositions.map(position => {
    const playerColor = positionColor(position.id, "offense");
    const route = item.routes[position.id] || [];
    const motion = item.motions?.[position.id] || [];
    const start = offensePositions[position.id];
    const snapStart = motionEnd(start, motion);
    const dx = snapStart.x - start.x;
    const dy = snapStart.y - start.y;
    const shiftedRoute = motion.length
      ? route.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }))
      : route;
    const motionPath = motion.length
      ? `<path d="${motion.length === 1 ? `M ${start.x} ${start.y} L ${motion[0].x} ${motion[0].y}` : routePathData(start, motion)}" fill="none" stroke="${playerColor}" stroke-width="4" stroke-dasharray="7 6" marker-end="url(#libraryMotionArrow)"></path>`
      : "";
    const routePath = shiftedRoute.length
      ? `<path d="${shiftedRoute.length === 1 ? `M ${snapStart.x} ${snapStart.y} L ${shiftedRoute[0].x} ${shiftedRoute[0].y}` : routePathData(snapStart, shiftedRoute)}" fill="none" stroke="${playerColor}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#libraryArrow)"></path>`
      : "";
    return motionPath + routePath;
  }).join("");
  const qbRouteMarkup = isDefense || isFormation
    ? ""
    : (() => {
        const start = offensePositions.QB;
        const playerColor = positionColor("QB", "offense");
        const route = item.routes.QB || [];
        if (!route.length) return "";
        const pathData = route.length === 1
          ? `M ${start.x} ${start.y} L ${route[0].x} ${route[0].y}`
          : routePathData(start, route);
        return `<path d="${pathData}" fill="none" stroke="${playerColor}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#libraryArrow)"></path>`;
      })();
  const optionRouteMarkup = isDefense || isFormation ? "" : skillPositions.map(position => {
    const playerColor = positionColor(position.id, "offense");
    const start = offensePositions[position.id];
    const motion = item.motions?.[position.id] || [];
    const snapStart = motionEnd(start, motion);
    const dx = snapStart.x - start.x;
    const dy = snapStart.y - start.y;
    return routeOptionsFor(item, position.id).map(option => {
      const storedAnchor = routeAnchorPoint(
        start,
        item.routes[position.id] || [],
        option.anchor
      );
      if (!storedAnchor || !option.points.length) return "";
      const displayAnchor = {
        x: storedAnchor.x + dx,
        y: storedAnchor.y + dy
      };
      const shifted = motion.length
        ? option.points.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }))
        : option.points;
      const pathData = shifted.length === 1
        ? `M ${displayAnchor.x} ${displayAnchor.y} L ${shifted[0].x} ${shifted[0].y}`
        : routePathData(displayAnchor, shifted);
      return `<path d="${pathData}" fill="none" stroke="${playerColor}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="8 6" marker-end="url(#libraryOptionArrow)" opacity=".82"></path>`;
    }).join("");
  }).join("");
  const offenseMarkup = [
    ...skillPositions.map(position => {
      const point = offensePositions[position.id];
      const playerColor = positionColor(position.id, "offense");
      return `<g transform="translate(${point.x} ${point.y})"><circle r="18" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></circle><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="10" font-weight="900">${escapeHtml(offenseLabels[position.id] || position.id)}</text></g>`;
    }),
    ...offensiveLine.map(player => {
      const point = offensePositions[player.id];
      const playerColor = positionColor(player.id, "offense");
      return `<g transform="translate(${point.x} ${point.y})"><rect x="-15" y="-15" width="30" height="30" rx="5" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></rect><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="9" font-weight="900">${player.label}</text></g>`;
    }),
    (() => {
      const point = offensePositions.QB;
      const playerColor = positionColor("QB", "offense");
      return `<g transform="translate(${point.x} ${point.y})"><circle r="19" fill="${playerColor}" stroke="#fff5d7" stroke-width="3"></circle><text y="4" text-anchor="middle" fill="${readableTextColor(playerColor)}" font-size="10" font-weight="900">QB</text></g>`;
    })()
  ].join("");
  const defenseMarkup = isDefense ? Object.keys(defaultDefensePositions()).map((id, index) => {
    const defenderColor = positionColor(id, "defense");
    const start = item.positions[id] || defaultDefensePositions()[id];
    const route = item.routes[id] || [];
    const manTarget = item.manAssignments?.[id];
    const zoneAssignment = item.zoneAssignments?.[id];
    const manLine = manTarget && offensePositions[manTarget]
      ? `<line x1="${start.x}" y1="${start.y}" x2="${offensePositions[manTarget].x}" y2="${offensePositions[manTarget].y}" stroke="${defenderColor}" stroke-width="2" stroke-dasharray="5 5" opacity=".7"></line>`
      : "";
    const zoneMarkup = zoneAssignment
      ? (() => {
          const radii = zoneRadii(zoneAssignment);
          return `<ellipse cx="${zoneAssignment.x}" cy="${zoneAssignment.y}" rx="${radii.x}" ry="${radii.y}" fill="${rgba(defenderColor, .1)}" stroke="${defenderColor}" stroke-width="2" stroke-dasharray="8 7" opacity=".55"></ellipse>`;
        })()
      : "";
    const path = route.length
      ? `<path d="${route.length === 1 ? `M ${start.x} ${start.y} L ${route[0].x} ${route[0].y}` : routePathData(start, route)}" fill="none" stroke="${defenderColor}" stroke-width="4" stroke-dasharray="10 6" marker-end="url(#libraryDefenseArrow)"></path>`
      : "";
    return `${zoneMarkup}${manLine}${path}<g transform="translate(${start.x} ${start.y})"><circle r="15" fill="${defenderColor}" stroke="#ffd8ca" stroke-width="2"></circle><text y="4" text-anchor="middle" fill="${readableTextColor(defenderColor)}" font-size="8" font-weight="900">${escapeHtml(item.labels[id] || String(index + 1))}</text></g>`;
  }).join("") : "";
  const notes = isFormation
    ? (formation.notes || [])
    : isDefense
    ? (item.notes || [])
    : [...(formation.notes || []), ...(item.notes || [])];
  const notesMarkup = notes.map(note => {
    const dimensions = noteDimensions(note.text);
    const x = Math.max(6, Math.min(note.x, fieldWidth - 6 - dimensions.width));
    const y = Math.max(6, Math.min(note.y, fieldHeight - 6 - dimensions.height));
    return `
      <g transform="translate(${x} ${y})">
        <rect width="${dimensions.width}" height="${dimensions.height}" rx="5" fill="rgba(255,253,247,.96)" stroke="#c9f45c" stroke-width="2"></rect>
        <foreignObject x="5" y="5" width="${Math.max(1, dimensions.width - 10)}" height="${Math.max(1, dimensions.height - 10)}">
          <div xmlns="http://www.w3.org/1999/xhtml" class="library-preview-note">${escapeHtml(note.text || "")}</div>
        </foreignObject>
      </g>
    `;
  }).join("");
  const routeOptionSummary = isDefense || isFormation ? "" : skillPositions.flatMap(position =>
    routeOptionsFor(item, position.id).map(option => {
      const defenseNames = option.defenseIds
        .map(defenseId => defenses.find(candidate => candidate.id === defenseId)?.name)
        .filter(Boolean);
      return `<span><strong>${escapeHtml(offenseLabels[position.id] || position.id)}:</strong> ${escapeHtml(option.name)} vs. ${escapeHtml(defenseNames.join(", ") || "Unassigned defense")}</span>`;
    })
  ).join("");

  return `
    <div class="library-preview-heading">
      <div>
        <p class="eyebrow">${isFormation ? "Formation preview" : isDefense ? "Defense preview" : escapeHtml(formation.name)}</p>
        <h3>${escapeHtml(item.name)}</h3>
      </div>
      <span class="library-field-standard">${escapeHtml(fieldStandards[fieldStandard].label)} field</span>
    </div>
    <div class="library-field-frame">
    ${navigationMarkup}
    <svg viewBox="0 0 ${fieldWidth} ${fieldHeight}" aria-label="${escapeHtml(item.name)} preview">
      <defs>
        <marker id="libraryArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
        <marker id="libraryMotionArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
        <marker id="libraryDefenseArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
        <marker id="libraryOptionArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,6 L7,3 z" fill="context-stroke"></path></marker>
      </defs>
      <rect width="${fieldWidth}" height="${fieldHeight}" rx="10" fill="#174c35"></rect>
      ${libraryFieldMarkingsMarkup()}
      ${routeMarkup}${qbRouteMarkup}${optionRouteMarkup}${offenseMarkup}${defenseMarkup}${notesMarkup}
    </svg>
    </div>
    ${routeOptionSummary
      ? `<div class="route-option-summary"><p class="eyebrow">Route options</p>${routeOptionSummary}</div>`
      : ""}
  `;
}

function activeRunRouteOptions() {
  if (appTab !== "run") return [];
  return skillPositions.map(position => {
    const option = matchedRouteOption(currentPlay(), position.id, selectedDefenseId);
    return option
      ? { player: offenseLabel(position.id), option }
      : null;
  }).filter(Boolean);
}

function renderFormationControls() {
  els.formationSelect.innerHTML = formations.map(formation =>
    `<option value="${formation.id}">${escapeHtml(formation.name)}</option>`
  ).join("");
  els.formationSelect.value = selectedFormationId;
  els.formationName.value = currentFormation()?.name || "";
}

function renderDefenseControls() {
  els.defenseSelect.innerHTML = defenses.map(defense =>
    `<option value="${defense.id}">${escapeHtml(defense.name)}</option>`
  ).join("");
  els.defenseSelect.value = selectedDefenseId;
  els.defenseName.value = currentDefense().name;
  const realism = normalizeDefenseRealism(currentDefense().realism);
  if (els.coveragePersonalitySelect) els.coveragePersonalitySelect.value = realism.personality;
  if (els.eyeDisciplineSelect) els.eyeDisciplineSelect.value = realism.eyes;
  if (els.awarenessInput) els.awarenessInput.value = String(realism.awareness);
  if (els.disciplineInput) els.disciplineInput.value = String(realism.discipline);
  if (els.aggressionInput) els.aggressionInput.value = String(realism.aggression);
  if (els.mistakeInput) els.mistakeInput.value = String(realism.mistakes);
  if (!formations.some(formation => formation.id === defenseAlignmentFormationId)) {
    defenseAlignmentFormationId = formations[0].id;
  }
  document.querySelector("#toggleDefenseAlignmentsButton").textContent = defenseAlignmentMode
    ? "Alignment Setup Active"
    : "Set Alignments";
  els.defenseAlignmentControls.classList.toggle("hidden", !defenseAlignmentMode);
  els.defenseAlignmentFormationSelect.innerHTML = formations.map(formation =>
    `<option value="${formation.id}">${escapeHtml(formation.name)}${
      currentDefense().formationAlignments?.[formation.id] ? " (Set)" : ""
    }</option>`
  ).join("");
  els.defenseAlignmentFormationSelect.value = defenseAlignmentFormationId;
  const alignmentIndex = formations.findIndex(
    formation => formation.id === defenseAlignmentFormationId
  );
  const customAlignmentCount = formations.filter(
    formation => currentDefense().formationAlignments?.[formation.id]
  ).length;
  els.defenseAlignmentProgress.textContent = defenseAlignmentMode
    ? `Formation ${alignmentIndex + 1} of ${formations.length} | ${customAlignmentCount} custom alignments saved`
    : "";
  document.querySelector("#previousDefenseAlignmentButton").disabled = alignmentIndex <= 0;
  document.querySelector("#nextDefenseAlignmentButton").disabled = alignmentIndex >= formations.length - 1;
  const selectedZone = activeRouteSide === "defense"
    ? currentDefense().zoneAssignments?.[activeRouteId]
    : null;
  els.zoneSizeControl.classList.toggle(
    "hidden",
    createScreen !== "defense" || defenseAssignmentMode !== "zone" || !selectedZone
  );
  if (selectedZone) {
    const radii = zoneRadii(selectedZone);
    const size = String(Math.round(Math.max(radii.x, radii.y)));
    els.zoneSizeRange.value = size;
    els.zoneSizeInput.value = size;
  }
}

function rememberRunFolderState() {
  els.runPlayBrowser
    ?.querySelectorAll("[data-run-folder-state]")
    .forEach(folder => {
      runFolderOpenState.set(folder.dataset.runFolderState, folder.open);
    });
  if (els.runPlayBrowser) {
    runFolderOpenState.set("browser", els.runPlayBrowser.open);
  }
}

function runFolderOpenAttribute(key, openByDefault = false) {
  const saved = runFolderOpenState.get(key);
  return (saved ?? openByDefault) ? " open" : "";
}

function selectRunPlay(playId) {
  const play = plays.find(candidate => candidate.id === playId);
  if (!play) return;
  rememberRunFolderState();
  selectedPlayId = play.id;
  selectedFormationId = play.formationId || selectedFormationId;
  stopAnimationPlayback();
  resetRunScenario();
  renderPlayControls();
  render();
}

function runPlayButtonMarkup(play) {
  const formation = formations.find(candidate => candidate.id === play.formationId);
  return `
    <button
      class="run-browser-play ${play.id === selectedPlayId ? "active" : ""}"
      data-run-browser-play="${play.id}"
    >
      <span>${escapeHtml(formation?.name || "Formation")}</span>
      <strong>${escapeHtml(play.name)}</strong>
    </button>
  `;
}

function runCustomFolderMarkup(folder, depth = 0) {
  const children = libraryFolders
    .filter(candidate => candidate.parentId === folder.id)
    .sort((a, b) => a.name.localeCompare(b.name));
  const folderPlays = plays
    .filter(play =>
      itemFolderIds(libraryItemKey("play", play.id)).includes(folder.id)
    )
    .sort((a, b) => a.name.localeCompare(b.name));
  return `
    <details
      class="run-browser-folder"
      style="--run-folder-depth:${depth}"
      data-run-folder-state="custom:${folder.id}"
      ${runFolderOpenAttribute(`custom:${folder.id}`)}
    >
      <summary>
        <span>${escapeHtml(folder.name)}</span>
        <small>${folderPlays.length + children.length}</small>
      </summary>
      <div class="run-browser-folder-content">
        ${children.map(child => runCustomFolderMarkup(child, depth + 1)).join("")}
        ${folderPlays.map(runPlayButtonMarkup).join("")}
        ${!children.length && !folderPlays.length
          ? `<p class="library-empty">This folder has no plays.</p>`
          : ""}
      </div>
    </details>
  `;
}

function renderRunPlayBrowser() {
  if (!els.runPlayBrowserContent) return;
  rememberRunFolderState();
  els.runPlayBrowser.open = runFolderOpenState.get("browser") || false;
  const rootFolders = libraryFolders
    .filter(folder =>
      !folder.parentId || !libraryFolders.some(candidate => candidate.id === folder.parentId)
    )
    .sort((a, b) => a.name.localeCompare(b.name));
  const formationFolders = formations
    .map(formation => ({
      formation,
      formationPlays: plays
        .filter(play => play.formationId === formation.id)
        .sort((a, b) => a.name.localeCompare(b.name))
    }))
    .filter(group => group.formationPlays.length);

  els.runPlayBrowserContent.innerHTML = `
    ${rootFolders.length ? `
      <div class="run-browser-section">
        <p class="eyebrow">Custom folders</p>
        ${rootFolders.map(folder => runCustomFolderMarkup(folder)).join("")}
      </div>
    ` : ""}
    <div class="run-browser-section">
      <p class="eyebrow">Formations</p>
      ${formationFolders.map(({ formation, formationPlays }) => `
        <details
          class="run-browser-folder"
          data-run-folder-state="formation:${formation.id}"
          ${runFolderOpenAttribute(`formation:${formation.id}`)}
        >
          <summary>
            <span>${escapeHtml(formation.name)}</span>
            <small>${formationPlays.length}</small>
          </summary>
          <div class="run-browser-folder-content">
            ${formationPlays.map(runPlayButtonMarkup).join("")}
          </div>
        </details>
      `).join("")}
    </div>
  `;

  els.runPlayBrowser.querySelectorAll("[data-run-folder-state]").forEach(folder => {
    folder.addEventListener("toggle", () => {
      runFolderOpenState.set(folder.dataset.runFolderState, folder.open);
    });
  });
  els.runPlayBrowser.querySelectorAll("[data-run-browser-play]").forEach(button => {
    button.addEventListener("click", () => selectRunPlay(button.dataset.runBrowserPlay));
  });
  els.runPlayBrowser.ontoggle = () => {
    runFolderOpenState.set("browser", els.runPlayBrowser.open);
  };
}

function renderRunControls() {
  const runnableFormations = formations.filter(formation =>
    plays.some(play => play.formationId === formation.id)
  );
  const selectedPlay = plays.find(play => play.id === selectedPlayId);
  if (appTab === "run") {
    if (selectedPlay?.formationId && runnableFormations.some(formation => formation.id === selectedPlay.formationId)) {
      selectedFormationId = selectedPlay.formationId;
    } else if (!runnableFormations.some(formation => formation.id === selectedFormationId)) {
      selectedFormationId = runnableFormations[0]?.id || formations[0].id;
    }
  }

  const formationPlays = plays.filter(play => play.formationId === selectedFormationId);
  if (appTab === "run" && !formationPlays.some(play => play.id === selectedPlayId)) {
    selectedPlayId = formationPlays[0]?.id || plays[0].id;
  }
  els.runPlaySelect.innerHTML = formationPlays.map(play =>
    `<option value="${play.id}">${escapeHtml(play.name)}</option>`
  ).join("");
  els.runPlaySelect.value = selectedPlayId;
  els.runPlaySelect.disabled = formationPlays.length === 0;
  els.runFormationSelect.innerHTML = runnableFormations.map(formation =>
    `<option value="${formation.id}">${escapeHtml(formation.name)}</option>`
  ).join("");
  els.runFormationSelect.value = selectedFormationId;
  els.runFormationSelect.disabled = runnableFormations.length <= 1;
  els.runDefenseSelect.innerHTML = defenses.map(defense =>
    `<option value="${defense.id}">${escapeHtml(defense.name)}</option>`
  ).join("");
  els.runDefenseSelect.value = selectedDefenseId;
  els.runSpeedSelect.value = String(runSpeed);
  els.runDefenseMovementSelect.value = runDefenseMovement ? "on" : "off";
  renderRunPlayBrowser();
}

function nestedFolderIds(folderId) {
  const ids = new Set([folderId]);
  let added = true;
  while (added) {
    added = false;
    libraryFolders.forEach(folder => {
      if (folder.parentId && ids.has(folder.parentId) && !ids.has(folder.id)) {
        ids.add(folder.id);
        added = true;
      }
    });
  }
  return ids;
}

function testEligiblePlays() {
  const sourcePlays = testSourceId === "all"
    ? plays
    : (() => {
        const folderIds = nestedFolderIds(testSourceId);
        return plays.filter(play =>
          itemFolderIds(libraryItemKey("play", play.id))
            .some(folderId => folderIds.has(folderId))
        );
      })();
  return sourcePlays.filter(play => testPlayIds.has(play.id));
}

function resetTestInteraction() {
  testQbLookPoint = null;
  testThrowState = null;
  testPlayResult = null;
  if (testThrowFrame) {
    cancelAnimationFrame(testThrowFrame);
    testThrowFrame = null;
  }
}

function testThrowActive() {
  return appTab === "test" && testRoundReady && !testAnswerRevealed && !testPlayDead();
}

function testPlayDead() {
  return Boolean(testPlayResult?.dead || testThrowState?.catchRun?.tackled);
}

function currentTestQbLookPoint() {
  if (appTab !== "test" || !testRoundReady || testAnswerRevealed) return null;
  return testQbLookPoint;
}

function nearestDefendersTo(point) {
  return Object.entries(animationState?.defense || currentDefenseEditorPositions())
    .map(([id, defenderPoint]) => ({
      id,
      point: defenderPoint,
      distance: Math.hypot(defenderPoint.x - point.x, defenderPoint.y - point.y)
    }))
    .sort((a, b) => a.distance - b.distance);
}

function nearestTestReceiver(point, maxDistance = 62) {
  return skillPositions
    .map(position => {
      const receiverPoint = animationState?.offense?.[position.id] || offensePosition(position.id);
      return {
        id: position.id,
        distance: Math.hypot(receiverPoint.x - point.x, receiverPoint.y - point.y)
      };
    })
    .filter(receiver => receiver.distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance)[0] || null;
}

function handleTestThrowPointer(event) {
  if (!testThrowActive()) return false;
  const point = eventToFieldPoint(event);
  const receiver = nearestTestReceiver(point);
  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation?.();
  startTestThrow(receiver?.id || null, receiver ? null : point);
  return true;
}

function scheduleTestThrowRender() {
  if (testThrowFrame) return;
  const tick = () => {
    if (!animationPlayback && testThrowState && !testThrowState.resolved) {
      breakTestDefenseOnThrow(1 / 60);
    }
    if (!animationPlayback && completedTestCatchActive()) {
      advanceTestCatchRun(1 / 60);
      rallyTestDefenseToBall(1 / 60);
      resolveTestCatchTackle();
    }
    renderRoutesAndPlayers();
    if (!testPlayDead() && ((testThrowState && !testThrowState.resolved) || completedTestCatchActive())) {
      testThrowFrame = requestAnimationFrame(tick);
    } else {
      testThrowFrame = null;
    }
  };
  testThrowFrame = requestAnimationFrame(tick);
}

function completedTestCatchActive() {
  if (appTab !== "test" || !testThrowState?.resolved) return false;
  return testThrowState.outcome?.className === "complete"
    && !testThrowState.catchRun?.tackled
    && (testThrowState.catchRun?.current?.y ?? fieldHeight) > fieldPadding + 3;
}

function advanceTestCatchRun(deltaSeconds) {
  if (!completedTestCatchActive()) return false;
  animationState ||= { offense: {}, defense: {} };
  const id = testThrowState.receiverId;
  const current = testThrowState.catchRun.current
    || animationState.offense[id]
    || offensePosition(id);
  const next = {
    ...current,
    y: Math.max(fieldPadding, current.y - (165 * Math.max(0, deltaSeconds)))
  };
  testThrowState.catchRun.current = next;
  animationState.offense[id] = next;
  if (next.y <= fieldPadding + 3) {
    testPlayResult = {
      dead: true,
      label: "Touchdown",
      point: { ...next },
      className: "complete"
    };
    els.testStatus.textContent = `${offenseLabel(id)} scores a touchdown.`;
    return false;
  }
  return !resolveTestCatchTackle(next) && next.y > fieldPadding + 3;
}

function markTestThrowDead(outcome, point) {
  if (!outcome || outcome.className === "complete") return;
  testPlayResult = {
    dead: true,
    label: outcome.label,
    point: { ...point },
    className: outcome.className || "breakup",
    defenderId: outcome.defenderId || ""
  };
}

function resolveTestCatchTackle(ballPoint = testThrowState?.catchRun?.current) {
  if (!completedTestCatchActive() || !ballPoint) return false;
  const id = testThrowState.receiverId;
  const tackler = nearestDefendersTo(ballPoint)
    .filter(defender => defender.distance <= 17)
    .sort((a, b) => a.distance - b.distance)[0];
  if (!tackler) return false;
  testThrowState.catchRun.tackled = true;
  testThrowState.catchRun.tacklerId = tackler.id;
  testPlayResult = {
    dead: true,
    label: "Tackled",
    point: { ...ballPoint },
    className: "breakup"
  };
  testThrowState.catchRun.current = {
    ...ballPoint,
    x: (ballPoint.x + tackler.point.x) / 2,
    y: (ballPoint.y + tackler.point.y) / 2
  };
  animationState.offense[id] = { ...testThrowState.catchRun.current };
  const tacklerLabel = currentDefense().labels[tackler.id] || tackler.id;
  els.testStatus.textContent = `${offenseLabel(id)} tackled by ${tacklerLabel}.`;
  return true;
}

function defenderLabel(id) {
  return currentDefense().labels?.[id] || id;
}

function isDefensiveLinePlayer(id) {
  return /(^|[^A-Z])(DE|DT|NT|DL|EDGE)([^A-Z]|$)/i.test(defenderLabel(id));
}

function currentTestThrowLandingPoint() {
  if (!testThrowState || testThrowState.resolved) return null;
  return testThrowState.targetMode === "receiver" && testThrowState.receiverId
    ? animationState?.offense?.[testThrowState.receiverId] || testThrowState.target
    : testThrowState.target;
}

function shouldDefenderBreakOnThrow(id, current, landingPoint, qbPoint) {
  if (!landingPoint || isDefensiveLinePlayer(id)) return false;
  const distanceToBall = Math.hypot(landingPoint.x - current.x, landingPoint.y - current.y);
  const laneDistance = pointLineDistance(current, qbPoint, landingPoint);
  const inThrowWindow = distanceToBall <= 245 || laneDistance <= 66;
  const canSeeIt = current.y < lineOfScrimmage + 25;
  return inThrowWindow && canSeeIt;
}

function breakDefenderOnThrow(id, current, landingPoint, deltaSeconds, urgency = 1) {
  if (!testThrowState) return current;
  testThrowState.breakStates ||= {};
  const state = testThrowState.breakStates[id] ||= {
    vx: 0,
    vy: 0,
    reaction: .08 + (Math.random() * .18),
    elapsed: 0
  };
  const safeDelta = Math.max(.008, Math.min(.05, deltaSeconds));
  state.elapsed += safeDelta;
  if (state.elapsed < state.reaction) return { ...current };
  const direction = vectorToward(current, landingPoint);
  const distance = Math.hypot(landingPoint.x - current.x, landingPoint.y - current.y);
  const receiverTopSpeed = 115;
  const maxSpeed = receiverTopSpeed * Math.min(1.18, urgency * 1.08);
  const desiredVx = direction.x * maxSpeed;
  const desiredVy = direction.y * maxSpeed;
  const acceleration = 520 * urgency;
  const velocityChange = Math.hypot(desiredVx - state.vx, desiredVy - state.vy);
  const maxVelocityChange = acceleration * safeDelta;
  const velocityRatio = velocityChange
    ? Math.min(1, maxVelocityChange / velocityChange)
    : 0;
  state.vx += (desiredVx - state.vx) * velocityRatio;
  state.vy += (desiredVy - state.vy) * velocityRatio;
  const proposedDx = state.vx * safeDelta;
  const proposedDy = state.vy * safeDelta;
  const proposedDistance = Math.hypot(proposedDx, proposedDy);
  const frameDistance = Math.min(distance, proposedDistance);
  const frameRatio = proposedDistance ? frameDistance / proposedDistance : 0;
  return {
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, current.x + (proposedDx * frameRatio))),
    y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, current.y + (proposedDy * frameRatio)))
  };
}

function resolveTestQbSack(defenderId) {
  if (testPlayDead() || testThrowState) return false;
  const qbPoint = animationState?.offense?.QB || offensePosition("QB");
  testPlayResult = {
    dead: true,
    label: "Sacked",
    point: { ...qbPoint },
    className: "interception",
    defenderId
  };
  const rusherLabel = defenderLabel(defenderId);
  els.testStatus.textContent = `QB sacked by ${rusherLabel}.`;
  return true;
}

function rushDefenderToQb(id, current, qbPoint, deltaSeconds, blocked = true) {
  if (blocked) {
    const labelHash = [...String(id)].reduce((total, char) => total + char.charCodeAt(0), 0);
    const time = performance.now() / 1000;
    const target = {
      x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, current.x + (Math.sin(time * 5.2 + labelHash) * 3.2))),
      y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, Math.min(lineOfScrimmage - 8, current.y + (Math.cos(time * 4.3 + labelHash) * 1.8))))
    };
    const direction = vectorToward(current, target);
    const distance = Math.hypot(target.x - current.x, target.y - current.y);
    const step = Math.min(distance, 42 * Math.max(.008, deltaSeconds));
    return {
      x: current.x + (direction.x * step),
      y: current.y + (direction.y * step)
    };
  }
  const direction = vectorToward(current, qbPoint);
  const distance = Math.hypot(qbPoint.x - current.x, qbPoint.y - current.y);
  const pocketWall = 16;
  const rushSpeed = 210;
  const step = Math.min(Math.max(0, distance - pocketWall), rushSpeed * Math.max(.008, deltaSeconds));
  return {
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, current.x + (direction.x * step))),
    y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, current.y + (direction.y * step)))
  };
}

function rallyDefenderToBall(id, current, ballPoint, deltaSeconds, urgency = 1) {
  const direction = vectorToward(current, ballPoint);
  const distance = Math.hypot(ballPoint.x - current.x, ballPoint.y - current.y);
  const rallySpeed = Math.min(245, 135 + (distance * .34)) * urgency;
  const step = Math.min(distance, rallySpeed * Math.max(.008, deltaSeconds));
  return {
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, current.x + (direction.x * step))),
    y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, current.y + (direction.y * step)))
  };
}

function rallyTestDefenseToBall(deltaSeconds) {
  if (!completedTestCatchActive()) return;
  animationState ||= { offense: {}, defense: {} };
  const ballPoint = testThrowState.catchRun.current;
      const defenders = Object.entries(animationState.defense || currentDefenseEditorPositions());
  defenders.forEach(([id, current]) => {
    const rallied = rallyDefenderToBall(id, current, ballPoint, deltaSeconds, 1);
    animationState.defense[id] = rallied;
    if (animationPlayback) {
      animationPlayback.defenderEyes[id] = {
        facing: vectorToward(rallied, ballPoint),
        mode: "rally",
        targetId: testThrowState.receiverId || ""
      };
    }
  });
}

function breakTestDefenseOnThrow(deltaSeconds) {
  const landingPoint = currentTestThrowLandingPoint();
  if (!landingPoint) return;
  animationState ||= { offense: {}, defense: {} };
  const qbPoint = animationState.offense?.QB || offensePosition("QB");
  const defenders = Object.entries(animationState.defense || currentDefenseEditorPositions());
  defenders.forEach(([id, current]) => {
    if (!shouldDefenderBreakOnThrow(id, current, landingPoint, qbPoint)) return;
    const broken = breakDefenderOnThrow(id, current, landingPoint, deltaSeconds, 1);
    animationState.defense[id] = broken;
    if (animationPlayback) {
      animationPlayback.defenderEyes[id] = {
        facing: vectorToward(broken, landingPoint),
        mode: "break",
        targetId: testThrowState.receiverId || ""
      };
    }
  });
}

function nearestCatchableReceiver(targetPoint, maxDistance = 36) {
  return skillPositions
    .map(position => {
      const receiverPoint = animationState?.offense?.[position.id] || offensePosition(position.id);
      return {
        id: position.id,
        point: receiverPoint,
        distance: Math.hypot(receiverPoint.x - targetPoint.x, receiverPoint.y - targetPoint.y)
      };
    })
    .filter(receiver => receiver.distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance)[0] || null;
}

function evaluateThrowOutcome(receiverId, targetPoint) {
  const catchTarget = receiverId
    ? { id: receiverId, point: animationState?.offense?.[receiverId] || offensePosition(receiverId), distance: 0 }
    : nearestCatchableReceiver(targetPoint);
  const defenders = nearestDefendersTo(targetPoint);
  const nearest = defenders[0];
  const second = defenders[1];
  const qbPoint = animationState?.offense?.QB || offensePosition("QB");
  const throwDistance = Math.hypot(targetPoint.x - qbPoint.x, targetPoint.y - qbPoint.y);
  const nearestDistance = nearest?.distance ?? 999;
  const secondDistance = second?.distance ?? 999;
  const contestThreat = defenders
    .map(defender => ({
      ...defender,
      targetDistance: Math.hypot(defender.point.x - targetPoint.x, defender.point.y - targetPoint.y),
      laneDistance: pointLineDistance(defender.point, qbPoint, targetPoint)
    }))
    .filter(defender =>
      defender.targetDistance < 42
      || (defender.targetDistance < 62 && defender.laneDistance < 36)
    )
    .sort((a, b) => {
      const aScore = a.targetDistance + (a.laneDistance * .45);
      const bScore = b.targetDistance + (b.laneDistance * .45);
      return aScore - bScore;
    })[0];
  const passingLaneThreat = defenders
    .map(defender => ({
      ...defender,
      targetDistance: Math.hypot(defender.point.x - targetPoint.x, defender.point.y - targetPoint.y),
      laneDistance: pointLineDistance(defender.point, qbPoint, targetPoint)
    }))
    .filter(defender => defender.laneDistance < 16 && defender.targetDistance < 70)
    .sort((a, b) => a.distance - b.distance)[0];
  if (!catchTarget) {
    if (nearestDistance < 13) {
      return { label: "Intercepted", className: "interception", defenderId: nearest.id, receiverId: null };
    }
    return { label: "Incomplete", className: "breakup", defenderId: "", receiverId: null };
  }
  if (nearestDistance > 38 && !passingLaneThreat && !contestThreat) {
    return { label: "Complete", className: "complete", defenderId: "", receiverId: catchTarget.id };
  }
  let risk = 0;
  risk += nearestDistance < 13 ? 78 : nearestDistance < 22 ? 48 : nearestDistance < 34 ? 26 : 0;
  risk += secondDistance < 24 ? 14 : 0;
  risk += passingLaneThreat ? 16 : 0;
  risk += contestThreat ? contestThreat.targetDistance < 24 ? 24 : 14 : 0;
  risk += throwDistance > 360 ? 10 : throwDistance > 250 ? 5 : 0;
  const routeDepth = Math.max(0, lineOfScrimmage - catchTarget.point.y);
  risk += routeDepth > 210 ? 10 : 0;
  const roll = Math.random() * 100;
  if (nearestDistance < 11 && roll < risk * .42) {
    return { label: "Intercepted", className: "interception", defenderId: nearest.id, receiverId: catchTarget.id };
  }
  if ((passingLaneThreat && roll < risk * .55) || (contestThreat && roll < risk * .82) || roll < risk) {
    return { label: "Broken up", className: "breakup", defenderId: passingLaneThreat?.id || contestThreat?.id || nearest?.id || "", receiverId: catchTarget.id };
  }
  return { label: "Complete", className: "complete", defenderId: "", receiverId: catchTarget.id };
}

function startTestThrow(receiverId, targetPoint = null) {
  if (!testThrowActive()) return;
  if (testThrowState && !testThrowState.resolved) return;
  const start = { ...(animationState?.offense?.QB || offensePosition("QB")) };
  const target = { ...(receiverId ? (animationState?.offense?.[receiverId] || offensePosition(receiverId)) : targetPoint) };
  const distance = Math.hypot(target.x - start.x, target.y - start.y);
  const flightSpeed = 760;
  testThrowState = {
    receiverId,
    targetMode: receiverId ? "receiver" : "spot",
    start,
    target,
    startedAt: performance.now(),
    duration: Math.max(.18, distance / flightSpeed),
    resolved: false,
    outcome: null,
    catchRun: null
  };
  els.testStatus.textContent = receiverId
    ? `Throwing to ${offenseLabel(receiverId)}...`
    : "Throwing to spot...";
  renderRoutesAndPlayers();
  scheduleTestThrowRender();
}

function resetTestSession() {
  testRoundReady = false;
  testAnswerRevealed = false;
  testSessionPlayIds = [];
  testSessionIndex = -1;
  resetTestInteraction();
  stopAnimationPlayback();
  const sessionButton = document.querySelector("#newTestRoundButton");
  const runButton = document.querySelector("#runTestButton");
  const resetButton = document.querySelector("#resetTestButton");
  const revealButton = document.querySelector("#revealTestButton");
  if (sessionButton) sessionButton.textContent = "Start Test";
  if (runButton) runButton.disabled = true;
  if (resetButton) resetButton.disabled = true;
  if (revealButton) {
    revealButton.disabled = true;
    revealButton.textContent = "Reveal Answer";
  }
}

function shuffledIds(items) {
  const ids = items.map(item => item.id);
  for (let index = ids.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [ids[index], ids[swapIndex]] = [ids[swapIndex], ids[index]];
  }
  return ids;
}

function refreshTestPlaySelectionUi() {
  if (!els.testPlayOptions) return;
  els.testPlayOptions.querySelectorAll("[data-test-play]").forEach(input => {
    input.checked = testPlayIds.has(input.dataset.testPlay);
  });
  els.testPlayOptions.querySelectorAll("[data-test-formation]").forEach(input => {
    const formationPlayIds = plays
      .filter(play => play.formationId === input.dataset.testFormation)
      .map(play => play.id);
    const selectedCount = formationPlayIds.filter(id => testPlayIds.has(id)).length;
    input.checked = selectedCount === formationPlayIds.length;
    input.indeterminate = selectedCount > 0 && selectedCount < formationPlayIds.length;
  });
  const selectedPlayCount = testPlayIds.size;
  els.testPlaySummary.textContent = selectedPlayCount === plays.length
    ? `All plays (${plays.length})`
    : `${selectedPlayCount} of ${plays.length} plays`;
}

function renderTestControls() {
  if (!els.testSourceSelect) return;
  const validPlayIds = new Set(plays.map(play => play.id));
  const validDefenseIds = new Set(defenses.map(defense => defense.id));
  testPlayIds = new Set([...testPlayIds].filter(id => validPlayIds.has(id)));
  testDefenseIds = new Set([...testDefenseIds].filter(id => validDefenseIds.has(id)));
  els.testSourceSelect.innerHTML = [
    `<option value="all">All Plays (${plays.length})</option>`,
    ...libraryFolders
      .slice()
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(folder => {
        const count = plays.filter(play =>
          itemFolderIds(libraryItemKey("play", play.id))
            .some(folderId => nestedFolderIds(folder.id).has(folderId))
        ).length;
        return `<option value="${folder.id}">${escapeHtml(folder.name)} (${count})</option>`;
      })
  ].join("");
  if (![...els.testSourceSelect.options].some(option => option.value === testSourceId)) {
    testSourceId = "all";
  }
  els.testSourceSelect.value = testSourceId;
  const playGroups = formations.map(formation => ({
    formation,
    formationPlays: plays
      .filter(play => play.formationId === formation.id)
      .sort((a, b) => a.name.localeCompare(b.name))
  })).filter(group => group.formationPlays.length);
  const unassignedPlays = plays
    .filter(play => !formations.some(formation => formation.id === play.formationId))
    .sort((a, b) => a.name.localeCompare(b.name));
  els.testPlayOptions.innerHTML = [
    ...playGroups.map(({ formation, formationPlays }) => `
      <details class="test-play-formation">
        <summary>
          <label>
            <input type="checkbox" data-test-formation="${formation.id}">
            <strong>${escapeHtml(formation.name)}</strong>
          </label>
          <small>${formationPlays.length}</small>
        </summary>
        <div>
          ${formationPlays.map(play => `
            <label class="test-play-option">
              <input type="checkbox" data-test-play="${play.id}" ${testPlayIds.has(play.id) ? "checked" : ""}>
              <span>${escapeHtml(play.name)}</span>
            </label>
          `).join("")}
        </div>
      </details>
    `),
    unassignedPlays.length ? `
      <details class="test-play-formation">
        <summary><strong>Other plays</strong><small>${unassignedPlays.length}</small></summary>
        <div>
          ${unassignedPlays.map(play => `
            <label class="test-play-option">
              <input type="checkbox" data-test-play="${play.id}" ${testPlayIds.has(play.id) ? "checked" : ""}>
              <span>${escapeHtml(play.name)}</span>
            </label>
          `).join("")}
        </div>
      </details>
    ` : ""
  ].join("");
  refreshTestPlaySelectionUi();
  els.testSpeedSelect.value = String(runSpeed);
  els.testDefenseOptions.innerHTML = defenses.map(defense => `
    <label class="test-defense-option">
      <input type="checkbox" value="${defense.id}" ${testDefenseIds.has(defense.id) ? "checked" : ""}>
      <span>${escapeHtml(defense.name)}</span>
    </label>
  `).join("");
  const selectedDefenseCount = testDefenseIds.size;
  els.testDefenseSummary.textContent = selectedDefenseCount === defenses.length
    ? `All defenses (${defenses.length})`
    : `${selectedDefenseCount} of ${defenses.length} defenses`;
  const revealButton = document.querySelector("#revealTestButton");
  const sessionButton = document.querySelector("#newTestRoundButton");
  const sessionComplete = testRoundReady
    && testSessionPlayIds.length
    && testSessionIndex >= testSessionPlayIds.length - 1;
  sessionButton.textContent = !testRoundReady
    ? "Start Test"
    : sessionComplete ? "Restart Test" : "Next Play";
  revealButton.disabled = !testRoundReady;
  revealButton.textContent = testAnswerRevealed ? "Hide Answer" : "Reveal Answer";
  document.querySelector("#runTestButton").disabled = !testRoundReady;
  document.querySelector("#resetTestButton").disabled = !testRoundReady;
  els.testStatus.textContent = !testRoundReady
    ? "Choose your plays and defenses, then start the test."
    : testAnswerRevealed
      ? `Play ${testSessionIndex + 1} of ${testSessionPlayIds.length}: ${currentFormation().name} / ${currentPlay().name} vs. ${currentDefense().name}`
      : `Play ${testSessionIndex + 1} of ${testSessionPlayIds.length}: ${currentFormation().name} / ${currentPlay().name}. Space once sets, Space again snaps.`;
}

function loadNextTestPlay() {
  let eligible = testEligiblePlays();
  if (!eligible.length) {
    window.alert("No selected plays are available from that source.");
    document.querySelector("#testPlayPicker").open = true;
    return;
  }
  const eligibleDefenses = defenses.filter(defense => testDefenseIds.has(defense.id));
  if (!eligibleDefenses.length) {
    window.alert("Select at least one defense for the test.");
    document.querySelector("#testDefensePicker").open = true;
    return;
  }
  const sessionComplete = testRoundReady
    && testSessionPlayIds.length
    && testSessionIndex >= testSessionPlayIds.length - 1;
  if (!testRoundReady || sessionComplete) {
    testSessionPlayIds = shuffledIds(eligible);
    testSessionIndex = -1;
  }
  stopAnimationPlayback();
  testSessionIndex += 1;
  const play = plays.find(candidate => candidate.id === testSessionPlayIds[testSessionIndex]);
  const defense = eligibleDefenses[Math.floor(Math.random() * eligibleDefenses.length)];
  if (!play) {
    resetTestSession();
    render();
    return;
  }
  selectedPlayId = play.id;
  selectedFormationId = play.formationId || formations[0].id;
  selectedDefenseId = defense.id;
  testAnswerRevealed = false;
  testRoundReady = true;
  resetTestInteraction();
  resetRunScenario();
  render();
}

function applyFormation(formation) {
  if (!formation) return;
  currentPlay().formationId = formation.id;
  currentPlay().offensePositions = structuredClone(normalizedOffensePositions(formation.offensePositions));
  currentPlay().labels = structuredClone(formation.labels);
  selectedFormationId = formation.id;
}

function mirroredPoint(point, sourceStart, targetStart) {
  return {
    ...point,
    x: targetStart.x - (point.x - sourceStart.x),
    y: targetStart.y + (point.y - sourceStart.y)
  };
}

function mirroredPath(path, sourceStart, targetStart) {
  return (path || []).map(point => mirroredPoint(point, sourceStart, targetStart));
}

function mirroredPlay(sourcePlay, sourceFormation, targetFormation) {
  const mirrored = createBlankPlay(sourcePlay.name);
  mirrored.formationId = targetFormation.id;
  mirrored.labels = structuredClone(targetFormation.labels);
  mirrored.offensePositions = structuredClone(normalizedOffensePositions(targetFormation.offensePositions));
  mirrored.notes = (sourcePlay.notes || []).map(note => ({
    ...structuredClone(note),
    id: crypto.randomUUID(),
    x: Math.max(8, 900 - note.x - (note.width || 170))
  }));
  routeableOffense.forEach(position => {
    const id = position.id;
    const sourceStart = sourceFormation.offensePositions[id];
    const targetStart = targetFormation.offensePositions[id];
    mirrored.routes[id] = mirroredPath(sourcePlay.routes[id], sourceStart, targetStart);
    mirrored.motions[id] = mirroredPath(sourcePlay.motions[id], sourceStart, targetStart);
    if (isSkillPosition(id)) {
      mirrored.routeOptions[id] = routeOptionsFor(sourcePlay, id).map(option => ({
        ...structuredClone(option),
        id: crypto.randomUUID(),
        points: mirroredPath(option.points, sourceStart, targetStart)
      }));
    }
  });
  return mirrored;
}

function mirroredFormation(source) {
  const mirrored = {
    id: crypto.randomUUID(),
    name: `${source.name} Mirror`,
    labels: structuredClone(source.labels),
    offensePositions: Object.fromEntries(
      Object.entries(source.offensePositions).map(([id, point]) => [
        id,
        { x: 900 - point.x, y: point.y }
      ])
    ),
    notes: (source.notes || []).map(note => ({
      ...structuredClone(note),
      id: crypto.randomUUID(),
      x: Math.max(8, 900 - note.x - (note.width || 170))
    }))
  };
  keepOffensiveLineOnScrimmage(mirrored.offensePositions);
  return mirrored;
}

function pointAlong(from, to, distance) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.hypot(dx, dy) || 1;
  const ratio = Math.min(distance, length / 2) / length;
  return { x: from.x + dx * ratio, y: from.y + dy * ratio };
}

function routePathData(position, route) {
  const points = [{ x: position.x, y: position.y }, ...route];
  if (points.length < 2) return "";
  let path = `M ${points[0].x} ${points[0].y}`;
  for (let index = 1; index < points.length; index += 1) {
    const point = points[index];
    const isRoundedBreak = Boolean(point.rounded) && index < points.length - 1;
    if (!isRoundedBreak) {
      path += ` L ${point.x} ${point.y}`;
      continue;
    }
    const before = pointAlong(point, points[index - 1], 20);
    const after = pointAlong(point, points[index + 1], 20);
    path += ` L ${before.x} ${before.y} Q ${point.x} ${point.y} ${after.x} ${after.y}`;
  }
  return path;
}

function nearestRouteAnchor(start, route, point) {
  const path = [start, ...route];
  if (path.length < 2) return null;
  let nearest = null;
  for (let index = 0; index < path.length - 1; index += 1) {
    const from = path[index];
    const to = path[index + 1];
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const lengthSquared = (dx * dx) + (dy * dy);
    const t = lengthSquared
      ? Math.max(0, Math.min(1, (((point.x - from.x) * dx) + ((point.y - from.y) * dy)) / lengthSquared))
      : 0;
    const projected = { x: from.x + (dx * t), y: from.y + (dy * t) };
    const distance = Math.hypot(point.x - projected.x, point.y - projected.y);
    if (!nearest || distance < nearest.distance) {
      nearest = { segmentIndex: index, t, point: projected, distance };
    }
  }
  return nearest;
}

function appendRoutePath(container, start, route, attributes) {
  if (!route.length) return;
  const element = route.length === 1
    ? svgEl("line", {
        x1: start.x,
        y1: start.y,
        x2: route[0].x,
        y2: route[0].y
    })
    : svgEl("path", { d: routePathData(start, route) });
  element.setAttribute("class", `${attributes.class || ""} field-route-line`.trim());
  element.setAttribute("vector-effect", "non-scaling-stroke");
  element.setAttribute("shape-rendering", "geometricPrecision");
  Object.entries(attributes).forEach(([key, value]) => {
    if (key !== "class") element.setAttribute(key, value);
  });
  container.append(element);
}

function offensePosition(id) {
  const base = editorOffensePositions()[id];
  return animationState?.offense?.[id] || base;
}

function routeForFormation(id) {
  if (isRunLikeMode()) return runScenarioRoute("offense", id);
  return currentPlay().routes[id] || [];
}

function motionEnd(start, motion) {
  return motion.length ? motion[motion.length - 1] : start;
}

function postSnapRoute(id, start = editorOffensePositions()[id]) {
  const route = routeForFormation(id);
  const motion = currentMotion(id);
  if (!motion.length) return route;
  const snapStart = motionEnd(start, motion);
  const dx = snapStart.x - start.x;
  const dy = snapStart.y - start.y;
  return route.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }));
}

function createPreviewRoute(id, start) {
  const selectedOption = id === activeRouteId ? selectedRouteOption(id) : null;
  const route = selectedOption
    ? branchedRoute(currentPlay(), id, selectedOption, start)
    : currentPlay().routes[id] || [];
  const motion = currentMotion(id);
  if (!motion.length) return route;
  const snapStart = motionEnd(start, motion);
  const dx = snapStart.x - start.x;
  const dy = snapStart.y - start.y;
  return route.map(point => ({ ...point, x: point.x + dx, y: point.y + dy }));
}

function extendRouteToBoundary(start, route) {
  if (!route.length) return route;
  const path = [start, ...route];
  let last = path[path.length - 1];
  let previous = null;
  for (let index = path.length - 2; index >= 0; index -= 1) {
    const candidate = path[index];
    if (Math.hypot(last.x - candidate.x, last.y - candidate.y) > 2) {
      previous = candidate;
      break;
    }
  }
  if (!previous) return route;
  const dx = last.x - previous.x;
  const dy = last.y - previous.y;
  const verticalMagnitude = Math.abs(dy);
  const horizontalMagnitude = Math.abs(dx);
  const isBreakingBackToBall = dy > 3 && verticalMagnitude >= horizontalMagnitude * .55;
  if (isBreakingBackToBall) return route;
  const candidates = [];
  if (dx > 0) candidates.push((fieldWidth - fieldPadding - last.x) / dx);
  if (dx < 0) candidates.push((fieldPadding - last.x) / dx);
  if (dy > 0) candidates.push((fieldHeight - fieldPadding - last.y) / dy);
  if (dy < 0) candidates.push((fieldPadding - last.y) / dy);
  const distanceRatio = candidates
    .filter(value => Number.isFinite(value) && value > 0)
    .sort((a, b) => a - b)[0];
  if (!distanceRatio || distanceRatio < .12) return route;
  const extendedPoint = {
    ...last,
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, last.x + (dx * distanceRatio))),
    y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, last.y + (dy * distanceRatio))),
    speed: last.speed || 1
  };
  return [...route, extendedPoint];
}

function makeMovable(group, side, id) {
  group.classList.add("movable-player");
  const isPlaySpecificRunningBack = () => appTab === "create"
    && createScreen === "play"
    && side === "offense"
    && id === "RB";
  if (isPlaySpecificRunningBack()) group.classList.add("play-specific-running-back");
  group.addEventListener("click", event => {
    event.stopPropagation();
    const createMove = appTab === "create" && boardMode === "move"
      && ((side === "offense" && createScreen === "formation") || (side === "defense" && createScreen === "defense"));
    const defenseOnlyScenarioTool = scenarioTool === "man" || scenarioTool === "zone";
    const scenarioSelect = appTab === "run" && scenarioEditing
      && (!defenseOnlyScenarioTool || side === "defense");
    if (!createMove && !scenarioSelect && !isPlaySpecificRunningBack()) return;
    activeRouteSide = side;
    activeRouteId = id;
    if (appTab === "create") renderPlayControls();
    render();
  });
  group.addEventListener("pointerdown", event => {
    const createMove = appTab === "create" && boardMode === "move"
      && ((side === "offense" && createScreen === "formation") || (side === "defense" && createScreen === "defense"));
    const scenarioMove = appTab === "run" && scenarioEditing && scenarioTool === "move";
    if (!createMove && !scenarioMove && !isPlaySpecificRunningBack()) return;
    event.preventDefault();
    event.stopPropagation();
    activeRouteSide = side;
    activeRouteId = id;
    els.field.setPointerCapture(event.pointerId);
    dragState = { side, id, pointerId: event.pointerId };
  });
}

function appendSegmentSpeedControl(handle, point) {
  if ((point.speed || 1) !== 1) {
    const label = svgEl("text", {
      class: "segment-speed-label",
      x: 13,
      y: -11
    });
    label.textContent = `${Math.round((point.speed || 1) * 100)}%`;
    handle.append(label);
  }
  const foreignObject = svgEl("foreignObject", {
    class: "segment-speed-control",
    x: 12,
    y: -17,
    width: 92,
    height: 35
  });
  const select = document.createElementNS("http://www.w3.org/1999/xhtml", "select");
  select.className = "segment-speed-select";
  select.title = "Speed to this point";
  select.setAttribute("aria-label", "Speed to this route point");
  select.innerHTML = [
    [1, "100%"],
    [.75, "75%"],
    [.5, "50%"],
    [.25, "25%"],
    [.1, "10%"]
  ].map(([value, label]) =>
    `<option value="${value}">${label} to here</option>`
  ).join("");
  select.value = String(point.speed || 1);
  select.addEventListener("pointerdown", event => event.stopPropagation());
  select.addEventListener("click", event => event.stopPropagation());
  select.addEventListener("change", event => {
    event.stopPropagation();
    point.speed = Number(event.target.value) || 1;
    saveAllLibraries();
    renderRoutesAndPlayers();
  });
  foreignObject.append(select);
  handle.append(foreignObject);
}

function renderTestInteractionOverlay() {
  if (appTab !== "test" || !testRoundReady || testAnswerRevealed) return;
  const qbPoint = animationState?.offense?.QB || offensePosition("QB");
  if (testQbLookPoint && !testPlayDead()) {
    els.routes.append(svgEl("line", {
      class: "qb-look-line",
      x1: qbPoint.x,
      y1: qbPoint.y,
      x2: testQbLookPoint.x,
      y2: testQbLookPoint.y
    }));
    els.routes.append(svgEl("circle", {
      class: "qb-look-dot",
      cx: testQbLookPoint.x,
      cy: testQbLookPoint.y,
      r: 6
    }));
  }
  if (testPlayResult?.dead && !testThrowState) {
    const resultText = svgEl("text", {
      class: `throw-result ${testPlayResult.className || "breakup"}`,
      x: testPlayResult.point.x,
      y: testPlayResult.point.y - 34,
      "text-anchor": "middle"
    });
    resultText.textContent = testPlayResult.label;
    els.routes.append(resultText);
    return;
  }
  if (!testThrowState) return;
  const elapsed = (performance.now() - testThrowState.startedAt) / 1000;
  const progress = Math.max(0, Math.min(1, elapsed / testThrowState.duration));
  const liveTarget = testThrowState.targetMode === "receiver" && testThrowState.receiverId
    ? animationState?.offense?.[testThrowState.receiverId] || testThrowState.target
    : testThrowState.target;
  if (!testThrowState.resolved) {
    testThrowState.target = { ...liveTarget };
  }
  const arc = Math.sin(progress * Math.PI) * 18;
  const ballPoint = {
    x: testThrowState.start.x + ((liveTarget.x - testThrowState.start.x) * progress),
    y: testThrowState.start.y + ((liveTarget.y - testThrowState.start.y) * progress) - arc
  };
  els.routes.append(svgEl("line", {
    class: "throw-trajectory",
    x1: testThrowState.start.x,
    y1: testThrowState.start.y,
    x2: liveTarget.x,
    y2: liveTarget.y
  }));
  if (!testThrowState.resolved || testThrowState.outcome?.className !== "complete") {
    const football = svgEl("ellipse", {
      class: "test-football",
      cx: ballPoint.x,
      cy: ballPoint.y,
      rx: 10,
      ry: 5,
      transform: `rotate(${Math.atan2(liveTarget.y - testThrowState.start.y, liveTarget.x - testThrowState.start.x) * 180 / Math.PI} ${ballPoint.x} ${ballPoint.y})`
    });
    els.routes.append(football);
  }
  if (progress >= 1 && !testThrowState.resolved) {
    testThrowState.target = { ...liveTarget };
    testThrowState.outcome = evaluateThrowOutcome(testThrowState.receiverId, liveTarget);
    markTestThrowDead(testThrowState.outcome, liveTarget);
    if (!testThrowState.receiverId && testThrowState.outcome.receiverId) {
      testThrowState.receiverId = testThrowState.outcome.receiverId;
      testThrowState.targetMode = "receiver";
    }
    testThrowState.resolved = true;
    if (testThrowState.outcome.className === "complete" && testThrowState.receiverId) {
      const catchPoint = animationState?.offense?.[testThrowState.receiverId] || liveTarget;
      testThrowState.catchRun = { current: { ...catchPoint } };
      animationState ||= { offense: {}, defense: {} };
      animationState.offense[testThrowState.receiverId] = { ...catchPoint };
      scheduleTestThrowRender();
    }
    const targetLabel = testThrowState.receiverId
      ? ` to ${offenseLabel(testThrowState.receiverId)}`
      : " at the spot";
    els.testStatus.textContent = `${testThrowState.outcome.label}${targetLabel}${testThrowState.outcome.defenderId ? ` by ${currentDefense().labels[testThrowState.outcome.defenderId] || testThrowState.outcome.defenderId}` : ""}.`;
  }
  if (testThrowState.resolved && testThrowState.outcome) {
    const labelPoint = testThrowState.catchRun?.current || testThrowState.target;
    const resultText = svgEl("text", {
      class: `throw-result ${testThrowState.catchRun?.tackled ? "breakup" : testThrowState.outcome.className}`,
      x: labelPoint.x,
      y: labelPoint.y - 34,
      "text-anchor": "middle"
    });
    resultText.textContent = testThrowState.catchRun?.tackled ? "Tackled" : testThrowState.outcome.label;
    els.routes.append(resultText);
  }
}

function renderRoutesAndPlayers() {
  els.routes.innerHTML = "";
  els.players.innerHTML = "";
  els.activeRouteLabel.textContent = activeRouteDisplayLabel();
  const showTestAnswers = appTab === "test" && testAnswerRevealed;
  const showOffensiveRoutes = isRunLikeMode()
    || (appTab === "create" && createScreen === "play");
  skillPositions.forEach(position => {
    const playerColor = positionColor(position.id, "offense");
    const playerTextColor = readableTextColor(playerColor);
    const basePlayerPosition = editorOffensePositions()[position.id];
    const playerPosition = offensePosition(position.id);
    const motion = showOffensiveRoutes ? currentMotion(position.id) : [];
    const snapPosition = motionEnd(basePlayerPosition, motion);
    const baseRoute = currentPlay().routes[position.id] || [];
    const routeOffset = {
      x: snapPosition.x - basePlayerPosition.x,
      y: snapPosition.y - basePlayerPosition.y
    };
    const route = showOffensiveRoutes
      ? appTab === "test" && !testAnswerRevealed
        ? baseRoute.map(point => ({
            ...point,
            x: point.x + routeOffset.x,
            y: point.y + routeOffset.y
          }))
        : postSnapRoute(position.id, basePlayerPosition)
      : [];
    const isSelectedOption = appTab === "create" && createScreen === "play"
      && activeRouteSide === "offense" && activeRouteId === position.id
      && selectedRouteOptionId !== "base";
    const runOption = appTab === "run" || (appTab === "test" && testAnswerRevealed)
      ? matchedRouteOption(currentPlay(), position.id, selectedDefenseId)
      : null;
    const showSplitRunOption = Boolean(
      showOffensiveRoutes
      && runOption?.anchor
      && runOption.points.length
      && !scenarioEditing
    );
    appendRoutePath(els.routes, basePlayerPosition, motion, {
      fill: "none",
      stroke: playerColor,
      "stroke-width": activeRouteSide === "offense" && position.id === activeRouteId && playPathType === "motion" ? 6 : 4,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-dasharray": "7 6",
      "marker-end": motion.length ? "url(#motionArrow)" : "",
      opacity: .88
    });
    if (showSplitRunOption) {
      const parts = routeBranchParts(currentPlay(), position.id, runOption, basePlayerPosition);
      const displayedStem = parts.stem.map(point => ({
        ...point,
        x: point.x + routeOffset.x,
        y: point.y + routeOffset.y
      }));
      const displayedAnchor = {
        x: parts.anchor.x + routeOffset.x,
        y: parts.anchor.y + routeOffset.y
      };
      const displayedBranch = parts.branch.map(point => ({
        ...point,
        x: point.x + routeOffset.x,
        y: point.y + routeOffset.y
      }));
      appendRoutePath(els.routes, snapPosition, displayedStem, {
        fill: "none",
        stroke: playerColor,
        "stroke-width": 6,
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        opacity: .82,
        filter: "url(#shadow)"
      });
      appendRoutePath(els.routes, displayedAnchor, displayedBranch, {
        fill: "none",
        stroke: playerColor,
        "stroke-width": 6,
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-dasharray": "9 6",
        "marker-end": "url(#optionArrow)",
        opacity: .95,
        filter: "url(#shadow)"
      });
    } else {
      appendRoutePath(els.routes, snapPosition, route, {
        fill: "none",
        stroke: playerColor,
        "stroke-width": activeRouteSide === "offense" && position.id === activeRouteId && playPathType === "route" ? 8 : 6,
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "marker-end": route.length ? "url(#arrow)" : "",
        opacity: activeRouteSide === "offense" && position.id === activeRouteId ? 1 : .78,
        filter: "url(#shadow)"
      });
    }
    if ((appTab === "create" && createScreen === "play")
      || (appTab === "test" && !testAnswerRevealed)) {
      routeOptionsFor(currentPlay(), position.id).forEach(option => {
        const storedAnchor = routeAnchorPoint(basePlayerPosition, baseRoute, option.anchor);
        if (!storedAnchor) return;
        const displayAnchor = {
          x: storedAnchor.x + routeOffset.x,
          y: storedAnchor.y + routeOffset.y
        };
        const displayPoints = option.points.map(point => ({
          ...point,
          x: point.x + routeOffset.x,
          y: point.y + routeOffset.y
        }));
        const selected = isSelectedOption && option.id === selectedRouteOptionId;
        appendRoutePath(els.routes, displayAnchor, displayPoints, {
          fill: "none",
          stroke: playerColor,
          "stroke-width": selected ? 7 : 5,
          "stroke-linecap": "round",
          "stroke-linejoin": "round",
          "stroke-dasharray": "9 6",
          "marker-end": displayPoints.length ? "url(#optionArrow)" : "",
          opacity: selected ? 1 : .62,
          filter: "url(#shadow)"
        });
        els.routes.append(svgEl("circle", {
          class: "route-branch-anchor",
          cx: displayAnchor.x,
          cy: displayAnchor.y,
          r: selected ? 7 : 5,
          fill: selected ? playerColor : "#10231c",
          stroke: playerColor,
          "stroke-width": 3,
          opacity: selected ? 1 : .75
        }));
      });

      if (appTab === "create" && isSelectedOption && baseRoute.length) {
        const displayedBaseRoute = baseRoute.map(point => ({
          ...point,
          x: point.x + routeOffset.x,
          y: point.y + routeOffset.y
        }));
        const branchTarget = svgEl("path", {
          class: "route-branch-target",
          d: displayedBaseRoute.length === 1
            ? `M ${snapPosition.x} ${snapPosition.y} L ${displayedBaseRoute[0].x} ${displayedBaseRoute[0].y}`
            : routePathData(snapPosition, displayedBaseRoute),
          fill: "none",
          stroke: "rgba(201,244,92,.001)",
          "stroke-width": 26
        });
        branchTarget.addEventListener("click", event => {
          event.preventDefault();
          event.stopPropagation();
          const point = eventToFieldPoint(event);
          const nearest = nearestRouteAnchor(snapPosition, displayedBaseRoute, point);
          const option = selectedRouteOption(position.id);
          if (!nearest || !option) return;
          option.anchor = {
            segmentIndex: nearest.segmentIndex,
            t: nearest.t
          };
          renderPlayControls();
          render();
        });
        els.routes.append(branchTarget);
      }
    }

    const isSelected = (appTab === "create" || scenarioEditing) && activeRouteSide === "offense" && activeRouteId === position.id;
    const group = svgEl("g", { transform: `translate(${playerPosition.x} ${playerPosition.y})`, filter: "url(#shadow)" });
    if (isSelected) {
      group.classList.add("selected-player");
      group.append(svgEl("circle", { class: "selection-ring", r: 25 }));
    }
    group.classList.add("route-hit-target");
    makeMovable(group, "offense", position.id);
    group.addEventListener("click", event => {
      event.stopPropagation();
      if (appTab === "test" && testRoundReady && !testAnswerRevealed) {
        startTestThrow(position.id);
        return;
      }
      const createMan = appTab === "create" && createScreen === "defense"
        && defenseAssignmentMode === "man" && activeRouteSide === "defense";
      const scenarioMan = appTab === "run" && scenarioEditing
        && scenarioTool === "man" && activeRouteSide === "defense";
      if (createMan || scenarioMan) {
        assignMan(activeRouteId, position.id);
        if (appTab === "create") saveDefenses();
        render();
        return;
      }
      if (appTab !== "create" || boardMode === "move" || createScreen !== "play") return;
      activeRouteSide = "offense";
      activeRouteId = position.id;
      renderPlayControls();
      renderRoutesAndPlayers();
    });
    if (appTab === "test" && testRoundReady && !testAnswerRevealed) {
      group.append(svgEl("circle", {
        r: 28,
        fill: "transparent",
        "pointer-events": "all"
      }));
    }
    group.append(svgEl("circle", {
      r: 18,
      fill: playerColor,
      stroke: isSelected ? "#f4ffd0" : "#fff5d7",
      "stroke-width": 3
    }));
    const text = svgEl("text", { x: 0, y: 4, "text-anchor": "middle", fill: playerTextColor, "font-size": 10, "font-weight": 950 });
    text.textContent = offenseLabel(position.id);
    group.append(text);
    if (testThrowState?.resolved
      && testThrowState.outcome?.className === "complete"
      && testThrowState.receiverId === position.id) {
      group.append(svgEl("ellipse", {
        class: "caught-football",
        cx: 14,
        cy: -12,
        rx: 8,
        ry: 4,
        transform: "rotate(-24 14 -12)"
      }));
    }
    els.players.append(group);

    const editingCreatePath = appTab === "create" && createScreen === "play"
      && activeRouteSide === "offense" && position.id === activeRouteId;
    const editingScenarioPath = appTab === "run" && scenarioEditing && scenarioTool === "draw"
      && activeRouteSide === "offense" && position.id === activeRouteId;
    if (editingCreatePath || editingScenarioPath) {
      const editingMotion = editingCreatePath && playPathType === "motion";
      const editablePath = editingMotion ? motion : routeForFormation(position.id);
      const displayOffset = !editingMotion && motion.length
        ? routeOffset
        : { x: 0, y: 0 };
      const optionAnchor = editingCreatePath && !editingMotion
        ? routeAnchorPoint(
            basePlayerPosition,
            currentPlay().routes[position.id] || [],
            selectedRouteOption(position.id)?.anchor
          )
        : null;
      editablePath.forEach((point, index) => {
        const displayPoint = !editingMotion
          ? {
              ...point,
              x: point.x + displayOffset.x,
              y: point.y + displayOffset.y
            }
          : point;
        const canRound = index < editablePath.length - 1;
        const handle = svgEl("g", { transform: `translate(${displayPoint.x} ${displayPoint.y})` });
        handle.classList.add("route-handle");
        if (canRound) handle.classList.add("round-toggle");
        handle.append(svgEl("circle", {
          r: canRound ? 9 : 7,
          fill: canRound && point.rounded ? "#c9f45c" : "#fffdf7",
          stroke: editingMotion
            ? playerColor
            : selectedRouteOptionId !== "base"
              ? playerColor
              : (canRound ? "#10231c" : playerColor),
          "stroke-width": 3
        }));
        if (editingCreatePath && !editingMotion && canRound) {
          appendSegmentSpeedControl(handle, point);
        }
        handle.addEventListener("pointerdown", event => beginPathPointDrag(
          event,
          editablePath,
          index,
          displayOffset,
          optionAnchor || basePlayerPosition,
          canRound
            ? () => {
                point.rounded = !point.rounded;
              }
            : null
        ));
        handle.addEventListener("click", event => event.stopPropagation());
        els.routes.append(handle);
      });
    }
  });

  offensiveLine.forEach(lineman => {
    const playerColor = positionColor(lineman.id, "offense");
    const playerTextColor = readableTextColor(playerColor);
    const basePlayerPosition = editorOffensePositions()[lineman.id];
    const playerPosition = offensePosition(lineman.id);
    const route = isRunLikeMode() ? routeForFormation(lineman.id) : [];
    appendRoutePath(els.routes, basePlayerPosition, route, {
      fill: "none",
      stroke: playerColor,
      "stroke-width": activeRouteSide === "offense" && lineman.id === activeRouteId ? 7 : 5,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "marker-end": route.length ? "url(#arrow)" : "",
      opacity: .78,
      filter: "url(#shadow)"
    });
    const isSelected = (appTab === "create" || scenarioEditing) && activeRouteSide === "offense" && activeRouteId === lineman.id;
    const group = svgEl("g", { transform: `translate(${playerPosition.x} ${playerPosition.y})`, filter: "url(#shadow)" });
    if (isSelected) {
      group.classList.add("selected-player");
      group.append(svgEl("circle", { class: "selection-ring", r: 24 }));
    }
    makeMovable(group, "offense", lineman.id);
    group.append(svgEl("rect", {
      x: -15,
      y: -15,
      width: 30,
      height: 30,
      rx: 5,
      fill: playerColor,
      stroke: isSelected ? "#f4ffd0" : "#fff5d7",
      "stroke-width": 3
    }));
    const text = svgEl("text", { x: 0, y: 4, "text-anchor": "middle", fill: playerTextColor, "font-size": 9, "font-weight": 950 });
    text.textContent = lineman.label;
    group.append(text);
    els.players.append(group);
  });

  const qbStart = editorOffensePositions().QB;
  const qbColor = positionColor("QB", "offense");
  const qbTextColor = readableTextColor(qbColor);
  const qbPosition = offensePosition("QB");
  const qbRoute = showOffensiveRoutes ? routeForFormation("QB") : [];
  appendRoutePath(els.routes, qbStart, qbRoute, {
    fill: "none",
    stroke: qbColor,
    "stroke-width": activeRouteSide === "offense" && activeRouteId === "QB" ? 7 : 5,
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "marker-end": qbRoute.length ? "url(#arrow)" : "",
    opacity: .78,
    filter: "url(#shadow)"
  });
  const qbSelected = (appTab === "create" || scenarioEditing) && activeRouteSide === "offense" && activeRouteId === "QB";
  const qb = svgEl("g", { transform: `translate(${qbPosition.x} ${qbPosition.y})`, filter: "url(#shadow)" });
  if (qbSelected) {
    qb.classList.add("selected-player");
    qb.append(svgEl("circle", { class: "selection-ring", r: 26 }));
  }
  makeMovable(qb, "offense", "QB");
  qb.classList.add("route-hit-target");
  qb.addEventListener("click", event => {
    event.stopPropagation();
    if (appTab !== "create" || createScreen !== "play" || boardMode === "move") return;
    activeRouteSide = "offense";
    activeRouteId = "QB";
    selectedRouteOptionId = "base";
    playPathType = "route";
    renderPlayControls();
    renderRoutesAndPlayers();
  });
  qb.append(svgEl("circle", {
    r: 19,
    fill: qbColor,
    stroke: qbSelected ? "#f4ffd0" : "#fff5d7",
    "stroke-width": 3
  }));
  const qbText = svgEl("text", { x: 0, y: 4, "text-anchor": "middle", fill: qbTextColor, "font-size": 10, "font-weight": 950 });
  qbText.textContent = "QB";
  qb.append(qbText);
  els.players.append(qb);
  renderTestInteractionOverlay();

  const editingCreateQbPath = appTab === "create" && createScreen === "play"
    && activeRouteSide === "offense" && activeRouteId === "QB";
  const editingScenarioQbPath = appTab === "run" && scenarioEditing
    && scenarioTool === "draw" && activeRouteSide === "offense"
    && activeRouteId === "QB";
  if (editingCreateQbPath || editingScenarioQbPath) {
    qbRoute.forEach((point, index) => {
      const canRound = index < qbRoute.length - 1;
      const handle = svgEl("g", { transform: `translate(${point.x} ${point.y})` });
      handle.classList.add("route-handle");
      if (canRound) handle.classList.add("round-toggle");
      handle.append(svgEl("circle", {
        r: canRound ? 9 : 7,
        fill: canRound && point.rounded ? "#c9f45c" : "#fffdf7",
        stroke: canRound ? "#10231c" : qbColor,
        "stroke-width": 3
      }));
      if (editingCreateQbPath && canRound) appendSegmentSpeedControl(handle, point);
      handle.addEventListener("pointerdown", event => beginPathPointDrag(
        event,
        qbRoute,
        index,
        { x: 0, y: 0 },
        qbStart,
        canRound
          ? () => {
              point.rounded = !point.rounded;
            }
          : null
      ));
      handle.addEventListener("click", event => event.stopPropagation());
      els.routes.append(handle);
    });
  }
}

let defenderRenderIndex = 0;
let defenderStarts = {};

function defenderVisionConePath(origin, facing, length = 185, halfAngle = Math.PI / 5.2) {
  const baseAngle = Math.atan2(facing.y, facing.x);
  const left = baseAngle - halfAngle;
  const right = baseAngle + halfAngle;
  const leftPoint = {
    x: origin.x + (Math.cos(left) * length),
    y: origin.y + (Math.sin(left) * length)
  };
  const rightPoint = {
    x: origin.x + (Math.cos(right) * length),
    y: origin.y + (Math.sin(right) * length)
  };
  return `M ${origin.x} ${origin.y} L ${leftPoint.x} ${leftPoint.y} A ${length} ${length} 0 0 1 ${rightPoint.x} ${rightPoint.y} Z`;
}

function normalizeVector(vector) {
  const length = Math.hypot(vector.x, vector.y) || 1;
  return { x: vector.x / length, y: vector.y / length };
}

function rotateVector(vector, angle) {
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);
  return {
    x: (vector.x * cos) - (vector.y * sin),
    y: (vector.x * sin) + (vector.y * cos)
  };
}

function vectorToward(from, to) {
  return normalizeVector({
    x: to.x - from.x,
    y: to.y - from.y
  });
}

function pointLineDistance(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = (dx * dx) + (dy * dy) || 1;
  const t = Math.max(0, Math.min(1, (((point.x - start.x) * dx) + ((point.y - start.y) * dy)) / lengthSquared));
  const projection = {
    x: start.x + (dx * t),
    y: start.y + (dy * t)
  };
  return Math.hypot(point.x - projection.x, point.y - projection.y);
}

function backfieldReadPoint() {
  return { x: fieldWidth / 2, y: lineOfScrimmage + 34 };
}

function lineOfScrimmageReadPoint(state) {
  return {
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, state.x)),
    y: lineOfScrimmage + 12
  };
}

function ballFacingVector(state) {
  return vectorToward(state, lineOfScrimmageReadPoint(state));
}

function setDefenderEyeState(state, facing, targetId = "", mode = "landmark") {
  state.facing = normalizeVector(facing);
  state.eyeTargetId = targetId;
  state.eyeMode = mode;
}

function animationElapsedSeconds() {
  if (!animationPlayback) return 0;
  return Math.max(
    0,
    ((performance.now() - animationPlayback.startedAt - animationPlayback.pausedDuration) / 1000) * (runSpeed || 1)
  );
}

function appendDefenderFieldOfView(id, playerPosition, defenderColor, zoneAssignment, manTarget, route) {
  if (!showDefenderFieldOfView || (appTab === "test" && !testAnswerRevealed)) return;
  if (!zoneAssignment && !manTarget) return;
  const liveEyes = animationPlayback?.defenderEyes?.[id];
  const style = zoneAssignment
    ? zoneStyle(zoneAssignment, { start: defenderStarts[id] || playerPosition })
    : {
        isDeepSafety: playerPosition.y < lineOfScrimmage - 190,
        isFlatDefender: playerPosition.y > lineOfScrimmage - 110,
        isCurlFlat: playerPosition.x < fieldWidth * .34 || playerPosition.x > fieldWidth * .66
      };
  const readLandmark = zoneAssignment
      ? { x: zoneAssignment.x, y: zoneAssignment.y }
      : manTarget
        ? offensePosition(manTarget)
        : (route.length ? route[0] : { x: fieldWidth / 2, y: lineOfScrimmage });
  let facing = liveEyes?.facing
    ? normalizeVector(liveEyes.facing)
    : defenderFacingVector(
        { ...playerPosition, start: defenderStarts[id] || playerPosition, primaryThreatId: null, facing: null },
        style,
        { eyes: zoneAssignment ? "balanced" : "landmark" },
        null,
        readLandmark
      );
  if (!liveEyes?.facing && manTarget) facing = vectorToward(playerPosition, readLandmark);
  const length = style.isDeepSafety ? 230 : style.isFlatDefender || style.isCurlFlat ? 190 : 165;
  const cone = svgEl("path", {
    class: "defender-fov-cone",
    d: defenderVisionConePath(playerPosition, facing, length),
    fill: rgba(defenderColor, .12),
    stroke: defenderColor,
    "stroke-width": 2,
    "stroke-dasharray": "7 8",
    opacity: .62
  });
  els.zones.append(cone);
}

function defender(x, y, label = "") {
  const id = `D${defenderRenderIndex}`;
  defenderRenderIndex += 1;
  const defenderColor = positionColor(id, "defense");
  const defenderTextColor = readableTextColor(defenderColor);
  currentDefense().labels ||= {};
  const savedLabel = currentDefense().labels[id];
  const displayLabel = appTab === "test" && /^(?:D)?\d+$/i.test(savedLabel || "")
    ? label || id
    : savedLabel || label || id;
  const saved = isRunLikeMode()
    ? (runScenario?.defensePositions[id] || currentDefense().positions[id])
    : currentDefenseEditorPositions()[id];
  defenderStarts[id] = saved || { x, y };
  const playerPosition = animationState?.defense?.[id] || saved || { x, y };
  const route = isRunLikeMode()
    ? runScenarioRoute("defense", id)
    : (currentDefense().routes[id] || []);
  const manTarget = currentManAssignments()[id];
  const zoneAssignment = currentZoneAssignments()[id];
  const showTestAnswers = appTab !== "test" || testAnswerRevealed;
  if (zoneAssignment && showTestAnswers) {
    const selectedZone = activeRouteSide === "defense" && activeRouteId === id;
    const radii = zoneRadii(zoneAssignment);
    const zoneElement = svgEl("ellipse", {
      class: selectedZone ? "zone-draggable" : "",
      cx: zoneAssignment.x,
      cy: zoneAssignment.y,
      rx: radii.x,
      ry: radii.y,
      fill: rgba(defenderColor, .1),
      stroke: defenderColor,
      "stroke-width": selectedZone ? 3 : 2,
      "stroke-dasharray": "8 7",
      opacity: selectedZone ? .78 : .42
    });
    const editingCreateZone = appTab === "create" && createScreen === "defense"
      && defenseAssignmentMode === "zone";
    const editingScenarioZone = appTab === "run" && scenarioEditing
      && scenarioTool === "zone";
    if (selectedZone && (editingCreateZone || editingScenarioZone)) {
      zoneElement.addEventListener("click", event => event.stopPropagation());
      zoneElement.addEventListener("pointerdown", event => {
        event.preventDefault();
        event.stopPropagation();
        const point = eventToFieldPoint(event);
        els.field.setPointerCapture(event.pointerId);
        dragState = {
          side: "zone-move",
          zone: zoneAssignment,
          pointerId: event.pointerId,
          offsetX: point.x - zoneAssignment.x,
          offsetY: point.y - zoneAssignment.y
        };
      });
    }
    els.zones.append(zoneElement);
    els.zones.append(svgEl("line", {
      x1: playerPosition.x,
      y1: playerPosition.y,
      x2: zoneAssignment.x,
      y2: zoneAssignment.y,
      stroke: defenderColor,
      "stroke-width": 2,
      "stroke-dasharray": "4 6",
      opacity: selectedZone ? .75 : .3
    }));
    if (selectedZone && (editingCreateZone || editingScenarioZone)) {
      [
        { kind: "horizontal", direction: "left", x: zoneAssignment.x - radii.x, y: zoneAssignment.y },
        { kind: "horizontal", direction: "right", x: zoneAssignment.x + radii.x, y: zoneAssignment.y },
        { kind: "vertical", direction: "top", x: zoneAssignment.x, y: zoneAssignment.y - radii.y },
        { kind: "vertical", direction: "bottom", x: zoneAssignment.x, y: zoneAssignment.y + radii.y }
      ].forEach(handleData => {
        const handle = svgEl("circle", {
          class: `zone-resize-handle ${handleData.kind} ${handleData.direction}`,
          cx: handleData.x,
          cy: handleData.y,
          r: 8
        });
        handle.addEventListener("pointerdown", event => {
          event.preventDefault();
          event.stopPropagation();
          els.field.setPointerCapture(event.pointerId);
          dragState = {
            side: "zone-resize",
            zone: zoneAssignment,
            kind: handleData.kind,
            direction: handleData.direction,
            pointerId: event.pointerId
          };
        });
        els.zones.append(handle);
      });
    }
  }
  if (manTarget && showTestAnswers) {
    const targetPoint = offensePosition(manTarget);
    els.zones.append(svgEl("line", {
      x1: playerPosition.x,
      y1: playerPosition.y,
      x2: targetPoint.x,
      y2: targetPoint.y,
      stroke: defenderColor,
      "stroke-width": activeRouteSide === "defense" && activeRouteId === id ? 3 : 2,
      "stroke-dasharray": "5 5",
      opacity: activeRouteSide === "defense" && activeRouteId === id ? .95 : .48
    }));
  }
  if (route.length && showTestAnswers) {
    appendRoutePath(els.routes, saved || { x, y }, route, {
      fill: "none",
      stroke: defenderColor,
      "stroke-width": activeRouteSide === "defense" && activeRouteId === id ? 7 : 4,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-dasharray": "10 6",
      "marker-end": "url(#defenseArrow)",
      opacity: appTab === "run" ? .42 : .8
    });
  }
  appendDefenderFieldOfView(id, playerPosition, defenderColor, zoneAssignment, manTarget, route);
  const isSelected = (appTab === "create" || scenarioEditing) && activeRouteSide === "defense" && activeRouteId === id;
  const group = svgEl("g", { transform: `translate(${playerPosition.x} ${playerPosition.y})`, filter: "url(#shadow)" });
  makeMovable(group, "defense", id);
  if (isSelected) {
    group.classList.add("selected-player");
    group.append(svgEl("circle", { class: "selection-ring", r: 23 }));
  }
  group.addEventListener("click", event => {
    event.stopPropagation();
    const createDraw = appTab === "create" && boardMode === "draw";
    const scenarioDraw = appTab === "run" && scenarioEditing && scenarioTool === "draw";
    const createMan = appTab === "create" && createScreen === "defense" && defenseAssignmentMode === "man";
    const createZone = appTab === "create" && createScreen === "defense" && defenseAssignmentMode === "zone";
    const scenarioMan = appTab === "run" && scenarioEditing && scenarioTool === "man";
    const scenarioZone = appTab === "run" && scenarioEditing && scenarioTool === "zone";
    if (!createDraw && !scenarioDraw && !createMan && !scenarioMan && !createZone && !scenarioZone) return;
    activeRouteSide = "defense";
    activeRouteId = id;
    renderPlayControls();
    render();
  });
  group.append(svgEl("circle", {
    r: 15,
    fill: defenderColor,
    stroke: isSelected ? "#f4ffd0" : "#ffd8ca",
    "stroke-width": 2
  }));
  const text = svgEl("text", { x: 0, y: 4, "text-anchor": "middle", fill: defenderTextColor, "font-size": 8, "font-weight": 950 });
  text.textContent = displayLabel;
  group.append(text);
  els.defenders.append(group);

  if (appTab === "create" && createScreen === "defense") {
    const row = document.createElement("label");
    row.className = "defense-label-row";
    row.innerHTML = `<span>Player ${Number(id.slice(1)) + 1} (${escapeHtml(label || "DEF")})</span>`;
    const input = document.createElement("input");
    input.value = displayLabel;
    input.maxLength = 4;
    input.setAttribute("aria-label", `${id} defensive player label`);
    input.addEventListener("input", event => {
      const nextLabel = event.target.value.trim().toUpperCase() || label || id;
      currentDefense().labels[id] = nextLabel;
      text.textContent = nextLabel;
      saveDefenses();
    });
    row.append(input);
    const technique = document.createElement("select");
    technique.className = "defense-technique-select";
    technique.setAttribute("aria-label", `${id} defensive technique`);
    technique.innerHTML = [
      ["balanced", "Balanced"],
      ["keepDepth", "Keep depth"],
      ["midpoint", "Midpoint"],
      ["matchVertical", "Match vertical"],
      ["jumpFirst", "Jump first"],
      ["robInside", "Rob inside"],
      ["wallCrosser", "Wall crosser"]
    ].map(([value, name]) =>
      `<option value="${value}">${name}</option>`
    ).join("");
    technique.value = normalizeDefenderTechnique(currentDefense().techniques?.[id]);
    technique.addEventListener("change", event => {
      currentDefense().techniques ||= {};
      currentDefense().techniques[id] = normalizeDefenderTechnique(event.target.value);
      saveDefenses();
    });
    row.append(technique);
    const assignment = document.createElement("small");
    assignment.className = "defense-assignment-label";
    assignment.textContent = manTarget
      ? `Man: ${offenseLabel(manTarget)}`
      : zoneAssignment && route.length ? "Custom movement + reactive zone"
      : zoneAssignment ? "Reactive zone"
      : route.length ? "Custom path" : "No movement";
    row.append(assignment);
    els.defenseLabels.append(row);
  }

  const editingCreatePath = appTab === "create" && createScreen === "defense"
    && activeRouteSide === "defense" && activeRouteId === id;
  const editingScenarioPath = appTab === "run" && scenarioEditing && scenarioTool === "draw"
    && activeRouteSide === "defense" && activeRouteId === id;
  if (editingCreatePath || editingScenarioPath) {
    route.forEach((point, index) => {
      const canRound = index < route.length - 1;
      const handle = svgEl("g", { transform: `translate(${point.x} ${point.y})` });
      handle.classList.add("route-handle");
      if (canRound) handle.classList.add("round-toggle");
      handle.append(svgEl("circle", {
        r: canRound ? 9 : 7,
        fill: canRound && point.rounded ? "#c9f45c" : "#fffdf7",
        stroke: defenderColor,
        "stroke-width": 3
      }));
      handle.addEventListener("pointerdown", event => beginPathPointDrag(
        event,
        route,
        index,
        { x: 0, y: 0 },
        saved || { x, y },
        canRound
          ? () => {
              point.rounded = !point.rounded;
            }
          : null
      ));
      handle.addEventListener("click", event => event.stopPropagation());
      els.routes.append(handle);
    });
  }
}

function zone(x, y, width, height, label) {
  const rect = svgEl("rect", { x, y, width, height, rx: 36, fill: "rgba(237,112,72,.12)", stroke: "rgba(255,193,171,.48)", "stroke-width": 2, "stroke-dasharray": "8 7" });
  els.zones.append(rect);
  const text = svgEl("text", { x: x + width / 2, y: y + height / 2, "text-anchor": "middle", fill: "rgba(255,220,207,.76)", "font-size": 11, "font-weight": 900, "letter-spacing": 1 });
  text.textContent = label;
  els.zones.append(text);
}

function renderDefense() {
  els.defenders.innerHTML = "";
  els.zones.innerHTML = "";
  els.defenseLabels.innerHTML = "";
  if (appTab === "create" && createScreen !== "defense") return;
  defenderRenderIndex = 0;
  defenderStarts = {};
  const defaults = defaultDefensePositions();
  Object.keys(defaults).forEach((id, index) => {
    const point = defaults[id];
    defender(point.x, point.y, defensePositionLabels[index] || "DEF");
  });
}

function renderNotes() {
  els.notes.innerHTML = "";
  visibleNotes().forEach(note => {
    const dimensions = noteDimensions(note.text);
    note.width = dimensions.width;
    note.height = dimensions.height;
    const { width, height } = dimensions;
    const group = svgEl("g", { transform: `translate(${note.x} ${note.y})` });
    group.classList.add("field-note-box");
    const background = svgEl("rect", { x: 0, y: 0, width, height, rx: 5 });
    group.append(background);

    if (appTab === "create") {
      group.addEventListener("click", event => event.stopPropagation());
      group.addEventListener("pointermove", event => {
        if (dragState?.side === "note") return;
        event.stopPropagation();
        els.routes.querySelector(".drawing-guide")?.remove();
      });
      const dragHandle = svgEl("rect", {
        x: 0,
        y: 0,
        width,
        height: 17,
        rx: 5,
        class: "note-drag-handle"
      });
      dragHandle.addEventListener("pointerdown", event => {
        event.preventDefault();
        event.stopPropagation();
        els.field.setPointerCapture(event.pointerId);
        dragState = {
          side: "note",
          note,
          pointerId: event.pointerId,
          offsetX: eventToFieldPoint(event).x - note.x,
          offsetY: eventToFieldPoint(event).y - note.y
        };
      });
      group.append(dragHandle);

      const foreignObject = svgEl("foreignObject", {
        x: 0,
        y: 0,
        width,
        height
      });
      const editor = document.createElementNS("http://www.w3.org/1999/xhtml", "div");
      editor.className = "note-editor";
      const moveButton = document.createElementNS("http://www.w3.org/1999/xhtml", "button");
      moveButton.type = "button";
      moveButton.className = "note-move-button";
      moveButton.textContent = "::";
      moveButton.title = "Drag note";
      moveButton.setAttribute("aria-label", "Drag note");
      moveButton.addEventListener("pointerdown", event => {
        event.preventDefault();
        event.stopPropagation();
        const point = eventToFieldPoint(event);
        els.field.setPointerCapture(event.pointerId);
        dragState = {
          side: "note",
          note,
          pointerId: event.pointerId,
          offsetX: point.x - note.x,
          offsetY: point.y - note.y
        };
      });
      const textarea = document.createElementNS("http://www.w3.org/1999/xhtml", "textarea");
      textarea.value = note.text;
      textarea.placeholder = "Type a note";
      textarea.setAttribute("aria-label", "Field note");
      ["pointerdown", "pointermove", "pointerup", "click", "dblclick"].forEach(eventName => {
        textarea.addEventListener(eventName, event => event.stopPropagation());
      });
      textarea.addEventListener("focus", () => {
        els.routes.querySelector(".drawing-guide")?.remove();
      });
      textarea.addEventListener("input", event => {
        note.text = event.target.value;
        const next = noteDimensions(note.text);
        note.width = next.width;
        note.height = next.height;
        note.x = Math.min(note.x, fieldWidth - next.width - 8);
        note.y = Math.min(note.y, fieldHeight - next.height - 8);
        group.setAttribute("transform", `translate(${note.x} ${note.y})`);
        background.setAttribute("width", next.width);
        background.setAttribute("height", next.height);
        dragHandle.setAttribute("width", next.width);
        foreignObject.setAttribute("width", next.width);
        foreignObject.setAttribute("height", next.height);
        saveAllLibraries();
      });
      const removeButton = document.createElementNS("http://www.w3.org/1999/xhtml", "button");
      removeButton.type = "button";
      removeButton.className = "note-delete-button";
      removeButton.textContent = "\u00d7";
      removeButton.title = "Delete note";
      removeButton.setAttribute("aria-label", "Delete note");
      removeButton.addEventListener("pointerdown", event => event.stopPropagation());
      removeButton.addEventListener("click", event => {
        event.stopPropagation();
        currentNoteOwner().notes = currentNoteOwner().notes.filter(item => item.id !== note.id);
        saveAllLibraries();
        renderNotes();
      });
      editor.append(moveButton, textarea, removeButton);
      foreignObject.append(editor);
      group.append(foreignObject);
    } else {
      const foreignObject = svgEl("foreignObject", {
        x: 9,
        y: 19,
        width: width - 18,
        height: height - 25
      });
      const display = document.createElementNS("http://www.w3.org/1999/xhtml", "div");
      display.className = "note-display";
      display.textContent = note.text;
      foreignObject.append(display);
      group.append(foreignObject);
    }
    els.notes.append(group);
  });
}

function noteDimensions(text) {
  const content = text || "";
  const lines = content.split("\n");
  const longestLine = Math.max(1, ...lines.map(line => line.length));
  const width = Math.max(38, Math.min(360, 25 + (longestLine * 7)));
  const charactersPerLine = Math.max(1, Math.floor((width - 20) / 7));
  const wrappedLines = lines.reduce((total, line) =>
    total + Math.max(1, Math.ceil(line.length / charactersPerLine)), 0);
  const height = Math.max(44, 27 + (wrappedLines * 17));
  return { width, height };
}

function saveAllLibraries() {
  scheduleAutosave();
}

function inferRouteTags(position, route) {
  if (!route.length) return [];
  const end = route[route.length - 1];
  const dx = end.x - position.x;
  const dy = end.y - position.y;
  const distance = Math.hypot(dx, dy);
  const tags = [];

  if (dy < -150) tags.push("vertical");
  if (distance < 145) tags.push("quick", "underneath");
  if (Math.abs(dy) < 95) tags.push("flat", "cross");
  if (route.length > 1) tags.push("break");
  if (Math.abs(end.x - 450) < Math.abs(position.x - 450)) tags.push("inside", "middle");
  if (Math.abs(end.x - 450) > Math.abs(position.x - 450)) tags.push("outside");
  if (dy < -165 && Math.abs(end.x - 450) < 180) tags.push("seam");
  return [...new Set(tags)];
}

function scoreRoute(position, route) {
  const tags = inferRouteTags(position, route);
  const bestTags = ["quick", "vertical", "inside", "outside", "break"];
  return tags.reduce((score, tag) => score + (bestTags.includes(tag) ? 1 : 0), 0);
}

function getRankedReads() {
  return skillPositions
    .filter(position => currentPlay().routes[position.id].length)
    .map(position => ({
      id: position.id,
      position: currentPlay().labels[position.id],
      route: currentPlay().routes[position.id],
      tags: inferRouteTags(offensePosition(position.id), currentPlay().routes[position.id]),
      score: scoreRoute(offensePosition(position.id), currentPlay().routes[position.id])
    }))
    .sort((a, b) => b.score - a.score);
}

function renderReads() {
  els.coachCue.textContent = "Build it, save it, and rep it against any defense.";
  if (appTab === "test") {
    els.boardTitle.textContent = testRoundReady
      ? `${currentPlay().name} | ${currentFormation().name}`
      : "Test Your Reads";
  } else if (appTab === "run") {
    els.boardTitle.textContent = `${currentPlay().name} | ${currentFormation().name} vs. ${currentDefense().name}`;
  } else if (createScreen === "formation") {
    els.boardTitle.textContent = currentFormation().name;
  } else if (createScreen === "defense") {
    els.boardTitle.textContent = defenseAlignmentMode
      ? `${currentDefense().name} vs. ${currentFormation().name}`
      : currentDefense().name;
  } else {
    els.boardTitle.textContent = currentPlay().name;
  }
}

function defaultTrenchesPositions(frontId = trenchesState.frontId) {
  const front = trenchesFrontOptions()[frontId] || trenchesFronts.starter;
  const customFront = Boolean(trenchesState?.customFronts?.[frontId]);
  const olX = { LT: 300, LG: 375, C: 450, RG: 525, RT: 600 };
  return {
    offense: defaultTrenchesOffensePlayers().map(player => ({
      id: player.id,
      label: player.label,
      x: player.id === "QB" ? 450 : olX[player.id] || 450,
      y: player.id === "QB" ? 405 : 300
    })),
    defense: front.defenders.map((defender, index) => ({
      id: defender.id || `D${index}`,
      label: defender.label,
      x: customFront ? defender.x : 250 + ((defender.x - 330) * 1.15),
      y: defender.y
    }))
  };
}

function trenchesPositions(frontId = trenchesState.frontId) {
  const saved = trenchesState.fronts?.[frontId];
  const defaults = defaultTrenchesPositions(frontId);
  const defaultOffenseIds = new Set(defaults.offense.map(player => player.id));
  const defaultDefenseIds = new Set(defaults.defense.map(player => player.id));
  return {
    offense: [
      ...defaults.offense.map(player => ({
        ...player,
        ...(saved?.offense?.find(item => item.id === player.id) || {})
      })),
      ...((saved?.offense || []).filter(player => !defaultOffenseIds.has(player.id)))
    ],
    defense: [
      ...defaults.defense.map(player => ({
        ...player,
        ...(saved?.defense?.find(item => item.id === player.id) || {})
      })),
      ...((saved?.defense || []).filter(player => !defaultDefenseIds.has(player.id)))
    ]
  };
}

function setTrenchesPositions(frontId, positions) {
  trenchesState.fronts ||= {};
  trenchesState.fronts[frontId] = structuredClone(positions);
  saveTrenchesState();
}

function trenchesFrontFromPositions(name, positions) {
  return {
    name: name.trim().slice(0, 48) || "Custom Front",
    defenders: positions.defense.map(defender => ({
      id: defender.id,
      label: defender.label || "D",
      x: Math.round(defender.x),
      y: Math.round(defender.y)
    }))
  };
}

function saveCurrentTrenchesFront(nameOverride = "") {
  const front = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
  const name = nameOverride || front.name || "Custom Front";
  const positions = trenchesPositions(trenchesState.frontId);
  trenchesState.customFronts ||= {};
  trenchesState.customFronts[trenchesState.frontId] = trenchesFrontFromPositions(name, positions);
  setTrenchesPositions(trenchesState.frontId, positions);
}

function createCustomTrenchesFront(name, positions = trenchesPositions(trenchesState.frontId)) {
  const id = `custom-${crypto.randomUUID()}`;
  trenchesState.customFronts ||= {};
  trenchesState.fronts ||= {};
  trenchesState.customFronts[id] = trenchesFrontFromPositions(name, positions);
  trenchesState.fronts[id] = structuredClone(positions);
  trenchesState.frontId = id;
  saveTrenchesState();
  return id;
}

function editableTrenchesFrontId() {
  if (trenchesState.customFronts?.[trenchesState.frontId]) return trenchesState.frontId;
  const front = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
  const name = window.prompt("Name this custom front:", `${front.name} Custom`);
  if (!name) return null;
  return createCustomTrenchesFront(name);
}

function updateTrenchesSelection(id, side = "offense") {
  trenchesState.selectedSide = side;
  trenchesState.selectedId = id;
  if (els.trenchesSelectedName) els.trenchesSelectedName.textContent = side === "defense" ? `DEF ${id}` : id;
  if (els.trenchesSpeedSelect) els.trenchesSpeedSelect.value = normalizedTrenchSpeedValue(trenchesState.playbackSpeed);
  saveTrenchesState();
}

function selectedTrenchesMovement() {
  if (trenchesState.selectedSide === "defense") {
    trenchesState.defensePaths ||= {};
    trenchesState.defensePaths[trenchesState.selectedId] ||= { path: [], speed: 1 };
    return trenchesState.defensePaths[trenchesState.selectedId];
  }
  trenchesState.assignments[trenchesState.selectedId] ||= { path: [], targetId: "", speed: 1 };
  return trenchesState.assignments[trenchesState.selectedId];
}

function normalizedTrenchSpeedValue(speed) {
  const value = Number(speed) || 1;
  const choices = [1, 0.75, 0.5, 0.25, 0.1];
  return String(choices.reduce((closest, choice) =>
    Math.abs(choice - value) < Math.abs(closest - value) ? choice : closest, 1));
}

function deleteTrenchesOffensePlayer(playerId) {
  const positions = trenchesPositions(trenchesState.frontId);
  positions.offense = positions.offense.filter(player => player.id !== playerId);
  setTrenchesPositions(trenchesState.frontId, positions);
  delete trenchesState.assignments[playerId];
  if (trenchesState.selectedSide === "offense" && trenchesState.selectedId === playerId) {
    updateTrenchesSelection("LT", "offense");
  } else {
    saveTrenchesState();
  }
  renderTrenches();
}

function deleteCurrentTrenchesFront() {
  if (trenchesState.frontId === "starter") {
    window.alert("The starter front stays as your blank starting point. Save a custom front first, then you can delete it.");
    return;
  }
  const frontName = trenchesFrontOptions()[trenchesState.frontId]?.name || "this front";
  if (!window.confirm(`Delete ${frontName}?`)) return;
  delete trenchesState.customFronts?.[trenchesState.frontId];
  delete trenchesState.fronts?.[trenchesState.frontId];
  trenchesState.plays.forEach(play => {
    if (play.frontId === trenchesState.frontId) play.frontId = "starter";
  });
  trenchesState.frontId = "starter";
  saveTrenchesState();
  renderTrenches();
  showSaveSuccess("Front deleted");
}

function addTrenchesDefender({ saveTemplate = false } = {}) {
  resetTrenchesRun();
  if (saveTemplate && !trenchesState.customFronts?.[trenchesState.frontId]) {
    const front = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
    createCustomTrenchesFront(els.trenchesFrontName?.value?.trim() || `${front.name} Custom`);
  }
  const positions = trenchesPositions(trenchesState.frontId);
  const count = positions.defense.length + 1;
  const newDefender = {
    id: `D${crypto.randomUUID().slice(0, 8)}`,
    label: `D${count}`,
    x: 450,
    y: 180
  };
  positions.defense.push(newDefender);
  setTrenchesPositions(trenchesState.frontId, positions);
  if (saveTemplate) saveCurrentTrenchesFront();
  updateTrenchesSelection(newDefender.id, "defense");
  renderTrenches();
  showSaveSuccess("Defender added");
}

function saveTrenchesPlayFromState(nameOverride = "") {
  const name = (nameOverride || els.trenchesPlayName?.value || trenchesState.playName || "Untitled Trench Play").trim() || "Untitled Trench Play";
  const play = {
    id: trenchesState.selectedPlayId || crypto.randomUUID(),
    name,
    frontId: trenchesState.frontId,
    playbackSpeed: trenchesState.playbackSpeed || 1,
    assignments: structuredClone(trenchesState.assignments),
    defensePaths: structuredClone(trenchesState.defensePaths || {}),
    fronts: structuredClone(trenchesState.fronts || {}),
    notes: structuredClone(trenchesState.notes || [])
  };
  const index = trenchesState.plays.findIndex(item => item.id === play.id);
  if (index >= 0) trenchesState.plays[index] = play;
  else trenchesState.plays.push(play);
  trenchesState.selectedPlayId = play.id;
  trenchesState.playName = play.name;
  saveTrenchesState();
  return play;
}

function loadTrenchesPlay(playId) {
  const play = trenchesState.plays.find(item => item.id === playId);
  if (!play) return;
  resetTrenchesRun();
  trenchesState.selectedPlayId = play.id;
  trenchesState.playName = play.name;
  trenchesState.frontId = play.frontId || trenchesState.frontId;
  trenchesState.playbackSpeed = Number(play.playbackSpeed) || 1;
  trenchesState.assignments = {
    ...defaultTrenchesAssignments(),
    ...(play.assignments || {})
  };
  trenchesState.defensePaths = structuredClone(play.defensePaths || {});
  trenchesState.fronts = structuredClone(play.fronts || {});
  trenchesState.notes = structuredClone(play.notes || []);
  saveTrenchesState();
  renderTrenches();
}

function setTrenchesMode(mode) {
  trenchesState.mode = mode === "draw" ? "draw" : "move";
  saveTrenchesState();
  renderTrenches();
}

function setTrenchesPanelTab(tab) {
  trenchesState.panelTab = tab === "defense" ? "defense" : "offense";
  saveTrenchesState();
  renderTrenches();
}

function trenchNoteDimensions(text) {
  const dimensions = noteDimensions(text || "");
  return {
    width: Math.max(34, Math.min(260, dimensions.width)),
    height: Math.max(34, Math.min(180, dimensions.height))
  };
}

function trenchesPointFromEvent(event) {
  const svg = els.trenchesBoard.querySelector("svg");
  const point = svg.createSVGPoint();
  point.x = event.clientX;
  point.y = event.clientY;
  const transformed = point.matrixTransform(svg.getScreenCTM().inverse());
  return {
    x: Math.max(70, Math.min(830, Math.round(transformed.x))),
    y: Math.max(70, Math.min(465, Math.round(transformed.y)))
  };
}

function trenchesEndPoint(player, side) {
  if (side === "offense") {
    const path = trenchesState.assignments[player.id]?.path || [];
    return path.length ? path[path.length - 1] : { x: player.x, y: player.y };
  }
  return { x: player.x, y: Math.min(360, player.y + 75) };
}

function pathLength(start, points) {
  return [start, ...points].slice(1).reduce((total, point, index, path) =>
    total + Math.hypot(point.x - path[index].x, point.y - path[index].y), 0);
}

function pointOnPath(start, points, progress) {
  if (!points.length) return start;
  const path = [start, ...points];
  const total = pathLength(start, points) || 1;
  let target = total * progress;
  for (let index = 0; index < path.length - 1; index += 1) {
    const from = path[index];
    const to = path[index + 1];
    const segment = Math.hypot(to.x - from.x, to.y - from.y);
    if (target <= segment) {
      const ratio = segment ? target / segment : 0;
      return {
        x: from.x + ((to.x - from.x) * ratio),
        y: from.y + ((to.y - from.y) * ratio)
      };
    }
    target -= segment;
  }
  return path[path.length - 1];
}

function trenchProgress(progress, speed = 1) {
  return Math.max(0, Math.min(1, progress * (Number(speed) || 1)));
}

function trenchPathForPlayer(player, movement = {}, target = null) {
  const path = Array.isArray(movement.path) ? movement.path : [];
  if (target && path.length) {
    const last = path[path.length - 1];
    const targetPoint = { x: target.x, y: target.y, rounded: false };
    return Math.hypot(last.x - target.x, last.y - target.y) > 8
      ? [...path, targetPoint]
      : [...path.slice(0, -1), targetPoint];
  }
  if (path.length) return path;
  return target ? [{ x: target.x, y: target.y, rounded: false }] : [];
}

function defenderTrenchDestination(defender) {
  const path = trenchesState.defensePaths?.[defender.id]?.path || [];
  return path.length ? path[path.length - 1] : defender;
}

function trenchTravelPoint(player, path, elapsedMs, speed = 1, engaged = false) {
  if (!path.length) return { ...player, travelProgress: 1 };
  const basePixelsPerSecond = 118;
  const contactMultiplier = engaged ? 0.36 : 1;
  const distance = Math.max(1, pathLength(player, path));
  const speedPercent = Math.max(0.1, Math.min(1, Number(speed) || 1));
  const traveled = (elapsedMs / 1000) * basePixelsPerSecond * speedPercent * contactMultiplier;
  const progress = Math.max(0, Math.min(1, traveled / distance));
  return { ...player, ...pointOnPath(player, path, progress), travelProgress: progress };
}

function trenchMovementDurationMs(player, path, speed = 1, contact = false) {
  if (!path.length) return 0;
  const basePixelsPerSecond = 118;
  const speedPercent = Math.max(0.1, Math.min(1, Number(speed) || 1));
  const contactMultiplier = contact ? 0.36 : 1;
  return (pathLength(player, path) / (basePixelsPerSecond * speedPercent * contactMultiplier)) * 1000;
}

function movementVector(start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const length = Math.hypot(dx, dy);
  if (length < 1) return null;
  return { x: dx / length, y: dy / length };
}

function renderTrenches() {
  if (!els.trenchesBoard) return;
  els.trenchesPlayName.value = trenchesState.playName || "";
  els.trenchesPlaySelect.innerHTML = [
    `<option value="">Saved trench plays</option>`,
    ...trenchesState.plays.map(play => `<option value="${play.id}">${escapeHtml(play.name)}</option>`)
  ].join("");
  els.trenchesPlaySelect.value = trenchesState.selectedPlayId || "";
  const frontOptionsMarkup = Object.entries(trenchesFrontOptions())
    .map(([id, front]) => `<option value="${id}">${escapeHtml(front.name)}</option>`)
    .join("");
  els.trenchesFrontSelect.innerHTML = frontOptionsMarkup;
  els.trenchesFrontSelect.value = trenchesState.frontId;
  if (els.trenchesFrontSelectMirror) {
    els.trenchesFrontSelectMirror.innerHTML = frontOptionsMarkup;
    els.trenchesFrontSelectMirror.value = trenchesState.frontId;
  }
  if (els.trenchesFrontName) {
    const front = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
    els.trenchesFrontName.value = front.name || "Starter Front";
  }
  els.trenchesSelectedName.textContent = trenchesState.selectedSide === "defense" ? `DEF ${trenchesState.selectedId}` : trenchesState.selectedId;
  els.trenchesSpeedSelect.value = normalizedTrenchSpeedValue(trenchesState.playbackSpeed);
  els.trenchesMoveButton?.classList.toggle("active", trenchesState.mode !== "draw");
  els.trenchesDrawButton?.classList.toggle("active", trenchesState.mode === "draw");
  document.querySelectorAll("[data-trenches-panel-tab]").forEach(button => {
    button.classList.toggle("active", button.dataset.trenchesPanelTab === trenchesState.panelTab);
  });
  document.querySelectorAll("[data-trenches-pane]").forEach(pane => {
    pane.classList.toggle("active", pane.dataset.trenchesPane === trenchesState.panelTab);
  });

  const positions = trenchesAnimation?.positions || trenchesPositions(trenchesState.frontId);
  const ol = positions.offense;
  const defenders = positions.defense;
  const notes = trenchesState.notes || [];

  els.trenchesBoard.innerHTML = `
    <svg viewBox="0 0 900 520" role="img" aria-label="The Trenches front and offensive line board">
      <defs>
        <marker id="trenchArrow" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto" markerUnits="userSpaceOnUse">
          <path d="M0,0 L0,7 L8,3.5 z" fill="#f2c35a"></path>
        </marker>
        <pattern id="trenchTurf" width="28" height="28" patternUnits="userSpaceOnUse">
          <rect width="28" height="28" fill="#1c5a3e"></rect>
          <path d="M0 28 L28 0" stroke="rgba(255,255,255,.035)" stroke-width="3"></path>
        </pattern>
      </defs>
      <rect width="900" height="520" rx="16" fill="url(#trenchTurf)"></rect>
      ${[80, 140, 200, 260, 320, 380, 440, 500].map(y => `
        <line x1="55" y1="${y}" x2="845" y2="${y}" stroke="rgba(255,255,255,.33)" stroke-width="${y === 320 ? 3 : 2}"></line>
        <line x1="418" y1="${y - 7}" x2="482" y2="${y - 7}" stroke="rgba(255,255,255,.45)" stroke-width="2"></line>
        <line x1="418" y1="${y + 7}" x2="482" y2="${y + 7}" stroke="rgba(255,255,255,.45)" stroke-width="2"></line>
      `).join("")}
      ${[220, 680].map(x => `
        <text x="${x}" y="455" fill="rgba(255,255,255,.32)" font-size="52" font-weight="950" text-anchor="middle" transform="rotate(-90 ${x} 455)">10</text>
      `).join("")}
      <line x1="70" y1="300" x2="830" y2="300" stroke="#f4f8f2" stroke-width="5"></line>
      <text x="82" y="292" fill="#ffffff" font-size="12" font-weight="900">LINE OF SCRIMMAGE</text>
      ${defenders.map(defender => {
        const movement = trenchesState.defensePaths?.[defender.id];
        const pathData = movement?.path?.length ? routePathData(defender, movement.path) : "";
        return `
          ${pathData ? `<path d="${pathData}" fill="none" stroke="#76d7ff" stroke-width="5" stroke-linecap="round" stroke-dasharray="10 8" marker-end="url(#trenchArrow)"></path>` : ""}
          ${(movement?.path || []).map((point, index) => `
            <g class="trenches-path-point" data-trenches-def-point="${defender.id}" data-point-index="${index}">
              <circle cx="${point.x}" cy="${point.y}" r="8" fill="${point.rounded ? "#76d7ff" : "#fffdf7"}" stroke="#102016" stroke-width="2"></circle>
              <text x="${point.x}" y="${point.y + 3}" text-anchor="middle" fill="#102016" font-size="8" font-weight="950">${index + 1}</text>
            </g>
          `).join("")}
        `;
      }).join("")}
      ${defenders.map(defender => `
        <g class="trenches-defender ${trenchesState.selectedSide === "defense" && trenchesState.selectedId === defender.id ? "selected" : ""}" data-trenches-defender="${defender.id}" transform="translate(${defender.x} ${defender.y})">
          <circle cx="0" cy="0" r="24" fill="#103049" stroke="${trenchesState.selectedSide === "defense" && trenchesState.selectedId === defender.id ? "#c9f45c" : "#76d7ff"}" stroke-width="3"></circle>
          <text x="0" y="5" text-anchor="middle" fill="#ffffff" font-size="13" font-weight="900">${escapeHtml(defender.label)}</text>
        </g>
      `).join("")}
      ${ol.map(lineman => {
        const assignment = trenchesState.assignments[lineman.id];
        const pathData = routePathData(lineman, assignment.path || []);
        const target = defenders.find(defender => defender.id === assignment.targetId);
        return `
          ${target ? `<line x1="${lineman.x}" y1="${lineman.y}" x2="${target.x}" y2="${target.y}" stroke="#c9f45c" stroke-width="3" stroke-dasharray="7 7" opacity=".8"></line>` : ""}
          ${assignment.path?.length ? `<path d="${pathData}" fill="none" stroke="#f2c35a" stroke-width="6" stroke-linecap="round" marker-end="url(#trenchArrow)"></path>` : ""}
          ${(assignment.path || []).map((point, index) => `
            <g class="trenches-path-point" data-trenches-point="${lineman.id}" data-point-index="${index}">
              <circle cx="${point.x}" cy="${point.y}" r="9" fill="${point.rounded ? "#c9f45c" : "#fffdf7"}" stroke="#102016" stroke-width="2"></circle>
              <text x="${point.x}" y="${point.y + 3}" text-anchor="middle" fill="#102016" font-size="8" font-weight="950">${index + 1}</text>
            </g>
          `).join("")}
          <g class="trenches-lineman ${trenchesState.selectedSide === "offense" && trenchesState.selectedId === lineman.id ? "selected" : ""}" data-trenches-lineman="${lineman.id}" transform="translate(${lineman.x} ${lineman.y})">
            <rect x="-27" y="-27" width="54" height="54" rx="10" fill="#c9f45c" stroke="${trenchesState.selectedSide === "offense" && trenchesState.selectedId === lineman.id ? "#ffffff" : "#102016"}" stroke-width="${trenchesState.selectedSide === "offense" && trenchesState.selectedId === lineman.id ? 5 : 2}"></rect>
            <text x="0" y="5" text-anchor="middle" fill="#102016" font-size="15" font-weight="950">${lineman.id}</text>
          </g>
        `;
      }).join("")}
      ${notes.map(note => {
        const dimensions = noteDimensions(note.text || "");
        note.width = dimensions.width;
        note.height = dimensions.height;
        return `
          <g class="field-note-box trenches-note" data-trenches-note="${note.id}" transform="translate(${note.x} ${note.y})">
            <rect width="${dimensions.width}" height="${dimensions.height}" rx="6" fill="#f9e08a" stroke="#1b2019" stroke-width="2"></rect>
            <foreignObject x="0" y="0" width="${dimensions.width}" height="${dimensions.height}">
              <div xmlns="http://www.w3.org/1999/xhtml" class="note-editor">
                <button type="button" class="note-move-button" data-trenches-note-handle="${note.id}" title="Drag note" aria-label="Drag note">+</button>
                <button type="button" class="note-delete-button" data-delete-trenches-note="${note.id}" title="Delete note" aria-label="Delete note">x</button>
                <textarea data-trenches-note-text="${note.id}" placeholder="Note">${escapeHtml(note.text || "")}</textarea>
              </div>
            </foreignObject>
          </g>
        `;
      }).join("")}
    </svg>
  `;

  els.trenchesBoard.querySelectorAll("[data-trenches-lineman]").forEach(node => {
    node.addEventListener("click", () => {
      updateTrenchesSelection(node.dataset.trenchesLineman, "offense");
      renderTrenches();
    });
    node.addEventListener("pointerdown", event => startTrenchesDrag(event, "offense", node.dataset.trenchesLineman));
  });
  els.trenchesBoard.querySelectorAll("[data-trenches-defender]").forEach(node => {
    node.addEventListener("click", event => {
      event.stopPropagation();
      if (trenchesState.mode === "draw" && trenchesState.panelTab === "offense" && trenchesState.selectedSide === "offense") {
        const assignment = trenchesState.assignments[trenchesState.selectedId];
        const defenderId = node.dataset.trenchesDefender;
        const positions = trenchesPositions(trenchesState.frontId);
        const defender = positions.defense.find(item => item.id === defenderId);
        assignment.targetId = assignment.targetId === defenderId ? "" : defenderId;
        if (assignment.targetId && defender) {
          const destination = defenderTrenchDestination(defender);
          assignment.path ||= [];
          const last = assignment.path[assignment.path.length - 1];
          if (!last || Math.hypot(last.x - destination.x, last.y - destination.y) > 8) {
            assignment.path.push({ x: destination.x, y: destination.y, rounded: false });
          }
        }
      } else {
        trenchesState.panelTab = trenchesState.panelTab === "front" ? "front" : "defense";
        updateTrenchesSelection(node.dataset.trenchesDefender, "defense");
      }
      saveTrenchesState();
      renderTrenches();
    });
    node.addEventListener("pointerdown", event => startTrenchesDrag(event, "defense", node.dataset.trenchesDefender));
  });
  els.trenchesBoard.querySelectorAll("[data-trenches-point]").forEach(node => {
    node.addEventListener("click", event => {
      event.stopPropagation();
      const assignment = trenchesState.assignments[node.dataset.trenchesPoint];
      const point = assignment?.path?.[Number(node.dataset.pointIndex)];
      if (!point) return;
      point.rounded = !point.rounded;
      trenchesState.selectedSide = "offense";
      trenchesState.selectedId = node.dataset.trenchesPoint;
      saveTrenchesState();
      renderTrenches();
    });
  });
  els.trenchesBoard.querySelectorAll("[data-trenches-def-point]").forEach(node => {
    node.addEventListener("click", event => {
      event.stopPropagation();
      const movement = trenchesState.defensePaths?.[node.dataset.trenchesDefPoint];
      const point = movement?.path?.[Number(node.dataset.pointIndex)];
      if (!point) return;
      point.rounded = !point.rounded;
      updateTrenchesSelection(node.dataset.trenchesDefPoint, "defense");
      renderTrenches();
    });
  });

  const baseOffenseIds = new Set(defaultTrenchesOffensePlayers().map(player => player.id));
  els.trenchesAssignmentsList.innerHTML = ol.map(lineman => {
    const assignment = trenchesState.assignments[lineman.id];
    return `
      <div class="trenches-assignment-chip ${trenchesState.selectedSide === "offense" && trenchesState.selectedId === lineman.id ? "active" : ""}" data-trenches-select="${lineman.id}">
        <input type="text" maxlength="8" value="${escapeHtml(lineman.label || lineman.id)}" data-trenches-off-label="${lineman.id}" aria-label="Offensive player label">
        <span>${(assignment?.path || []).length} path pts${assignment?.targetId ? " | target locked" : ""}</span>
        ${baseOffenseIds.has(lineman.id) ? "" : `<span class="trenches-delete-inline" data-delete-trenches-offense="${lineman.id}">Delete</span>`}
      </div>
    `;
  }).join("");
  els.trenchesAssignmentsList.querySelectorAll("[data-trenches-select]").forEach(button => {
    button.addEventListener("click", () => {
      updateTrenchesSelection(button.dataset.trenchesSelect, "offense");
      renderTrenches();
    });
  });
  els.trenchesAssignmentsList.querySelectorAll("[data-trenches-off-label]").forEach(input => {
    input.addEventListener("click", event => event.stopPropagation());
    input.addEventListener("change", () => {
      const positions = trenchesPositions(trenchesState.frontId);
      const player = positions.offense.find(item => item.id === input.dataset.trenchesOffLabel);
      if (!player) return;
      player.label = input.value.trim() || player.label;
      setTrenchesPositions(trenchesState.frontId, positions);
      renderTrenches();
    });
  });
  els.trenchesAssignmentsList.querySelectorAll("[data-delete-trenches-offense]").forEach(button => {
    button.addEventListener("click", event => {
      event.stopPropagation();
      deleteTrenchesOffensePlayer(button.dataset.deleteTrenchesOffense);
    });
  });

  const currentPositions = trenchesPositions(trenchesState.frontId);
  els.trenchesDefenderList.innerHTML = currentPositions.defense.map(defender => `
    <div class="trenches-defender-row ${trenchesState.selectedSide === "defense" && trenchesState.selectedId === defender.id ? "active" : ""}">
      <input type="text" maxlength="8" value="${escapeHtml(defender.label)}" data-trenches-def-label="${defender.id}" aria-label="Defender label">
      <span class="trenches-path-count">${(trenchesState.defensePaths?.[defender.id]?.path || []).length} pts</span>
      <button class="library-action-button" data-select-trenches-defender="${defender.id}">Select</button>
      <button class="library-action-button danger" data-delete-trenches-defender="${defender.id}">Delete</button>
    </div>
  `).join("");
  els.trenchesDefenderList.querySelectorAll("[data-select-trenches-defender]").forEach(button => {
    button.addEventListener("click", () => {
      trenchesState.panelTab = "defense";
      updateTrenchesSelection(button.dataset.selectTrenchesDefender, "defense");
      renderTrenches();
    });
  });
  els.trenchesDefenderList.querySelectorAll("[data-trenches-def-label]").forEach(input => {
    input.addEventListener("change", () => {
      const positions = trenchesPositions(trenchesState.frontId);
      const defender = positions.defense.find(item => item.id === input.dataset.trenchesDefLabel);
      if (!defender) return;
      defender.label = input.value.trim() || defender.label;
      setTrenchesPositions(trenchesState.frontId, positions);
      renderTrenches();
    });
  });
  els.trenchesDefenderList.querySelectorAll("[data-delete-trenches-defender]").forEach(button => {
    button.addEventListener("click", () => {
      const defenderId = button.dataset.deleteTrenchesDefender;
      const positions = trenchesPositions(trenchesState.frontId);
      positions.defense = positions.defense.filter(item => item.id !== defenderId);
      setTrenchesPositions(trenchesState.frontId, positions);
      delete trenchesState.defensePaths?.[defenderId];
      Object.values(trenchesState.assignments).forEach(assignment => {
        if (assignment.targetId === defenderId) assignment.targetId = "";
      });
      if (trenchesState.selectedSide === "defense" && trenchesState.selectedId === defenderId) {
        trenchesState.selectedSide = "offense";
        trenchesState.selectedId = "LT";
      }
      saveTrenchesState();
      renderTrenches();
    });
  });

  if (els.trenchesFrontDefenderList) {
    els.trenchesFrontDefenderList.innerHTML = currentPositions.defense.map(defender => `
      <div class="trenches-defender-row ${trenchesState.selectedSide === "defense" && trenchesState.selectedId === defender.id ? "active" : ""}">
        <input type="text" maxlength="8" value="${escapeHtml(defender.label)}" data-trenches-front-def-label="${defender.id}" aria-label="Template defender label">
        <button class="library-action-button" data-select-trenches-front-defender="${defender.id}">Select</button>
        <button class="library-action-button danger" data-delete-trenches-front-defender="${defender.id}">Delete</button>
      </div>
    `).join("");
    els.trenchesFrontDefenderList.querySelectorAll("[data-select-trenches-front-defender]").forEach(button => {
      button.addEventListener("click", () => {
        trenchesState.panelTab = "front";
        updateTrenchesSelection(button.dataset.selectTrenchesFrontDefender, "defense");
        renderTrenches();
      });
    });
    els.trenchesFrontDefenderList.querySelectorAll("[data-trenches-front-def-label]").forEach(input => {
      input.addEventListener("change", () => {
        editableTrenchesFrontId();
        const positions = trenchesPositions(trenchesState.frontId);
        const defender = positions.defense.find(item => item.id === input.dataset.trenchesFrontDefLabel);
        if (!defender) return;
        defender.label = input.value.trim() || defender.label;
        setTrenchesPositions(trenchesState.frontId, positions);
        saveCurrentTrenchesFront();
        renderTrenches();
      });
    });
    els.trenchesFrontDefenderList.querySelectorAll("[data-delete-trenches-front-defender]").forEach(button => {
      button.addEventListener("click", () => {
        editableTrenchesFrontId();
        const defenderId = button.dataset.deleteTrenchesFrontDefender;
        const positions = trenchesPositions(trenchesState.frontId);
        positions.defense = positions.defense.filter(item => item.id !== defenderId);
        setTrenchesPositions(trenchesState.frontId, positions);
        delete trenchesState.defensePaths?.[defenderId];
        saveCurrentTrenchesFront();
        renderTrenches();
      });
    });
  }

  els.trenchesBoard.querySelectorAll("[data-trenches-note-handle]").forEach(button => {
    button.addEventListener("pointerdown", event => startTrenchesNoteDrag(event, button.dataset.trenchesNoteHandle));
  });
  els.trenchesBoard.querySelectorAll("[data-trenches-note-text]").forEach(textarea => {
    textarea.addEventListener("click", event => event.stopPropagation());
    textarea.addEventListener("pointerdown", event => event.stopPropagation());
    textarea.addEventListener("input", event => {
      const note = trenchesState.notes.find(item => item.id === textarea.dataset.trenchesNoteText);
      if (!note) return;
      note.text = event.target.value;
      const dimensions = noteDimensions(note.text || "");
      note.width = dimensions.width;
      note.height = dimensions.height;
      const group = textarea.closest("[data-trenches-note]");
      group?.querySelector("rect")?.setAttribute("width", dimensions.width);
      group?.querySelector("rect")?.setAttribute("height", dimensions.height);
      group?.querySelector("foreignObject")?.setAttribute("width", dimensions.width);
      group?.querySelector("foreignObject")?.setAttribute("height", dimensions.height);
      saveTrenchesState();
    });
  });
  els.trenchesBoard.querySelectorAll("[data-delete-trenches-note]").forEach(button => {
    button.addEventListener("pointerdown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      trenchesState.notes = trenchesState.notes.filter(note => note.id !== button.dataset.deleteTrenchesNote);
      saveTrenchesState();
      renderTrenches();
    });
  });
}

function startTrenchesDrag(event, side, id) {
  if (trenchesAnimationFrame) return;
  if (trenchesState.mode === "draw" && side === "defense" && !["defense", "front"].includes(trenchesState.panelTab)) return;
  event.preventDefault();
  event.stopPropagation();
  if (side === "offense") updateTrenchesSelection(id);
  if (side === "offense" && trenchesState.mode === "draw") return;
  if (side === "defense" && trenchesState.mode === "draw") {
    trenchesState.panelTab = trenchesState.panelTab === "front" ? "front" : "defense";
    updateTrenchesSelection(id, "defense");
    return;
  }
  if (side === "defense" && trenchesState.panelTab === "front" && !trenchesState.customFronts?.[trenchesState.frontId]) {
    const frontId = editableTrenchesFrontId();
    if (!frontId) return;
  }
  const point = trenchesPointFromEvent(event);
  const positions = trenchesPositions(trenchesState.frontId);
  const list = side === "offense" ? positions.offense : positions.defense;
  const player = list.find(item => item.id === id);
  if (!player) return;
  const svg = els.trenchesBoard.querySelector("svg");
  svg.setPointerCapture(event.pointerId);
  trenchesDrag = {
    side,
    id,
    pointerId: event.pointerId,
    offsetX: point.x - player.x,
    offsetY: point.y - player.y
  };
}

function startTrenchesNoteDrag(event, noteId) {
  if (trenchesAnimationFrame) return;
  event.preventDefault();
  event.stopPropagation();
  const note = trenchesState.notes.find(item => item.id === noteId);
  if (!note) return;
  const point = trenchesPointFromEvent(event);
  const svg = els.trenchesBoard.querySelector("svg");
  svg.setPointerCapture(event.pointerId);
  trenchesDrag = {
    side: "note",
    id: noteId,
    pointerId: event.pointerId,
    offsetX: point.x - note.x,
    offsetY: point.y - note.y
  };
}

function updateTrenchesDrag(event) {
  if (!trenchesDrag) return;
  const point = trenchesPointFromEvent(event);
  if (trenchesDrag.side === "note") {
    const note = trenchesState.notes.find(item => item.id === trenchesDrag.id);
    if (!note) return;
    note.x = Math.max(8, Math.min(860 - (note.width || 38), point.x - trenchesDrag.offsetX));
    note.y = Math.max(8, Math.min(500 - (note.height || 44), point.y - trenchesDrag.offsetY));
    saveTrenchesState();
    els.trenchesBoard.querySelector(`[data-trenches-note="${trenchesDrag.id}"]`)
      ?.setAttribute("transform", `translate(${note.x} ${note.y})`);
    return;
  }
  const positions = trenchesPositions(trenchesState.frontId);
  const list = trenchesDrag.side === "offense" ? positions.offense : positions.defense;
  const player = list.find(item => item.id === trenchesDrag.id);
  if (!player) return;
  player.x = point.x - trenchesDrag.offsetX;
  player.y = point.y - trenchesDrag.offsetY;
  if (trenchesDrag.side === "offense") player.y = Math.max(260, Math.min(390, player.y));
  setTrenchesPositions(trenchesState.frontId, positions);
  const selector = trenchesDrag.side === "offense"
    ? `[data-trenches-lineman="${trenchesDrag.id}"]`
    : `[data-trenches-defender="${trenchesDrag.id}"]`;
  els.trenchesBoard.querySelector(selector)
    ?.setAttribute("transform", `translate(${player.x} ${player.y})`);
}

function finishTrenchesDrag(event) {
  if (!trenchesDrag) return;
  const svg = els.trenchesBoard.querySelector("svg");
  if (svg?.hasPointerCapture(trenchesDrag.pointerId)) {
    svg.releasePointerCapture(trenchesDrag.pointerId);
  }
  if (trenchesDrag.side === "defense" && trenchesState.panelTab === "front") {
    saveCurrentTrenchesFront();
  }
  trenchesDrag = null;
  renderTrenches();
}

function runTrenchesPlay() {
  const start = trenchesPositions(trenchesState.frontId);
  const playbackSpeed = Math.max(0.1, Math.min(1, Number(trenchesState.playbackSpeed) || 1));
  const offenseDurations = start.offense.map(player => {
    const assignment = trenchesState.assignments[player.id] || {};
    const target = start.defense.find(defender => defender.id === assignment.targetId);
    const path = trenchPathForPlayer(player, assignment, target ? defenderTrenchDestination(target) : null);
    return trenchMovementDurationMs(player, path, playbackSpeed, Boolean(target));
  });
  const defenseDurations = start.defense.map(player => {
    const movement = trenchesState.defensePaths?.[player.id] || { path: [], speed: 1 };
    return trenchMovementDurationMs(player, movement.path || [], playbackSpeed, false);
  });
  const duration = Math.max(2500, ...offenseDurations, ...defenseDurations) + 600;
  const safetyDuration = Math.max(duration + 2000, 120000);
  const startedAt = performance.now();
  cancelAnimationFrame(trenchesAnimationFrame);
  const tick = now => {
    const elapsedMs = now - startedAt;
    const offensePositions = start.offense.map(player => {
      const assignment = trenchesState.assignments[player.id] || {};
      const target = start.defense.find(defender => defender.id === assignment.targetId);
      const path = trenchPathForPlayer(player, assignment, target ? defenderTrenchDestination(target) : null);
      const contactSoon = target && Math.hypot(player.x - target.x, player.y - target.y) < 75;
      return trenchTravelPoint(player, path, elapsedMs, playbackSpeed, contactSoon && elapsedMs > 250);
    });
    const defenseBase = start.defense.map(player => {
      const movement = trenchesState.defensePaths?.[player.id] || { path: [], speed: 1 };
      return trenchTravelPoint(player, movement.path || [], elapsedMs, playbackSpeed, false);
    });
    const defensePositions = defenseBase.map(defender => ({ ...defender }));

    offensePositions.forEach(blocker => {
      const assignment = trenchesState.assignments[blocker.id] || {};
      const targetIndex = defensePositions.findIndex(defender => defender.id === assignment.targetId);
      if (targetIndex < 0) return;
      const defender = defensePositions[targetIndex];
      const startBlocker = start.offense.find(player => player.id === blocker.id) || blocker;
      const moveUnit = movementVector(startBlocker, blocker)
        || movementVector(startBlocker, defender)
        || { x: 0, y: -1 };
      const distance = Math.hypot(blocker.x - defender.x, blocker.y - defender.y);
      if (distance > 58 && blocker.travelProgress < .98) return;

      const separation = 42;
      const pushAmount = Math.max(0, 1 - Math.min(distance, 58) / 58);
      const desired = {
        x: blocker.x + (moveUnit.x * separation),
        y: blocker.y + (moveUnit.y * separation)
      };
      defender.x += (desired.x - defender.x) * Math.min(.55, .22 + pushAmount * .35);
      defender.y += (desired.y - defender.y) * Math.min(.55, .22 + pushAmount * .35);
      const nextDistance = Math.hypot(blocker.x - defender.x, blocker.y - defender.y) || 1;
      if (nextDistance < 36) {
        defender.x = blocker.x + (moveUnit.x * 36);
        defender.y = blocker.y + (moveUnit.y * 36);
      }
      defender.x = Math.max(70, Math.min(830, defender.x));
      defender.y = Math.max(70, Math.min(430, defender.y));
    });

    trenchesAnimation = {
      positions: {
        offense: offensePositions,
        defense: defensePositions
      }
    };
    renderTrenches();
    const allFinished = [
      ...offensePositions.map(player => player.travelProgress ?? 1),
      ...defensePositions.map(player => player.travelProgress ?? 1)
    ].every(value => value >= .999);
    if (!allFinished && elapsedMs < safetyDuration) trenchesAnimationFrame = requestAnimationFrame(tick);
    else trenchesAnimationFrame = null;
  };
  trenchesAnimationFrame = requestAnimationFrame(tick);
}

function resetTrenchesRun() {
  cancelAnimationFrame(trenchesAnimationFrame);
  trenchesAnimationFrame = null;
  trenchesAnimation = null;
  renderTrenches();
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char]));
}

function syncTabButtons() {
  document.querySelectorAll("[data-app-tab]").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.appTab === appTab);
  });
  document.querySelectorAll("[data-create-screen]").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.createScreen === createScreen);
  });
}

function render() {
  document.body.classList.toggle("run-view", appTab === "run");
  document.body.classList.toggle("test-view", appTab === "test");
  document.body.classList.toggle("playbook-view", appTab === "playbook");
  document.body.classList.toggle("create-formation", appTab === "create" && createScreen === "formation");
  document.body.classList.toggle("create-play", appTab === "create" && createScreen === "play");
  document.body.classList.toggle("create-defense", appTab === "create" && createScreen === "defense");
  document.body.classList.toggle(
    "defense-alignment-mode",
    appTab === "create" && createScreen === "defense" && defenseAlignmentMode
  );
  document.body.classList.toggle("scenario-editing", appTab === "run" && scenarioEditing);
  document.querySelector("#runToolbar").classList.toggle("hidden", appTab !== "run");
  document.querySelector("#testToolbar").classList.toggle("hidden", appTab !== "test");
  els.field.classList.toggle(
    "move-mode",
    (appTab === "create" && boardMode === "move")
      || (appTab === "run" && scenarioEditing && scenarioTool === "move")
  );
  document.querySelector("#editScenarioButton").textContent = scenarioEditing ? "Done Editing" : "Edit Scenario";
  document.querySelector("#scenarioMoveButton").classList.toggle("active", scenarioTool === "move");
  document.querySelector("#scenarioDrawButton").classList.toggle("active", scenarioTool === "draw");
  document.querySelector("#scenarioZoneButton").classList.toggle("active", scenarioTool === "zone");
  document.querySelector("#scenarioManButton").classList.toggle("active", scenarioTool === "man");
  document.querySelector("#scenarioClearButton").textContent = scenarioTool === "zone"
    ? "Clear Zone"
    : scenarioTool === "man"
      ? "Clear Assignment"
      : "Clear Movement";
  document.querySelector("#defensePathModeButton").classList.toggle("active", defenseAssignmentMode === "path");
  document.querySelector("#defenseZoneModeButton").classList.toggle("active", defenseAssignmentMode === "zone");
  document.querySelector("#defenseManModeButton").classList.toggle("active", defenseAssignmentMode === "man");
  document.querySelector("#drawRouteButton").classList.toggle("active", playPathType === "route");
  document.querySelector("#drawMotionButton").classList.toggle("active", playPathType === "motion");
  const scenarioZone = appTab === "run" && scenarioEditing
    && scenarioTool === "zone" && activeRouteSide === "defense"
    ? currentZoneAssignments()[activeRouteId]
    : null;
  els.scenarioZoneSizeControl.classList.toggle("hidden", !scenarioZone);
  if (scenarioZone) {
    const size = String(Math.round(Math.max(
      zoneRadii(scenarioZone).x,
      zoneRadii(scenarioZone).y
    )));
    els.scenarioZoneSizeRange.value = size;
    els.scenarioZoneSizeInput.value = size;
  }
  els.scenarioStatus.textContent = `${
    scenarioTool === "move"
      ? "Moving"
      : scenarioTool === "man"
        ? "Assigning man for"
        : scenarioTool === "zone"
          ? "Adjusting zone for"
          : "Drawing"
  } ${
    activeRouteSide === "offense" ? offenseLabel(activeRouteId) : (currentDefense().labels[activeRouteId] || activeRouteId)
  }`;
  els.defensePathHelp.textContent = defenseAlignmentMode
    ? "Move defenders into their starting positions for the selected offensive formation."
    : defenseAssignmentMode === "man"
    ? "Click a defender, then click the receiver or back they guard."
    : defenseAssignmentMode === "zone"
      ? "Place the defender's zone. Any custom movement already drawn will run first at the snap."
      : "Draw the defender's snap movement. You can also assign a zone that takes over when the movement ends.";
  els.boardModeStatus.textContent = defenseAlignmentMode
    ? "Setting alignment for"
    : boardMode === "move"
    ? "Moving players"
    : createScreen === "defense" && defenseAssignmentMode === "man"
      ? "Assigning man for"
    : createScreen === "defense" && defenseAssignmentMode === "zone"
      ? "Placing zone for"
    : createScreen === "play" && playPathType === "motion"
      ? "Drawing motion for"
    : createScreen === "play" && selectedRouteOptionId !== "base"
      ? "Drawing option for"
    : activeRouteSide === "defense" ? "Drawing defender" : "Drawing";
  els.routeHelp.textContent = defenseAlignmentMode
    ? `Drag defenders into position against ${currentFormation().name}, then save or move to the next formation.`
    : boardMode === "move"
    ? "Drag players into position. They snap to the line of scrimmage when close; hold Alt to place freely."
    : createScreen === "defense" && defenseAssignmentMode === "man"
      ? "Click a defender, then click the receiver or back they guard."
    : createScreen === "defense" && defenseAssignmentMode === "zone"
      ? currentDefense().zoneAssignments?.[activeRouteId]
        ? "Drag or reshape the zone. Deep zones will protect the roof by rule."
        : "Click the field to place the reactive zone. The defender's custom movement can remain in place."
    : createScreen === "play" && playPathType === "motion"
      ? "Click the field to draw pre-snap motion. The route will begin where the motion ends."
    : createScreen === "play" && selectedRouteOptionId !== "base"
      ? selectedRouteOption()?.anchor
        ? "Draw the dotted branch from the green point. Click the solid route again to move the branch point."
        : "Click anywhere on the solid base route to choose where this option branches."
    : activeRouteSide === "defense"
      ? "Click to add movement points. Drag a point to adjust it; hold Shift for a straight line."
      : "Click to add route points. Drag a point to adjust it; hold Shift for a straight line. Click a break point to round it.";
  const routeUnavailable = boardMode === "move"
    || (activeRouteSide === "offense" && !isRouteableOffense(activeRouteId));
  document.querySelector("#undoPointButton").disabled = routeUnavailable;
  document.querySelector("#clearRouteButton").disabled = routeUnavailable;
  document.querySelector("#drawMotionButton").disabled = activeRouteId === "QB";
  document.querySelector("#clearRouteButton").textContent = createScreen === "play" && playPathType === "motion"
    ? "Clear Motion"
    : createScreen === "play" && selectedRouteOptionId !== "base"
      ? "Clear Option"
    : createScreen === "defense" && defenseAssignmentMode === "man"
      ? "Clear Assignment"
    : createScreen === "defense" && defenseAssignmentMode === "zone"
      ? "Clear Zone"
    : "Clear Route";
  document.querySelector("#previewMovementButton").textContent = createScreen === "defense"
    ? "Preview Defense"
    : "Preview Play";
  if (els.fieldOfViewToggle) {
    els.fieldOfViewToggle.classList.toggle("active", showDefenderFieldOfView);
    els.fieldOfViewToggle.setAttribute("aria-pressed", showDefenderFieldOfView ? "true" : "false");
    els.fieldOfViewToggle.textContent = showDefenderFieldOfView ? "FOV On" : "FOV Off";
  }
  els.fieldStandardSelect.value = fieldStandard;
  const screenCopy = {
    formation: ["Formation", "Create formation"],
    play: ["Offense", "Create play"],
    defense: ["Defense", "Create defense"]
  }[createScreen];
  els.leftPanelEyebrow.textContent = screenCopy[0];
  els.leftPanelTitle.textContent = screenCopy[1];
  els.fieldNote.textContent = appTab === "test"
    ? (!testRoundReady
        ? "Choose the plays and defenses for this session, then start the test."
        : testAnswerRevealed
          ? `${currentFormation().name} / ${currentPlay().name} vs. ${currentDefense().name}`
          : `${currentFormation().name} / ${currentPlay().name}. Space once sets, Space again snaps. After the snap, move your mouse for QB eyes and click to throw.`)
    : appTab === "run"
    ? (activeRunRouteOptions().length
        ? `Active options: ${activeRunRouteOptions().map(item =>
            `${item.player} runs ${item.option.name}`
          ).join("; ")}.`
        : "No route options match this defense. The base routes will run.")
    : {
        formation: "Move players into position, edit receiver labels, name the formation, and save it.",
        play: "Choose a saved formation, draw the named play, and drag the RB anywhere for this play only.",
        defense: defenseAlignmentMode
          ? `Setting ${currentDefense().name}'s starting alignment against ${currentFormation().name}.`
          : "Position defenders, then combine snap movement with zone coverage or assign man coverage."
      }[createScreen];
  document.querySelectorAll(".board-mode-button").forEach(button => {
    button.classList.toggle("active", button.dataset.boardMode === boardMode);
  });
  renderRoutesAndPlayers();
  renderDefense();
  renderNotes();
  renderReads();
  renderRunControls();
  renderTestControls();
  renderPlaybookLibrary();
}

document.querySelector("#savePlayButton").addEventListener("click", () => {
  currentPlay().name = els.playName.value.trim() || "Untitled Play";
  currentPlay().formationId = selectedFormationId;
  currentPlay().intent = {
    playAction: Boolean(els.playActionToggle?.checked),
    rpo: Boolean(els.rpoToggle?.checked)
  };
  if (draftPlay) {
    plays.push(draftPlay);
    selectedPlayId = draftPlay.id;
    draftPlay = null;
  }
  lastSavedSignature = "";
  const saved = persistPlaybook();
  showSaveSuccess(saved ? "Play saved successfully" : "Save failed - download a backup");
  renderPlayControls();
  render();
});

document.querySelector("#mirrorPlayButton").addEventListener("click", () => {
  const targetFormation = formations.find(
    formation => formation.id === els.mirrorPlayFormationSelect.value
  );
  if (!targetFormation) return;

  let sourcePlay = currentPlay();
  sourcePlay.name = els.playName.value.trim() || "Untitled Play";
  sourcePlay.formationId = selectedFormationId;
  const sourceFormation = formations.find(
    formation => formation.id === sourcePlay.formationId
  ) || currentFormation();

  if (draftPlay) {
    plays.push(sourcePlay);
    selectedPlayId = sourcePlay.id;
    draftPlay = null;
    savePlays();
  }

  draftPlay = mirroredPlay(sourcePlay, sourceFormation, targetFormation);
  selectedFormationId = targetFormation.id;
  activeRouteSide = "offense";
  activeRouteId = "X";
  selectedRouteOptionId = "base";
  playPathType = "route";
  boardMode = "draw";
  renderPlayControls();
  render();
  showSaveSuccess("Original saved; mirrored play ready");
});

els.playName.addEventListener("input", event => {
  currentPlay().name = event.target.value;
});

els.playActionToggle?.addEventListener("change", event => {
  currentPlay().intent ||= defaultPlayIntent();
  currentPlay().intent.playAction = event.target.checked;
  savePlays();
});

els.rpoToggle?.addEventListener("change", event => {
  currentPlay().intent ||= defaultPlayIntent();
  currentPlay().intent.rpo = event.target.checked;
  savePlays();
});

els.fieldStandardSelect.addEventListener("change", event => {
  fieldStandard = event.target.value;
  localStorage.setItem("readroute-field-standard", fieldStandard);
  renderMarkings();
});

document.querySelector("#newPlayButton").addEventListener("click", () => {
  preserveDraftBeforeReplacement();
  createScreen = "play";
  appTab = "create";
  stopAnimationPlayback();
  document.querySelectorAll("[data-app-tab]").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.appTab === "create");
  });
  document.querySelectorAll("[data-create-screen]").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.createScreen === "play");
  });
  draftPlay = createBlankPlay("");
  draftPlay.formationId = selectedFormationId;
  draftPlay.offensePositions = structuredClone(normalizedOffensePositions(currentFormation().offensePositions));
  draftPlay.labels = structuredClone(currentFormation().labels);
  emptyPlayPaths(draftPlay);
  activeRouteId = "X";
  activeRouteSide = "offense";
  boardMode = "draw";
  playPathType = "route";
  selectedRouteOptionId = "base";
  renderPlayControls();
  render();
  els.playName.focus();
  els.playName.select();
});

function eventToFieldPoint(event) {
  const point = els.field.createSVGPoint();
  point.x = event.clientX;
  point.y = event.clientY;
  const transformed = point.matrixTransform(els.field.getScreenCTM().inverse());
  return {
    x: Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, Math.round(transformed.x))),
    y: Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, Math.round(transformed.y))),
    rounded: false,
    speed: 1
  };
}

function constrainRoutePoint(point, anchor, event) {
  if (!event.shiftKey || !anchor) return point;
  return Math.abs(point.x - anchor.x) >= Math.abs(point.y - anchor.y)
    ? { ...point, y: anchor.y }
    : { ...point, x: anchor.x };
}

function beginPathPointDrag(
  event,
  path,
  index,
  displayOffset = { x: 0, y: 0 },
  anchor = null,
  onTap = null
) {
  event.preventDefault();
  event.stopPropagation();
  els.field.setPointerCapture(event.pointerId);
  dragState = {
    side: "path-point",
    path,
    index,
    displayOffset,
    anchor,
    onTap,
    pointerId: event.pointerId,
    startClientX: event.clientX,
    startClientY: event.clientY,
    moved: false
  };
}

function updateDrawingGuide(event) {
  els.routes.querySelector(".drawing-guide")?.remove();
  let anchor = null;
  let color = positionColor(activeRouteId, activeRouteSide);
  let dashed = false;

  if (appTab === "create" && boardMode === "draw") {
    if (createScreen === "play" && activeRouteSide === "offense"
      && isRouteableOffense(activeRouteId)) {
      const start = editorOffensePositions()[activeRouteId];
      const motion = currentMotion(activeRouteId);
      if (playPathType === "motion" && activeRouteId !== "QB") {
        anchor = motion[motion.length - 1] || start;
        dashed = true;
      } else {
        const option = selectedRouteOption(activeRouteId);
        if (option) {
          const storedAnchor = option.points[option.points.length - 1]
            || routeAnchorPoint(start, currentPlay().routes[activeRouteId] || [], option.anchor);
          if (storedAnchor) {
            const snapStart = motionEnd(start, motion);
            anchor = {
              x: storedAnchor.x + (snapStart.x - start.x),
              y: storedAnchor.y + (snapStart.y - start.y)
            };
            dashed = true;
          }
        } else {
          const route = postSnapRoute(activeRouteId, start);
          anchor = route[route.length - 1] || motionEnd(start, motion);
        }
      }
    } else if (createScreen === "defense" && activeRouteSide === "defense"
      && defenseAssignmentMode === "path") {
      const route = currentDefense().routes[activeRouteId] || [];
      anchor = route[route.length - 1] || currentDefenseEditorPositions()[activeRouteId];
      dashed = true;
    }
  } else if (appTab === "run" && scenarioEditing && scenarioTool === "draw") {
    const route = runScenarioRoute(activeRouteSide, activeRouteId);
    if (activeRouteSide === "offense") {
      const start = editorOffensePositions()[activeRouteId];
      const displayedRoute = postSnapRoute(activeRouteId, start);
      anchor = displayedRoute[displayedRoute.length - 1] || motionEnd(start, currentMotion(activeRouteId));
    } else {
      anchor = route[route.length - 1] || runScenario.defensePositions[activeRouteId];
      dashed = true;
    }
  }

  if (!anchor) return;
  const point = constrainRoutePoint(eventToFieldPoint(event), anchor, event);
  const guide = svgEl("line", {
    class: "drawing-guide",
    x1: anchor.x,
    y1: anchor.y,
    x2: point.x,
    y2: point.y,
    stroke: color,
    "stroke-width": 3,
    "stroke-linecap": "round",
    "stroke-dasharray": dashed ? "8 6" : "5 5",
    opacity: .72
  });
  els.routes.append(guide);
}

els.field.addEventListener("pointermove", event => {
  if (!testThrowActive()) return;
  testQbLookPoint = eventToFieldPoint(event);
  renderRoutesAndPlayers();
});

els.field.addEventListener("pointerdown", event => {
  if (handleTestThrowPointer(event)) {
    suppressFieldClickUntil = Date.now() + 250;
  }
}, true);

els.field.addEventListener("click", event => {
  handleTestThrowPointer(event);
}, true);

els.field.addEventListener("click", event => {
  if (Date.now() < suppressFieldClickUntil) {
    return;
  }
  if (handleTestThrowPointer(event)) {
    return;
  }
  if (appTab === "run" && scenarioEditing && scenarioTool === "zone"
    && activeRouteSide === "defense") {
    delete currentManAssignments()[activeRouteId];
    const point = eventToFieldPoint(event);
    const existingZone = currentZoneAssignments()[activeRouteId];
    const radii = zoneRadii(existingZone);
    currentZoneAssignments()[activeRouteId] = {
      ...existingZone,
      x: Math.max(radii.x, Math.min(900 - radii.x, point.x)),
      y: Math.max(radii.y, Math.min(fieldHeight - radii.y, point.y)),
      radiusX: radii.x,
      radiusY: radii.y
    };
    render();
    return;
  }
  if (appTab === "run" && scenarioEditing && scenarioTool === "draw") {
    if (activeRouteSide === "defense") {
      delete currentManAssignments()[activeRouteId];
    }
    const route = runScenarioRoute(activeRouteSide, activeRouteId);
    if (activeRouteSide === "offense") {
      const start = editorOffensePositions()[activeRouteId];
      const motion = currentMotion(activeRouteId);
      const snapStart = motionEnd(start, motion);
      const displayedRoute = postSnapRoute(activeRouteId, start);
      const anchor = displayedRoute[displayedRoute.length - 1] || snapStart;
      const constrained = constrainRoutePoint(eventToFieldPoint(event), anchor, event);
      route.push({
        ...constrained,
        x: constrained.x - (snapStart.x - start.x),
        y: constrained.y - (snapStart.y - start.y)
      });
    } else {
      const start = runScenario.defensePositions[activeRouteId];
      const anchor = route[route.length - 1] || start;
      route.push(constrainRoutePoint(eventToFieldPoint(event), anchor, event));
    }
    render();
    return;
  }
  if (appTab !== "create" || boardMode !== "draw") return;
  if (createScreen === "play" && activeRouteSide === "offense") {
    if (!isRouteableOffense(activeRouteId)) return;
    const point = eventToFieldPoint(event);
    if (playPathType === "motion" && activeRouteId !== "QB") {
      const motion = currentMotion(activeRouteId);
      const anchor = motion[motion.length - 1] || editorOffensePositions()[activeRouteId];
      motion.push(constrainRoutePoint(point, anchor, event));
    } else {
      const start = editorOffensePositions()[activeRouteId];
      const snapStart = motionEnd(start, currentMotion(activeRouteId));
      const route = editablePlayRoute(activeRouteId);
      const option = selectedRouteOption(activeRouteId);
      if (option) {
        const baseRoute = currentPlay().routes[activeRouteId] || [];
        const displayedBaseRoute = baseRoute.map(routePoint => ({
          ...routePoint,
          x: routePoint.x + (snapStart.x - start.x),
          y: routePoint.y + (snapStart.y - start.y)
        }));
        const nearest = nearestRouteAnchor(snapStart, displayedBaseRoute, point);
        if (nearest?.distance <= 20) {
          option.anchor = {
            segmentIndex: nearest.segmentIndex,
            t: nearest.t
          };
          renderPlayControls();
          render();
          return;
        }
      }
      const storedBranchAnchor = option
        ? routeAnchorPoint(start, currentPlay().routes[activeRouteId] || [], option.anchor)
        : null;
      if (option && !storedBranchAnchor) return;
      const displayedRoute = option
        ? option.points.map(routePoint => ({
            ...routePoint,
            x: routePoint.x + (snapStart.x - start.x),
            y: routePoint.y + (snapStart.y - start.y)
          }))
        : postSnapRoute(activeRouteId, start);
      const anchor = displayedRoute[displayedRoute.length - 1]
        || (storedBranchAnchor
          ? {
              x: storedBranchAnchor.x + (snapStart.x - start.x),
              y: storedBranchAnchor.y + (snapStart.y - start.y)
            }
          : snapStart);
      const constrained = constrainRoutePoint(point, anchor, event);
      route.push({
        ...constrained,
        x: constrained.x - (snapStart.x - start.x),
        y: constrained.y - (snapStart.y - start.y)
      });
    }
  } else if (createScreen === "defense" && activeRouteSide === "defense"
    && defenseAssignmentMode === "zone") {
    delete currentDefense().manAssignments[activeRouteId];
    const point = eventToFieldPoint(event);
    const existingZone = currentDefense().zoneAssignments[activeRouteId];
    const radii = zoneRadii(existingZone);
    currentDefense().zoneAssignments[activeRouteId] = {
      ...existingZone,
      x: Math.max(radii.x, Math.min(900 - radii.x, point.x)),
      y: Math.max(radii.y, Math.min(fieldHeight - radii.y, point.y)),
      radiusX: radii.x,
      radiusY: radii.y
    };
  } else if (createScreen === "defense" && activeRouteSide === "defense"
    && defenseAssignmentMode === "path") {
    delete currentDefense().manAssignments[activeRouteId];
    currentDefense().routes[activeRouteId] ||= [];
    const route = currentDefense().routes[activeRouteId];
    const anchor = route[route.length - 1] || currentDefenseEditorPositions()[activeRouteId];
    route.push(constrainRoutePoint(eventToFieldPoint(event), anchor, event));
  } else {
    return;
  }
  renderPlayControls();
  render();
});

els.field.addEventListener("pointermove", event => {
  if (!dragState) {
    updateDrawingGuide(event);
    return;
  }
  if (appTab !== "create" && appTab !== "run") return;
  const point = eventToFieldPoint(event);
  if (dragState.side === "zone-move") {
    const radii = zoneRadii(dragState.zone);
    dragState.zone.x = Math.max(
      radii.x,
      Math.min(900 - radii.x, point.x - dragState.offsetX)
    );
    dragState.zone.y = Math.max(
      radii.y,
      Math.min(fieldHeight - radii.y, point.y - dragState.offsetY)
    );
    renderDefense();
    return;
  }
  if (dragState.side === "zone-resize") {
    const dx = Math.abs(point.x - dragState.zone.x);
    const dy = Math.abs(point.y - dragState.zone.y);
    if (dragState.kind === "horizontal") {
      dragState.zone.radiusX = Math.max(40, Math.min(300, dx));
    } else {
      dragState.zone.radiusY = Math.max(40, Math.min(300, dy));
    }
    delete dragState.zone.radius;
    const size = String(Math.round(Math.max(
      dragState.zone.radiusX,
      dragState.zone.radiusY
    )));
    if (appTab === "run") {
      els.scenarioZoneSizeRange.value = size;
      els.scenarioZoneSizeInput.value = size;
    } else {
      els.zoneSizeRange.value = size;
      els.zoneSizeInput.value = size;
    }
    renderDefense();
    return;
  }
  if (dragState.side === "path-point") {
    const previous = dragState.index > 0
      ? dragState.path[dragState.index - 1]
      : dragState.anchor;
    const displayAnchor = previous
      ? {
          x: previous.x + dragState.displayOffset.x,
          y: previous.y + dragState.displayOffset.y
        }
      : null;
    const constrained = constrainRoutePoint(point, displayAnchor, event);
    dragState.path[dragState.index] = {
      ...dragState.path[dragState.index],
      x: constrained.x - dragState.displayOffset.x,
      y: constrained.y - dragState.displayOffset.y
    };
    dragState.moved ||= Math.hypot(
      event.clientX - dragState.startClientX,
      event.clientY - dragState.startClientY
    ) > 3;
    renderRoutesAndPlayers();
    renderDefense();
    return;
  }
  if (dragState.side === "note") {
    const maxX = 900 - (dragState.note.width || 170) - 8;
    const maxY = fieldHeight - (dragState.note.height || 62) - 8;
    dragState.note.x = Math.max(8, Math.min(maxX, point.x - dragState.offsetX));
    dragState.note.y = Math.max(8, Math.min(maxY, point.y - dragState.offsetY));
    renderNotes();
    return;
  }
  if (appTab === "run") {
    if (!scenarioEditing || scenarioTool !== "move") return;
    if (dragState.side === "offense") {
      const playerPoint = constrainOffenseStartPoint(
        dragState.id,
        snapPlayerToScrimmage(point, event)
      );
      runScenario.offensePositions[dragState.id] = { x: playerPoint.x, y: playerPoint.y };
    } else {
      const playerPoint = snapPlayerToScrimmage(point, event);
      runScenario.defensePositions[dragState.id] = { x: playerPoint.x, y: playerPoint.y };
    }
    renderRoutesAndPlayers();
    renderDefense();
    return;
  }
  const playSpecificRunningBack = appTab === "create"
    && createScreen === "play"
    && dragState.side === "offense"
    && dragState.id === "RB";
  if (boardMode !== "move" && !playSpecificRunningBack) return;
  if (dragState.side === "offense") {
    const playerPoint = constrainOffenseStartPoint(
      dragState.id,
      snapPlayerToScrimmage(point, event)
    );
    const positions = playSpecificRunningBack
      ? currentPlay().offensePositions
      : currentFormation().offensePositions;
    positions[dragState.id] = { x: playerPoint.x, y: playerPoint.y };
    renderRoutesAndPlayers();
  } else {
    const playerPoint = snapPlayerToScrimmage(point, event);
    currentDefenseEditorPositions()[dragState.id] = { x: playerPoint.x, y: playerPoint.y };
    renderDefense();
  }
});

els.formationSelect.addEventListener("change", event => {
  selectedFormationId = event.target.value;
  renderPlayControls();
  render();
});

els.playFormationSelect.addEventListener("change", event => {
  if (!draftPlay) return;
  selectedFormationId = event.target.value;
  emptyPlayPaths(draftPlay);
  applyFormation(currentFormation());
  renderPlayControls();
  render();
});

function selectDefenseAlignmentFormation(formationId) {
  if (!formations.some(formation => formation.id === formationId)) return;
  defenseAlignmentFormationId = formationId;
  selectedFormationId = formationId;
  boardMode = "move";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  currentDefenseEditorPositions();
  renderPlayControls();
  render();
}

els.defenseSelect.addEventListener("change", event => {
  selectedDefenseId = event.target.value;
  defenseAssignmentMode = "path";
  activeRouteSide = "defense";
  activeRouteId = "D0";
  if (defenseAlignmentMode) currentDefenseEditorPositions();
  renderPlayControls();
  render();
});

document.querySelector("#toggleDefenseAlignmentsButton").addEventListener("click", () => {
  defenseAlignmentMode = !defenseAlignmentMode;
  if (defenseAlignmentMode) {
    selectDefenseAlignmentFormation(
      formations.some(formation => formation.id === selectedFormationId)
        ? selectedFormationId
        : formations[0].id
    );
    return;
  }
  lastSavedSignature = "";
  persistPlaybook();
  renderPlayControls();
  render();
  showSaveSuccess("Formation alignments saved");
});

els.fieldOfViewToggle?.addEventListener("click", () => {
  showDefenderFieldOfView = !showDefenderFieldOfView;
  localStorage.setItem("readroute-show-defender-fov", showDefenderFieldOfView ? "true" : "false");
  renderPlayControls();
  renderDefense();
});

els.defenseAlignmentFormationSelect.addEventListener("change", event => {
  selectDefenseAlignmentFormation(event.target.value);
});

document.querySelector("#previousDefenseAlignmentButton").addEventListener("click", () => {
  const index = formations.findIndex(
    formation => formation.id === defenseAlignmentFormationId
  );
  if (index > 0) selectDefenseAlignmentFormation(formations[index - 1].id);
});

document.querySelector("#nextDefenseAlignmentButton").addEventListener("click", () => {
  const index = formations.findIndex(
    formation => formation.id === defenseAlignmentFormationId
  );
  if (index >= 0 && index < formations.length - 1) {
    selectDefenseAlignmentFormation(formations[index + 1].id);
  }
});

document.querySelector("#saveDefenseAlignmentButton").addEventListener("click", () => {
  currentDefenseEditorPositions();
  lastSavedSignature = "";
  const saved = persistPlaybook();
  showSaveSuccess(saved
    ? `Alignment saved for ${currentFormation().name}`
    : "Save failed - download a backup");
  renderDefenseControls();
});

document.querySelector("#resetDefenseAlignmentButton").addEventListener("click", () => {
  currentDefense().formationAlignments ||= {};
  currentDefense().formationAlignments[defenseAlignmentFormationId] =
    structuredClone(currentDefense().positions);
  saveDefenses();
  render();
  showSaveSuccess(`Default alignment restored for ${currentFormation().name}`);
});

document.querySelector("#doneDefenseAlignmentsButton").addEventListener("click", () => {
  defenseAlignmentMode = false;
  lastSavedSignature = "";
  persistPlaybook();
  renderPlayControls();
  render();
  showSaveSuccess("Formation alignments saved");
});

document.querySelector("#newFormationButton").addEventListener("click", () => {
  const formation = {
    id: crypto.randomUUID(),
    name: `Formation ${formations.length + 1}`,
    labels: structuredClone(formations[0]?.labels || { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" }),
    offensePositions: defaultOffensePositions(),
    notes: []
  };
  formations.push(formation);
  selectedFormationId = formation.id;
  saveFormations();
  renderPlayControls();
  els.formationName.focus();
  els.formationName.select();
});

document.querySelector("#saveFormationButton").addEventListener("click", () => {
  const formation = currentFormation();
  formation.name = els.formationName.value.trim() || "Untitled Formation";
  lastSavedSignature = "";
  const saved = persistPlaybook();
  showSaveSuccess(saved ? "Formation saved successfully" : "Save failed - download a backup");
  renderPlayControls();
  render();
});

document.querySelector("#mirrorFormationButton").addEventListener("click", () => {
  const source = currentFormation();
  source.name = els.formationName.value.trim() || "Untitled Formation";
  saveFormations();
  const mirrored = mirroredFormation(source);
  formations.push(mirrored);
  selectedFormationId = mirrored.id;
  saveFormations();
  renderPlayControls();
  render();
  showSaveSuccess("Mirrored formation created");
  els.formationName.focus();
  els.formationName.select();
});

document.querySelector("#newDefenseButton").addEventListener("click", () => {
  const defense = createBlankDefense(`Defense ${defenses.length + 1}`, defenses[0]?.labels || {});
  defenses.push(defense);
  selectedDefenseId = defense.id;
  defenseAssignmentMode = "path";
  activeRouteSide = "defense";
  activeRouteId = "D0";
  saveDefenses();
  renderPlayControls();
  render();
  els.defenseName.focus();
  els.defenseName.select();
});

document.querySelector("#saveDefenseButton").addEventListener("click", () => {
  currentDefense().name = els.defenseName.value.trim() || "Untitled Defense";
  currentDefense().realism = readDefenseRealismControls();
  lastSavedSignature = "";
  const saved = persistPlaybook();
  showSaveSuccess(saved ? "Defense saved successfully" : "Save failed - download a backup");
  renderPlayControls();
  render();
});

function readDefenseRealismControls() {
  return normalizeDefenseRealism({
    personality: els.coveragePersonalitySelect?.value,
    eyes: els.eyeDisciplineSelect?.value,
    awareness: els.awarenessInput?.value,
    discipline: els.disciplineInput?.value,
    aggression: els.aggressionInput?.value,
    mistakes: els.mistakeInput?.value
  });
}

[
  els.coveragePersonalitySelect,
  els.eyeDisciplineSelect,
  els.awarenessInput,
  els.disciplineInput,
  els.aggressionInput,
  els.mistakeInput
].forEach(input => {
  input?.addEventListener("input", () => {
    currentDefense().realism = readDefenseRealismControls();
    saveDefenses();
  });
  input?.addEventListener("change", () => {
    currentDefense().realism = readDefenseRealismControls();
    saveDefenses();
  });
});

els.runPlaySelect.addEventListener("change", event => {
  selectRunPlay(event.target.value);
});

els.runFormationSelect.addEventListener("change", event => {
  selectedFormationId = event.target.value;
  const firstFormationPlay = plays.find(play => play.formationId === selectedFormationId);
  if (firstFormationPlay) selectedPlayId = firstFormationPlay.id;
  stopAnimationPlayback();
  resetRunScenario();
  renderPlayControls();
  render();
});

els.runDefenseSelect.addEventListener("change", event => {
  selectedDefenseId = event.target.value;
  stopAnimationPlayback();
  resetRunScenario();
  render();
});

els.runSpeedSelect.addEventListener("change", event => {
  runSpeed = Number(event.target.value) || 1;
  resetAnimation();
});

els.runDefenseMovementSelect.addEventListener("change", event => {
  runDefenseMovement = event.target.value === "on";
  resetAnimation();
});

function pathLength(start, points) {
  let total = 0;
  let previous = start;
  points.forEach(point => {
    total += Math.hypot(point.x - previous.x, point.y - previous.y);
    previous = point;
  });
  return total;
}

function interpolatePath(start, points, distanceTraveled) {
  const path = [start, ...points];
  if (path.length === 1) return { ...start };
  const segments = [];
  let total = 0;
  for (let index = 1; index < path.length; index += 1) {
    const from = path[index - 1];
    const to = path[index];
    const length = Math.hypot(to.x - from.x, to.y - from.y);
    segments.push({ from, to, length });
    total += length;
  }
  if (!total) return { ...start };
  let remaining = Math.min(distanceTraveled, total);
  for (const segment of segments) {
    if (remaining <= segment.length) {
      const ratio = segment.length ? remaining / segment.length : 0;
      return {
        x: segment.from.x + (segment.to.x - segment.from.x) * ratio,
        y: segment.from.y + (segment.to.y - segment.from.y) * ratio
      };
    }
    remaining -= segment.length;
  }
  return { ...path[path.length - 1] };
}

function pathDuration(start, points, baseSpeed = 115) {
  let total = 0;
  let previous = start;
  points.forEach(point => {
    const segmentLength = Math.hypot(point.x - previous.x, point.y - previous.y);
    total += segmentLength / (baseSpeed * (point.speed || 1));
    previous = point;
  });
  return total;
}

function interpolateTimedPath(start, points, elapsedSeconds, baseSpeed = 115) {
  let previous = start;
  let remaining = Math.max(0, elapsedSeconds);
  for (const point of points) {
    const length = Math.hypot(point.x - previous.x, point.y - previous.y);
    const duration = length / (baseSpeed * (point.speed || 1));
    if (remaining <= duration) {
      const ratio = duration ? remaining / duration : 1;
      return {
        x: previous.x + ((point.x - previous.x) * ratio),
        y: previous.y + ((point.y - previous.y) * ratio)
      };
    }
    remaining -= duration;
    previous = point;
  }
  return points.length ? { ...points[points.length - 1] } : { ...start };
}

function defensivePreSnapPathTarget(start, route) {
  const firstPoint = Array.isArray(route) ? route[0] : null;
  if (!firstPoint) return null;
  const dx = firstPoint.x - start.x;
  const dy = firstPoint.y - start.y;
  const distance = Math.hypot(dx, dy);
  if (distance < 6) return null;
  const creepDistance = Math.min(22, Math.max(8, distance * .18));
  return {
    x: start.x + (dx / distance) * creepDistance,
    y: start.y + (dy / distance) * creepDistance
  };
}

function interpolateDefensivePreSnap(start, route, elapsedSeconds, availableSeconds) {
  const target = defensivePreSnapPathTarget(start, route);
  if (!target || availableSeconds <= 0) return { ...start };
  const duration = Math.max(.45, Math.min(1.35, availableSeconds * .82));
  const ratio = Math.max(0, Math.min(1, elapsedSeconds / duration));
  const eased = ratio * ratio * (3 - (2 * ratio));
  return {
    x: start.x + ((target.x - start.x) * eased),
    y: start.y + ((target.y - start.y) * eased)
  };
}

function preSnapMotionPressures(offensePaths) {
  return offensePaths
    .filter(path => Array.isArray(path.motion) && path.motion.length)
    .map(path => {
      const end = path.snapStart || motionEnd(path.start, path.motion);
      const dx = end.x - path.start.x;
      const dy = end.y - path.start.y;
      const distance = Math.hypot(dx, dy);
      return {
        id: path.id,
        start: path.start,
        end,
        dx,
        dy,
        distance,
        direction: distance ? { x: dx / distance, y: dy / distance } : { x: 0, y: 0 },
        targetSide: end.x < fieldWidth / 2 ? "left" : "right"
      };
    })
    .filter(pressure => pressure.distance > 12);
}

function defensiveMotionAdjustment(start, pressures, elapsedSeconds, availableSeconds, assignment = {}) {
  if (!pressures.length || availableSeconds <= 0) return { x: 0, y: 0 };
  const startSide = start.x < fieldWidth / 2 ? "left" : "right";
  const best = pressures
    .map(pressure => {
      const endDistance = Math.hypot(start.x - pressure.end.x, start.y - pressure.end.y);
      const sameSide = pressure.targetSide === startSide;
      const nearMotion = endDistance < 210;
      const sideScore = sameSide ? 1 : .42;
      const distanceScore = Math.max(0, 1 - Math.min(1, endDistance / 270));
      const zoneStyleWeight = assignment.isDeepSafety ? .32 : assignment.isFlatDefender || assignment.isCurlFlat ? .86 : .68;
      return {
        pressure,
        score: (nearMotion ? .45 : .18) + (sideScore * .34) + (distanceScore * .38),
        zoneStyleWeight
      };
    })
    .sort((a, b) => b.score - a.score)[0];
  if (!best || best.score < .45) return { x: 0, y: 0 };
  const duration = Math.max(.5, Math.min(1.2, availableSeconds * .72));
  const ratio = Math.max(0, Math.min(1, elapsedSeconds / duration));
  const eased = ratio * ratio * (3 - (2 * ratio));
  const sideDirection = best.pressure.end.x < start.x ? -1 : 1;
  const travel = Math.min(26, 7 + best.pressure.distance * .16) * best.zoneStyleWeight * best.score;
  const depthBump = Math.max(-6, Math.min(8, best.pressure.dy * .08)) * best.zoneStyleWeight;
  return {
    x: sideDirection * travel * eased,
    y: depthBump * eased
  };
}

function safeVelocity(distance, deltaSeconds) {
  const safeDelta = Math.max(.008, Math.min(.05, Number(deltaSeconds) || .016));
  return distance / safeDelta;
}

function initializeBodyState(posture = "shuffle") {
  return {
    posture,
    hips: "square",
    turnDelay: 0,
    momentum: { x: 0, y: 0 }
  };
}

function bodyPostureForMode(mode, gapX, gapY, isDeepSafety = false) {
  if (mode === "recover") return "recover";
  if (mode === "carry") return "open";
  if (mode === "rally" || mode === "run-fit" || mode === "bite") return "drive";
  if (mode === "wall") return "shuffle";
  if (isDeepSafety || mode === "midpoint") return "backpedal";
  if (Math.abs(gapX) > Math.abs(gapY) * 1.15) return "shuffle";
  if (gapY < -8) return "backpedal";
  return "shuffle";
}

function bodyMovementProfile(body, nextPosture, gapX, gapY, safeDelta) {
  body.posture ||= nextPosture;
  body.hips ||= "square";
  body.turnDelay ||= 0;
  const changingToOpen = body.posture !== "open" && nextPosture === "open";
  const changingDirection = Math.sign(gapX || 0) && body.hips !== "square"
    && body.hips !== (gapX < 0 ? "left" : "right");
  if (changingToOpen || changingDirection) {
    body.turnDelay = Math.max(body.turnDelay || 0, changingToOpen ? .12 : .08);
  }
  if (body.turnDelay > 0) body.turnDelay = Math.max(0, body.turnDelay - safeDelta);
  body.posture = nextPosture;
  if (nextPosture === "open" || nextPosture === "recover") {
    body.hips = gapX < -8 ? "left" : gapX > 8 ? "right" : body.hips;
  } else if (nextPosture === "backpedal" || nextPosture === "shuffle") {
    body.hips = "square";
  }
  const multipliers = {
    backpedal: { speed: .68, accel: .62 },
    shuffle: { speed: .72, accel: .7 },
    open: { speed: 1, accel: .88 },
    drive: { speed: .9, accel: 1 },
    recover: { speed: 1.08, accel: .92 }
  };
  const base = multipliers[nextPosture] || multipliers.shuffle;
  const turnPenalty = body.turnDelay > 0 ? .58 : 1;
  return {
    speed: base.speed * turnPenalty,
    accel: base.accel * turnPenalty
  };
}

function movementFacingVector(state, gapX, gapY) {
  const gapDistance = Math.hypot(gapX, gapY);
  if (gapDistance > 1) return normalizeVector({ x: gapX, y: gapY });
  const speed = Math.hypot(state.vx || 0, state.vy || 0);
  if (speed > 4) return normalizeVector({ x: state.vx, y: state.vy });
  return ballFacingVector(state);
}

function routeMovementEyeVector(current, start, route, elapsed, speed) {
  const lookAhead = interpolateTimedPath(start, route, elapsed + .18, speed);
  const gapX = lookAhead.x - current.x;
  const gapY = lookAhead.y - current.y;
  if (Math.hypot(gapX, gapY) < 1) return ballFacingVector(current);
  if (gapY < -6 && Math.abs(gapY) >= Math.abs(gapX) * .72) {
    return ballFacingVector(current);
  }
  return movementFacingVector(current, gapX, gapY);
}

function deepRouteScanVector(state, receivers, readLandmark, elapsed, profile = {}) {
  const routeThreats = receivers
    .filter(receiver => receiver.y <= state.start.y + 105 && receiver.vy < 28)
    .sort((a, b) => {
      const depthDiff = a.y - b.y;
      if (Math.abs(depthDiff) > 20) return depthDiff;
      const aVertical = a.read?.isVertical ? 1 : 0;
      const bVertical = b.read?.isVertical ? 1 : 0;
      return bVertical - aVertical;
    });
  if (!routeThreats.length) {
    const scanAmount = Math.sin(elapsed * .95 + (profile.scanNoise || 0)) * .22;
    return rotateVector(ballFacingVector(state), scanAmount);
  }
  const primary = routeThreats[0];
  if (routeThreats.length === 1) return vectorToward(state, primary);
  const secondary = routeThreats[1];
  const scan = (Math.sin(elapsed * 1.15 + (profile.scanNoise || 0)) + 1) / 2;
  const scanWeight = .35 + (scan * .3);
  return vectorToward(state, {
    x: (primary.x * (1 - scanWeight)) + (secondary.x * scanWeight),
    y: Math.min(primary.y, secondary.y) + 4
  });
}

function deepZonePedalTarget(state, zone, readLandmark, elapsed = 0, roofDefender = false) {
  const radii = zoneRadii(zone);
  const outsideDeepThird = roofDefender && (zone.x < fieldWidth * .34 || zone.x > fieldWidth * .66);
  const dropDepth = (roofDefender ? 70 : 48) + Math.min(54, elapsed * 58);
  const zoneCap = zone.y - (radii.y * .12);
  return {
    x: state.start.x + ((readLandmark.x - state.start.x) * (outsideDeepThird ? .08 : roofDefender ? .42 : .32)),
    y: Math.min(state.start.y - dropDepth, zoneCap)
  };
}

function laneCapX(zone, targetX, pad = 8) {
  const radii = zoneRadii(zone);
  return Math.max(zone.x - radii.x + pad, Math.min(zone.x + radii.x - pad, targetX));
}

function deepestRoofThreat(receivers, state, zone, roofDefender = false) {
  const radii = zoneRadii(zone);
  const outsideDeepThird = roofDefender && (zone.x < fieldWidth * .34 || zone.x > fieldWidth * .66);
  const leftThird = zone.x < fieldWidth / 2;
  const lanePad = roofDefender ? 34 : 18;
  const laneThreats = receivers.filter(receiver => {
    const sameSide = leftThird ? receiver.x < fieldWidth * .58 : receiver.x > fieldWidth * .42;
    const inLane = Math.abs(receiver.x - zone.x) <= radii.x + lanePad;
    const trueVertical = receiver.read?.isVertical
      && !receiver.read?.isFlat
      && !receiver.read?.isComingBack;
    const deepBreaker = receiver.read?.routeDepth > (outsideDeepThird ? 132 : 64)
      && !receiver.read?.isComingBack;
    const deepEnough = trueVertical
      || deepBreaker
      || receiver.y <= state.start.y + 64;
    return inLane
      && deepEnough
      && receiver.vy < 32
      && (!outsideDeepThird || sameSide);
  });
  return laneThreats.sort((a, b) => {
    if (outsideDeepThird) {
      const aVertical = a.read?.isVertical && !a.read?.isFlat && !a.read?.isComingBack;
      const bVertical = b.read?.isVertical && !b.read?.isFlat && !b.read?.isComingBack;
      if (aVertical !== bVertical) return aVertical ? -1 : 1;
    }
    const depthDiff = a.y - b.y;
    if (Math.abs(depthDiff) > 12) return depthDiff;
    return (b.read?.verticalSpeed || 0) - (a.read?.verticalSpeed || 0);
  })[0] || null;
}

function postureEyeVector(state, posture, mode, target, gapX, gapY, context = {}) {
  const isDeepSafety = Boolean(context.isDeepSafety);
  if (mode === "backfield" || mode === "run-fit" || mode === "bite") {
    return vectorToward(state, backfieldReadPoint());
  }
  if (posture === "backpedal" || mode === "midpoint") {
    return ballFacingVector(state);
  }
  if (mode === "carry" && !isDeepSafety) {
    return ballFacingVector(state);
  }
  if (posture === "open" || posture === "recover") {
    return target ? vectorToward(state, target) : movementFacingVector(state, gapX, gapY);
  }
  if (mode === "wall" || mode === "rally" || posture === "drive") {
    return target ? vectorToward(state, target) : movementFacingVector(state, gapX, gapY);
  }
  if (mode === "carry" || mode === "lean") {
    return target ? vectorToward(state, target) : movementFacingVector(state, gapX, gapY);
  }
  return ballFacingVector(state);
}

function approachSpeedLimit(maxSpeed, separation, slowRadius = 42) {
  if (separation >= slowRadius) return maxSpeed;
  const ratio = Math.max(.28, separation / slowRadius);
  return maxSpeed * ratio;
}

function phaseChangeBrake(state, nextMode, safeDelta) {
  if (state.lastMode && state.lastMode !== nextMode) {
    state.transitionBrake = Math.max(state.transitionBrake || 0, .12);
    state.vx *= .72;
    state.vy *= .72;
  }
  state.transitionBrake = Math.max(0, (state.transitionBrake || 0) - safeDelta);
  return state.transitionBrake > 0 ? .55 : 1;
}

function trafficSlowdown(point, receivers, defenderId = "") {
  let slowdown = 1;
  receivers.forEach(receiver => {
    if (receiver.id === defenderId) return;
    const distance = Math.hypot(receiver.x - point.x, receiver.y - point.y);
    if (distance < 26) slowdown = Math.min(slowdown, .62);
    else if (distance < 42) slowdown = Math.min(slowdown, .78);
  });
  return slowdown;
}

function moveManDefender(state, receiverPosition, elapsed, deltaSeconds) {
  const safeDelta = Math.max(0, Math.min(.05, Number(deltaSeconds) || 0));
  const profile = state.profile || {};
  state.body ||= initializeBodyState("shuffle");
  setDefenderEyeState(state, vectorToward(state, receiverPosition), receiverPosition.id || "", "man");
  const reactionVariance = profile.reaction ? profile.reaction * .35 : 0;
  const reactionTime = (state.initialCushion < 55 ? 0.09 : 0.14)
    + reactionVariance
    + ((profile.falseStep || 0) < (profile.mistakeRate || 0) ? .08 : 0);
  if (elapsed < reactionTime || !safeDelta) {
    state.lastReceiver = { ...receiverPosition };
    return { x: state.x, y: state.y };
  }

  const receiverDx = receiverPosition.x - state.lastReceiver.x;
  const receiverDy = receiverPosition.y - state.lastReceiver.y;
  const receiverStep = Math.hypot(receiverDx, receiverDy);
  const directionX = receiverStep ? receiverDx / receiverStep : state.lastDirection.x;
  const directionY = receiverStep ? receiverDy / receiverStep : state.lastDirection.y;
  const receiverVx = receiverDx / safeDelta;
  const receiverVy = receiverDy / safeDelta;
  const previousDirection = state.lastDirection;
  const receiverDepth = state.receiverStart.y - receiverPosition.y;
  const receiverLateralTravel = Math.abs(receiverPosition.x - state.receiverStart.x);
  const directionChange = Math.hypot(
    directionX - previousDirection.x,
    directionY - previousDirection.y
  );
  const verticalRelease = receiverVy < -18
    || (directionY < -.38 && receiverDepth > 8);
  const lateralBreak = Math.abs(receiverVx) > Math.max(34, Math.abs(receiverVy) * 1.2);
  const downhillBreak = receiverVy > 18;
  if (receiverDepth > 18 || verticalRelease) state.deepThreatened = true;
  const routeBreakEvidence = elapsed > .2 && (
    downhillBreak
    || (state.deepThreatened && lateralBreak)
    || (state.deepThreatened && directionChange > .85)
    || (elapsed > .3 && receiverLateralTravel > 24 && lateralBreak)
  );
  state.breakEvidence = Math.max(
    0,
    (state.breakEvidence || 0) + (routeBreakEvidence ? safeDelta : -safeDelta * 1.7)
  );
  if (state.breakEvidence >= .08) state.breakConfirmed = true;
  const renewedVerticalThreat = state.breakConfirmed
    && receiverVy < -42
    && Math.abs(receiverVy) > Math.abs(receiverVx) * 1.12;
  if (renewedVerticalThreat) {
    state.verticalRecoveryTime = (state.verticalRecoveryTime || 0) + safeDelta;
    if (state.verticalRecoveryTime > .1) {
      state.breakConfirmed = false;
      state.breakEvidence = 0;
    }
  } else {
    state.verticalRecoveryTime = 0;
  }
  if (state.breakConfirmed) {
    state.phase = "drive";
  } else if (state.deepThreatened) {
    state.phase = "carry";
  } else {
    state.phase = "mirror";
  }

  const cushion = receiverPosition.y - state.y;
  let targetX = state.x;
  let targetY = state.y;
  let maxSpeed = 90;
  let acceleration = 430;

  if (state.phase === "mirror") {
    // Hold depth and mirror the release until the receiver threatens vertically.
    const leverage = Math.max(-42, Math.min(42, state.horizontalLeverage));
    targetX = receiverPosition.x + leverage;
    targetY = state.start.y;
    maxSpeed = (state.initialCushion < 55 ? 104 : 92) * (.92 + ((profile.aggressiveness || .5) * .16));
    acceleration = (state.initialCushion < 55 ? 560 : 450) * (.88 + ((profile.awareness || .7) * .2));
  } else if (state.phase === "carry") {
    // Open and carry from an over-the-top position instead of chasing the receiver's hip.
    const baseCarryCushion = state.initialCushion < 55 ? 20 : 30;
    const desiredCushion = cushion < baseCarryCushion
      ? baseCarryCushion + 7
      : cushion > 48
        ? 40
        : cushion;
    targetX = receiverPosition.x + (state.horizontalLeverage * .55);
    targetY = Math.min(state.start.y, receiverPosition.y - desiredCushion);
    const receiverIsLevel = cushion < 10;
    const cushionThreatened = cushion < 24;
    maxSpeed = (receiverIsLevel ? 154 : cushionThreatened ? 140 : 122)
      * (.9 + ((profile.aggressiveness || .5) * .18));
    acceleration = (receiverIsLevel ? 940 : cushionThreatened ? 800 : 680)
      * (.88 + ((profile.awareness || .7) * .22));
  } else {
    // Once the receiver declares the break, plant and drive toward the upfield hip.
    const trailDistance = state.deepThreatened ? 8 : 5;
    targetX = receiverPosition.x - (directionX * trailDistance);
    targetY = receiverPosition.y - Math.min(0, directionY * trailDistance);
    const separationFromReceiver = Math.hypot(
      receiverPosition.x - state.x,
      receiverPosition.y - state.y
    );
    maxSpeed = (separationFromReceiver > 55 ? 142 : separationFromReceiver > 30 ? 128 : 116)
      * (.9 + ((profile.aggressiveness || .5) * .2));
    acceleration = 820 * (.86 + ((profile.awareness || .7) * .24));
  }

  const gapX = targetX - state.x;
  const gapY = targetY - state.y;
  const separation = Math.hypot(gapX, gapY);
  const nextPosture = state.phase === "carry"
    ? "open"
    : state.phase === "drive"
      ? "drive"
      : "shuffle";
  const bodyProfile = bodyMovementProfile(state.body, nextPosture, gapX, gapY, safeDelta);
  const phaseBrake = phaseChangeBrake(state, state.phase, safeDelta);
  const controlledSpeed = approachSpeedLimit(maxSpeed * bodyProfile.speed, separation, state.phase === "drive" ? 24 : 32);
  const desiredVx = separation ? (gapX / separation) * controlledSpeed : 0;
  const desiredVy = separation ? (gapY / separation) * controlledSpeed : 0;
  const velocityChange = Math.hypot(desiredVx - state.vx, desiredVy - state.vy);
  const maxVelocityChange = acceleration * bodyProfile.accel * phaseBrake * safeDelta;
  const velocityRatio = velocityChange
    ? Math.min(1, maxVelocityChange / velocityChange)
    : 0;

  state.vx += (desiredVx - state.vx) * velocityRatio;
  state.vy += (desiredVy - state.vy) * velocityRatio;
  state.x += state.vx * safeDelta;
  state.y += state.vy * safeDelta;
  state.x = Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, state.x));
  state.y = Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, state.y));
  if (state.phase !== "drive" && state.y > state.start.y) {
    state.y = state.start.y;
    state.vy = Math.min(0, state.vy);
  }
  state.lastMode = state.phase;
  state.lastReceiver = { ...receiverPosition };
  if (receiverStep) state.lastDirection = { x: directionX, y: directionY };
  setDefenderEyeState(state, vectorToward(state, receiverPosition), receiverPosition.id || "", `man-${state.phase}`);
  return { x: state.x, y: state.y };
}

function smoothPointToward(current, target, maxStep = 18) {
  const dx = target.x - current.x;
  const dy = target.y - current.y;
  const distance = Math.hypot(dx, dy);
  if (!distance || distance <= maxStep) return { ...target };
  return {
    x: current.x + (dx / distance) * maxStep,
    y: current.y + (dy / distance) * maxStep
  };
}

function clampToZone(point, zone) {
  const dx = point.x - zone.x;
  const dy = point.y - zone.y;
  const radii = zoneRadii(zone);
  const distance = Math.hypot(dx / radii.x, dy / radii.y);
  if (!distance || distance <= 1) return point;
  return {
    x: zone.x + (dx / distance),
    y: zone.y + (dy / distance)
  };
}

function createDefenderAiProfile(start, zone, manTarget = null, realism = defaultDefenseRealism(), repId = "") {
  const settings = normalizeDefenseRealism(realism);
  const radii = zone ? zoneRadii(zone) : { x: 130, y: 130 };
  const deepPlayer = start.y < lineOfScrimmage - 190
    || (zone && zone.y < lineOfScrimmage - Math.max(155, radii.y * .75));
  const flatZone = zone && zone.y > lineOfScrimmage - 110;
  const awareness = settings.awareness / 100;
  const discipline = settings.discipline / 100;
  const aggression = settings.aggression / 100;
  const mistakes = settings.mistakes / 100;
  const personality = settings.personality;
  const matchBoost = personality === "match" ? .22 : personality === "spot" ? -.18 : 0;
  const aggressionBoost = personality === "aggressive" ? .22 : personality === "conservative" ? -.16 : 0;
  const disciplinePenalty = personality === "undisciplined" ? .22 : 0;
  return {
    reaction: (deepPlayer ? .34 : flatZone ? .18 : .23) - (awareness * .12) + (Math.random() * .14),
    aggressiveness: Math.max(.15, Math.min(1, .22 + (aggression * .68) + aggressionBoost + (Math.random() * .16))),
    matchTendency: Math.max(.1, Math.min(1, .34 + (discipline * .28) + (awareness * .18) + matchBoost + (Math.random() * .18))),
    flatRally: flatZone
      ? Math.max(.1, Math.min(1, .28 + (aggression * .48) + aggressionBoost + (Math.random() * .18)))
      : Math.max(.1, Math.min(1, .18 + (aggression * .28) + (Math.random() * .14))),
    patience: Math.max(.1, Math.min(1, (deepPlayer ? .54 : .34) + (discipline * .34) - aggressionBoost + (Math.random() * .12))),
    cushion: deepPlayer ? 34 + (Math.random() * 16) : 12 + (Math.random() * 10),
    awareness,
    discipline: Math.max(0, discipline - disciplinePenalty),
    mistakeRate: Math.max(0, Math.min(1, mistakes + disciplinePenalty - (awareness * .18))),
    eyes: settings.eyes,
    personality,
    repId,
    falseStep: Math.random(),
    runBite: Math.random(),
    overCarry: Math.random(),
    jumpShort: Math.random(),
    flatFoot: Math.random(),
    choiceNoise: Math.random(),
    wrongChoice: Math.random(),
    safetyChoice: Math.random(),
    safetyModeRoll: Math.random(),
    settleNoise: Math.random(),
    zonePriority: Math.max(.55, Math.min(1, .62 + (discipline * .22) + (awareness * .18) - (mistakes * .16) + (Math.random() * .08))),
    assignmentMistake: Math.random() < Math.max(.015, Math.min(.32, (mistakes * .32) + ((1 - discipline) * .08))),
    routePrioritySeed: Math.random(),
    repSalt: Math.random(),
    landmarkX: (Math.random() - .5) * 42,
    landmarkY: (Math.random() - .5) * 26,
    leverageNoise: (Math.random() - .5) * 34,
    leanNoise: (Math.random() - .5) * .22,
    manTarget
  };
}

function playInfluence(playIntent = defaultPlayIntent(), profile = {}) {
  const intent = normalizePlayIntent(playIntent);
  const backfieldRead = profile.eyes === "backfield" || (
    profile.eyes === "balanced" && (intent.playAction || intent.rpo)
  );
  const biteRisk = intent.playAction
    ? .5
    : intent.rpo
      ? .5
      : .04;
  const mistakeMultiplier = profile.mistakeRate || 0;
  const normalEyeRisk = .16 + mistakeMultiplier * .36 + ((1 - (profile.awareness || .7)) * .22);
  return {
    backfieldRead,
    biteRisk,
    falseStep: backfieldRead && profile.falseStep < biteRisk + mistakeMultiplier * .42,
    runBite: backfieldRead && profile.runBite < biteRisk,
    flatFoot: profile.flatFoot < normalEyeRisk,
    wrongChoice: profile.wrongChoice < normalEyeRisk,
    delayedRouteRead: backfieldRead && (intent.playAction || intent.rpo),
    rpo: intent.rpo,
    playAction: intent.playAction
  };
}

function chooseSafetyMode(profile, verticalThreatCount, hasDeepHelp, technique = "balanced", claimedByOther = false) {
  if (verticalThreatCount < 2) return "attach";
  if (!hasDeepHelp && technique !== "matchVertical") return "overplay-deepest";
  if (technique === "keepDepth" || technique === "midpoint") return "midpoint";
  if (technique === "matchVertical") return profile.safetyChoice < .5 ? "attach-left" : "attach-right";
  const roll = profile.safetyModeRoll || 0;
  const mistakeRate = profile.mistakeRate || 0;
  const discipline = profile.discipline || .7;
  if (claimedByOther) {
    const bustChance = .03 + (mistakeRate * .12) + ((1 - discipline) * .08);
    if ((profile.wrongChoice || 0) >= bustChance) {
      return roll < .62 + (discipline * .18) ? "midpoint" : "overplay-deepest";
    }
  }
  if (roll < .24 + (discipline * .16)) return "midpoint";
  if (roll < .44) return "attach-left";
  if (roll < .64) return "attach-right";
  if (roll < .78 + mistakeRate * .12) return "jump-near";
  if (roll < .9 || hasDeepHelp) return "overplay-deepest";
  return "late";
}

function chooseCloseThreat(threats, profile, influence, spread = 28) {
  if (!threats.length) return null;
  const testMode = Boolean(profile.testMode);
  if (testMode) {
    const inZoneThreats = threats.filter(threat =>
      threat.zoneDistance <= (threat.read?.isVertical ? 1.6 : 1.38)
    );
    if (inZoneThreats.length > 1) {
      const playableThreats = inZoneThreats.filter(threat =>
        inZoneThreats[0].threatScore - threat.threatScore <= 135
      );
      const pool = playableThreats.length > 1 ? playableThreats : inZoneThreats;
      const index = Math.floor((profile.repSalt || Math.random()) * pool.length) % pool.length;
      return pool[index];
    }
  }
  const window = spread
    + ((profile.mistakeRate || 0) * (testMode ? 22 : 32))
    + ((1 - (profile.awareness || .7)) * (testMode ? 12 : 18))
    + (testMode ? 10 : 0);
  const closeThreats = threats.filter(threat =>
    threats[0].threatScore - threat.threatScore <= window
  );
  if (closeThreats.length <= 1) return threats[0];
  const inZoneCloseThreats = closeThreats.filter(threat =>
    threat.zoneDistance <= (threat.read?.isVertical ? 1.55 : 1.35)
  );
  const choicePool = testMode && inZoneCloseThreats.length > 1
    ? inZoneCloseThreats
    : closeThreats;
  const shouldVary = influence.wrongChoice
    || (profile.choiceNoise || 0) < .55
    || (profile.personality === "aggressive" && (profile.jumpShort || 0) < .62);
  if (!shouldVary) return threats[0];
  const index = Math.floor(
    ((profile.choiceNoise || 0) * 1009)
    + ((profile.safetyChoice || 0) * 97)
    + ((profile.routePrioritySeed || 0) * 193)
    + ((profile.repSalt || 0) * 389)
  ) % choicePool.length;
  return choicePool[index];
}

function committedThreat(threats, state, profile, influence, elapsed, spread = 28) {
  if (!threats.length) return null;
  const current = state.primaryThreatId
    ? threats.find(threat => threat.id === state.primaryThreatId)
    : null;
  const holdUntil = state.commitUntil || 0;
  if (current && elapsed < holdUntil) {
    const topThreatClearlyBetter = threats[0]
      && threats[0].id !== current.id
      && threats[0].threatScore - current.threatScore > 42 + ((profile.discipline || .7) * 18);
    if (!topThreatClearlyBetter) return current;
  }
  const next = chooseCloseThreat(threats, profile, influence, spread);
  if (next) {
    state.commitUntil = elapsed + .32 + ((profile.discipline || .7) * .28);
  }
  return next;
}

function zoneStyle(zone, state) {
  const radii = zoneRadii(zone);
  const isDeepSafety = state.start.y < lineOfScrimmage - 190
    || zone.y < lineOfScrimmage - Math.max(155, radii.y * .75);
  const isFlatDefender = zone.y > lineOfScrimmage - 110;
  const isOutsideLane = zone.x < fieldWidth * .34
    || zone.x > fieldWidth * .66;
  const isWideZone = zone.x < fieldWidth * .34
    || zone.x > fieldWidth * .66
    || radii.x > radii.y * 1.18;
  return {
    radii,
    isDeepSafety,
    isFlatDefender,
    isWideZone,
    isOutsideDeepThird: isDeepSafety && isOutsideLane,
    isCurlFlat: isWideZone && !isDeepSafety,
    isHook: !isDeepSafety && !isWideZone
  };
}

function receiverRouteRead(receiver) {
  const verticalSpeed = Math.max(0, -receiver.vy);
  const routeDepth = Math.max(0, lineOfScrimmage - receiver.y);
  const lateralSpeed = Math.abs(receiver.vx);
  return {
    routeDepth,
    verticalSpeed,
    isVertical: receiver.vy < -24 || (routeDepth > 34 && receiver.vy < 12),
    isFlat: receiver.y > lineOfScrimmage - 125 && lateralSpeed > Math.max(22, verticalSpeed * .75),
    isCrosser: lateralSpeed > Math.max(30, Math.abs(receiver.vy) * 1.08),
    isComingBack: receiver.vy > 24
  };
}

function confirmedReceiverRead(receiver, state, safeDelta) {
  state.receiverReads ||= {};
  const read = receiver.read || receiverRouteRead(receiver);
  const saved = state.receiverReads[receiver.id] ||= {
    crosser: 0,
    comingBack: 0,
    vertical: 0
  };
  saved.crosser = Math.max(0, saved.crosser + (read.isCrosser ? safeDelta : -safeDelta * 1.5));
  saved.comingBack = Math.max(0, saved.comingBack + (read.isComingBack ? safeDelta : -safeDelta * 1.5));
  saved.vertical = Math.max(0, saved.vertical + (read.isVertical ? safeDelta : -safeDelta));
  return {
    ...read,
    isCrosser: saved.crosser > .12,
    isComingBack: saved.comingBack > .1,
    isVertical: saved.vertical > .06 || read.routeDepth > 55
  };
}

function defenderFacingVector(state, style, profile, influence, readLandmark) {
  if (state.facing) return normalizeVector(state.facing);
  if (influence?.backfieldRead) {
    return vectorToward(state, backfieldReadPoint());
  }
  if (state.primaryThreatId && state.lastSeenThreats?.[state.primaryThreatId]) {
    const threat = state.lastSeenThreats[state.primaryThreatId];
    return vectorToward(state, threat);
  }
  if (profile?.eyes === "landmark" && readLandmark?.y > state.y) {
    return vectorToward(state, readLandmark);
  }
  return ballFacingVector(state);
}

function receiverVisionInfo(receiver, state, style, profile, influence, readLandmark) {
  const facing = defenderFacingVector(state, style, profile, influence, readLandmark);
  const dx = receiver.x - state.x;
  const dy = receiver.y - state.y;
  const distance = Math.hypot(dx, dy) || 1;
  const dot = ((dx / distance) * facing.x) + ((dy / distance) * facing.y);
  const baseCone = style.isDeepSafety ? -.05 : style.isFlatDefender || style.isCurlFlat ? .08 : .02;
  const awarenessBoost = ((profile.awareness || .7) - .5) * -.12;
  const backfieldPenalty = influence?.backfieldRead
    ? style.isDeepSafety ? .1 : .18
    : 0;
  const coneThreshold = Math.max(style.isDeepSafety ? -.32 : -.16, Math.min(.42, baseCone + awarenessBoost + backfieldPenalty));
  const read = receiver.read || receiverRouteRead(receiver);
  const eyeMode = profile.eyes || "balanced";
  let visibility = (dot - coneThreshold) / (1 - coneThreshold);
  if (eyeMode === "receiver" || eyeMode === "nearest") visibility += .14;
  if (eyeMode === "landmark") visibility += .04;
  if (eyeMode === "backfield") visibility -= .18;
  if (read.isVertical && style.isDeepSafety) visibility += .18;
  if (read.isFlat && (style.isFlatDefender || style.isCurlFlat)) visibility += .08;
  visibility = Math.max(0, Math.min(1, visibility));
  const peripheral = dot > coneThreshold - .22 && visibility < .42;
  return {
    dot,
    distance,
    visible: visibility > .08,
    clear: visibility > .38,
    peripheral,
    score: visibility
  };
}

function receiverThreatScore(receiver, zone, state, style, hasDeepHelp, claimCount = 0, receiverIndex = 0, vision = null) {
  const radii = zoneRadii(zone);
  const projected = {
    x: receiver.x + (receiver.vx * .16),
    y: receiver.y + (receiver.vy * .16)
  };
  const distance = zoneDistance(projected, zone);
  const read = receiver.read || receiverRouteRead(receiver);
  const movingIntoZone = receiver.zoneDistancePrevious - distance;
  const profile = state.profile || {};
  const testMode = Boolean(profile.testMode);
  const zonePriority = profile.zonePriority || .72;
  const clearlyInZone = distance <= (style.isDeepSafety ? 1.5 : 1.22);
  const outsideZone = distance > (style.isDeepSafety ? 1.9 : 1.5);
  const defenderSide = zone.x < fieldWidth / 2 ? "left" : "right";
  const receiverSide = receiver.x < fieldWidth / 2 ? "left" : "right";
  const sameSide = defenderSide === receiverSide;
  const middleZone = Math.abs(zone.x - fieldWidth / 2) < fieldWidth * .14;
  const technique = normalizeDefenderTechnique(state.technique);
  const visionInfo = vision || receiver.vision || { score: 1, clear: true, peripheral: false };
  let score = (1.45 - Math.min(1.45, distance)) * 80;
  if (testMode) {
    score += clearlyInZone ? 30 + (zonePriority * 28) : 0;
    score -= outsideZone && !profile.assignmentMistake ? 34 + (zonePriority * 24) : 0;
    if (!middleZone) {
      score += sameSide ? 26 + (zonePriority * 18) : 0;
      score -= !sameSide && !profile.assignmentMistake ? 42 + (zonePriority * 26) : 0;
    }
  }
  score += Math.min(30, Math.max(-12, movingIntoZone * 125));
  score += Math.min(24, read.verticalSpeed * .16);
  score += (visionInfo.score - .5) * (style.isDeepSafety ? 34 : 28);
  if (visionInfo.clear) score += style.isDeepSafety ? 14 : 10;
  if (visionInfo.peripheral) score -= 10 * (profile.discipline || .7);
  if (!visionInfo.visible) {
    const blindPenalty = 18
      + ((profile.awareness || .7) * 16)
      + (distance > 1 ? 18 : 0)
      - ((profile.mistakeRate || 0) * 8);
    score -= blindPenalty;
  }
  if (style.isDeepSafety) {
    score += Math.min(58, read.routeDepth * .18);
    score += read.isVertical ? 28 : 0;
    score += receiver.y < state.y + 70 ? 30 : 0;
    score -= read.isComingBack ? 38 * (profile.patience || .7) : 0;
    score -= read.isFlat ? 26 : 0;
    if (style.isOutsideDeepThird) {
      const outsideLane = sameSide && distance <= 1.9;
      const verticalLaneThreat = outsideLane
        && read.isVertical
        && !read.isFlat
        && !read.isComingBack;
      score += verticalLaneThreat ? 76 + ((profile.discipline || .7) * 28) : 0;
      score -= read.isFlat || read.isComingBack ? 58 + ((profile.discipline || .7) * 30) : 0;
      score -= !sameSide && !profile.assignmentMistake ? 48 + ((profile.awareness || .7) * 24) : 0;
    }
  } else if (style.isFlatDefender || style.isCurlFlat) {
    score += read.isFlat ? 34 * (profile.flatRally || .5) : 0;
    score += read.isCrosser ? 12 : 0;
    score += !hasDeepHelp && read.isVertical ? 18 * (profile.matchTendency || .6) : 0;
    score -= hasDeepHelp && read.routeDepth > 135 ? 18 : 0;
  } else {
    score += receiver.y >= zone.y - radii.y * .8 ? 14 : 0;
    score += read.isCrosser ? 18 : 0;
    score += !hasDeepHelp && read.isVertical ? 12 : 0;
  }
  if (technique === "keepDepth") {
    score += read.isVertical ? 22 : 0;
    score -= read.isComingBack || read.isFlat ? 24 : 0;
  } else if (technique === "midpoint") {
    score += read.isVertical ? 12 : 0;
    score -= read.isComingBack ? 12 : 0;
  } else if (technique === "matchVertical") {
    score += read.isVertical ? 34 : 0;
  } else if (technique === "jumpFirst") {
    score += receiver.zoneDistance < 1 ? 22 : 0;
    score += read.isFlat || read.isComingBack ? 16 : 0;
  } else if (technique === "robInside") {
    score += read.isCrosser && Math.abs(receiver.x - zone.x) < radii.x * .85 ? 30 : 0;
  } else if (technique === "wallCrosser") {
    score += read.isCrosser ? 34 : 0;
  }
  const duplicateClaimPenalty = style.isDeepSafety
    ? 30 + ((profile.discipline || .7) * 26) - ((profile.mistakeRate || 0) * 14)
    : 28;
  score -= claimCount * duplicateClaimPenalty;
  if (state.primaryThreatId === receiver.id) score += 8 + ((profile.discipline || .7) * 8);
  const repNoise = Math.sin(
    ((profile.choiceNoise || .5) * 999)
    + (receiverIndex * 3.71)
    + ((profile.repId || "").length * .37)
    + ((profile.routePrioritySeed || .5) * 73)
  );
  const noiseWindow = testMode
    ? 8 + ((profile.mistakeRate || 0) * 30) + ((1 - (profile.awareness || .7)) * 14)
    : 20 + ((profile.mistakeRate || 0) * 34) + ((1 - (profile.awareness || .7)) * 24);
  score += repNoise * noiseWindow;
  return score;
}

function qbLookRouteInfluence(receiver, defenderState, playIntent = {}, style = {}) {
  const lookPoint = playIntent.qbLookPoint;
  const qbPoint = animationState?.offense?.QB || offensePosition("QB");
  const qbFlow = playIntent.qbFlowPoint || null;
  if (!lookPoint && !qbFlow) return 0;
  const profile = defenderState.profile || {};
  const susceptibility = .18
    + ((profile.aggressiveness || .5) * .26)
    + ((1 - (profile.discipline || .7)) * .32)
    + ((profile.mistakeRate || 0) * .34);
  const deepDiscount = style.isDeepSafety ? .3 : 1;
  let score = 0;
  if (lookPoint) {
    const laneDistance = pointLineDistance(receiver, qbPoint, lookPoint);
    const lookDistance = Math.hypot(receiver.x - lookPoint.x, receiver.y - lookPoint.y);
    const closeToLook = laneDistance < 38 || lookDistance < 72;
    if (closeToLook) {
      const lookStrength = Math.max(0, 1 - Math.min(1, laneDistance / 62));
      score += lookStrength * susceptibility * deepDiscount * 42;
    }
  }
  if (qbFlow) {
    const flowDistance = pointLineDistance(receiver, qbPoint, qbFlow);
    const flowSide = Math.sign(qbFlow.x - qbPoint.x);
    const receiverSide = Math.sign(receiver.x - qbPoint.x);
    const sameFlowSide = flowSide === 0 || receiverSide === 0 || flowSide === receiverSide;
    if (sameFlowSide && flowDistance < 96) {
      const flowStrength = Math.max(0, 1 - Math.min(1, flowDistance / 110));
      score += flowStrength * susceptibility * (style.isDeepSafety ? .22 : .55) * 28;
    }
  }
  return score;
}

function qbFlowPointFromPlayback(playIntent = {}) {
  if (playIntent.qbFlowPoint) return playIntent.qbFlowPoint;
  const qbPoint = animationState?.offense?.QB || offensePosition("QB");
  const qbStart = editorOffensePositions().QB || qbPoint;
  const dx = qbPoint.x - qbStart.x;
  const dy = qbPoint.y - qbStart.y;
  if (Math.hypot(dx, dy) < 10) return null;
  return {
    x: qbPoint.x + dx * 3.2,
    y: qbPoint.y + dy * 2.4
  };
}

function receiverSettledInZone(receiver, zone, style) {
  const speed = Math.hypot(receiver.vx || 0, receiver.vy || 0);
  const depthOk = style.isFlatDefender || style.isCurlFlat
    ? receiver.y > zone.y - zoneRadii(zone).y * .8
    : true;
  return receiver.zoneDistance <= (style.isDeepSafety ? 1.25 : 1.08)
    && speed < 34
    && depthOk
    && !receiver.read.isVertical;
}

function receiverFieldSide(receiver) {
  if (receiver.x < fieldWidth * .44) return "left";
  if (receiver.x > fieldWidth * .56) return "right";
  return "middle";
}

function receiverMovingOutside(receiver) {
  const side = receiverFieldSide(receiver);
  if (side === "middle") return false;
  return side === "left" ? receiver.vx < -12 : receiver.vx > 12;
}

function routeLevel(receiver) {
  const depth = receiver.read?.routeDepth || 0;
  if (receiver.read?.isFlat || depth < 42) return "low";
  if (receiver.read?.isVertical || depth > 132) return "high";
  return "mid";
}

function recognizeRouteDistribution(receivers) {
  const concepts = [];
  const tags = new Map(receivers.map(receiver => [receiver.id, {
    score: 0,
    labels: new Set(),
    highLowPartnerId: "",
    midpointIds: []
  }]));
  const bySide = ["left", "right"].map(side => ({
    side,
    receivers: receivers.filter(receiver =>
      receiverFieldSide(receiver) === side
    )
  }));
  const addTag = (receiver, label, score = 0, partnerId = "") => {
    const tag = tags.get(receiver.id);
    if (!tag) return;
    tag.labels.add(label);
    tag.score += score;
    if (partnerId) tag.highLowPartnerId = partnerId;
  };

  bySide.forEach(({ side, receivers: sideReceivers }) => {
    const low = sideReceivers.filter(receiver =>
      routeLevel(receiver) === "low"
      || (
        Math.hypot(receiver.vx || 0, receiver.vy || 0) < 34
        && (receiver.read?.routeDepth || 0) < 82
        && !receiver.read?.isVertical
      )
    );
    const mid = sideReceivers.filter(receiver => routeLevel(receiver) === "mid");
    const high = sideReceivers.filter(receiver => routeLevel(receiver) === "high");
    const outsideHigh = high.filter(receiver =>
      receiver.read.isVertical || receiverMovingOutside(receiver)
    );
    const outsideLow = low.filter(receiver =>
      receiver.read.isFlat || receiverMovingOutside(receiver)
    );

    if (outsideHigh.length && outsideLow.length) {
      concepts.push({ type: "smash", side, highIds: outsideHigh.map(receiver => receiver.id), lowIds: outsideLow.map(receiver => receiver.id) });
      outsideHigh.forEach(highReceiver => addTag(highReceiver, "smash-high", 26, outsideLow[0]?.id));
      outsideLow.forEach(lowReceiver => addTag(lowReceiver, "smash-low", 18, outsideHigh[0]?.id));
    }
    if (low.length && mid.length && high.length) {
      concepts.push({ type: "flood", side, lowIds: low.map(receiver => receiver.id), midIds: mid.map(receiver => receiver.id), highIds: high.map(receiver => receiver.id) });
      low.forEach(receiver => addTag(receiver, "flood-low", 14, high[0]?.id));
      mid.forEach(receiver => addTag(receiver, "flood-mid", 24, high[0]?.id));
      high.forEach(receiver => addTag(receiver, "flood-high", 24, low[0]?.id));
    }
    if (high.length >= 2) {
      concepts.push({ type: "vertical-stretch", side, highIds: high.map(receiver => receiver.id) });
      high.forEach(receiver => {
        addTag(receiver, "vertical-stretch", 30);
        tags.get(receiver.id).midpointIds = high
          .filter(other => other.id !== receiver.id)
          .map(other => other.id);
      });
    }
  });

  const crossers = receivers.filter(receiver =>
    receiver.read?.isCrosser
    && receiver.read.routeDepth < 95
  );
  const leftCrossers = crossers.filter(receiver => receiver.vx < -14);
  const rightCrossers = crossers.filter(receiver => receiver.vx > 14);
  if (leftCrossers.length && rightCrossers.length) {
    concepts.push({
      type: "mesh",
      ids: [...leftCrossers, ...rightCrossers].map(receiver => receiver.id)
    });
    [...leftCrossers, ...rightCrossers].forEach(receiver => addTag(receiver, "mesh-crosser", 26));
  }

  const verticals = receivers.filter(receiver =>
    receiver.read?.isVertical
    && !receiver.read?.isFlat
    && !receiver.read?.isComingBack
  );
  if (verticals.length >= 3) {
    concepts.push({ type: "four-verts", ids: verticals.map(receiver => receiver.id) });
    verticals.forEach(receiver => {
      addTag(receiver, "four-verts", 32);
      tags.get(receiver.id).midpointIds = verticals
        .filter(other => other.id !== receiver.id)
        .map(other => other.id);
    });
  }

  return {
    concepts,
    tags,
    has(type) {
      return concepts.some(concept => concept.type === type);
    }
  };
}

function applyRouteDistributionContext(receivers, distribution, style) {
  receivers.forEach(receiver => {
    const tag = distribution.tags.get(receiver.id);
    if (!tag) return;
    receiver.conceptLabels = [...tag.labels];
    receiver.conceptPartnerId = tag.highLowPartnerId;
    receiver.conceptMidpointIds = tag.midpointIds || [];
    let conceptScore = tag.score;
    if (style.isDeepSafety) {
      conceptScore *= receiver.read.isVertical ? 1.25 : .35;
    } else if (style.isFlatDefender || style.isCurlFlat) {
      conceptScore *= receiver.read.isFlat || receiver.read.isCrosser ? 1.05 : .82;
    }
    receiver.threatScore += conceptScore;
  });
}

function moveZoneDefender(
  state,
  zone,
  receivers,
  elapsed,
  deltaSeconds,
  hasDeepHelp = false,
  coverageClaims = new Map(),
  playIntent = defaultPlayIntent()
) {
  const safeDelta = Math.max(0, Math.min(.05, Number(deltaSeconds) || 0));
  const style = zoneStyle(zone, state);
  const { radii, isDeepSafety, isFlatDefender, isCurlFlat, isHook, isOutsideDeepThird } = style;
  const profile = state.profile || createDefenderAiProfile(state.start, zone);
  state.profile = profile;
  profile.testMode = Boolean(playIntent?.testMode);
  state.body ||= initializeBodyState(isDeepSafety ? "backpedal" : "shuffle");
  state.repId ||= profile.repId || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const technique = normalizeDefenderTechnique(state.technique);
  const influence = playInfluence(playIntent, profile);
  const readLandmark = {
    x: zone.x + (profile.landmarkX || 0),
    y: zone.y + (profile.landmarkY || 0)
  };
  const roofDefender = isDeepSafety;
  const reactionTime = profile.reaction
    + (influence.delayedRouteRead ? .12 * (1 - profile.discipline) : 0)
    + (influence.flatFoot ? .1 + ((1 - (profile.awareness || .7)) * .14) : 0);
  const deepThreatLine = Math.max(
    state.start.y,
    Math.min(state.start.y + 25, zone.y + (radii.y * .2))
  );
  const receiverCandidates = receivers
    .map((receiver, receiverIndex) => {
      const read = confirmedReceiverRead(receiver, state, safeDelta);
      const enriched = {
        ...receiver,
        zoneDistance: zoneDistance(receiver, zone),
        read
      };
      const vision = receiverVisionInfo(enriched, state, style, profile, influence, readLandmark);
      const qbLookScore = qbLookRouteInfluence(enriched, state, playIntent, style);
      const settledScore = receiverSettledInZone(enriched, zone, style)
        ? isDeepSafety ? 6 : isFlatDefender || isCurlFlat ? 34 : 26
        : 0;
      return {
        ...enriched,
        qbLookScore,
        vision,
        settledInZone: settledScore > 0,
        threatScore: receiverThreatScore(
          enriched,
          zone,
          state,
          style,
          hasDeepHelp,
          coverageClaims.get(receiver.id) || 0,
          receiverIndex,
          vision
        ) + qbLookScore + settledScore
      };
    });
  const routeDistribution = recognizeRouteDistribution(receiverCandidates);
  applyRouteDistributionContext(receiverCandidates, routeDistribution, style);
  state.routeConcepts = routeDistribution.concepts.map(concept => concept.type);
  state.lastSeenThreats = Object.fromEntries(
    receiverCandidates
      .filter(receiver => receiver.vision?.visible)
      .map(receiver => [receiver.id, { x: receiver.x, y: receiver.y }])
  );
  const visionPullLimit = isDeepSafety
    ? 2.1
    : isFlatDefender || isCurlFlat
      ? 1.62
      : 1.5;
  const zoneThreatLimit = isDeepSafety ? 1.55 : 1.28;
  const inZoneThreats = receiverCandidates.filter(receiver =>
    receiver.zoneDistance <= zoneThreatLimit
  );
  const inZoneThreatCount = inZoneThreats.length;
  const emptyZoneFindWork = elapsed >= reactionTime && inZoneThreatCount === 0;
  const qbFlowPoint = qbFlowPointFromPlayback(playIntent);
  const qbFlowLean = qbFlowPoint && elapsed >= reactionTime
    ? (() => {
        const qbPoint = animationState?.offense?.QB || offensePosition("QB");
        const flowDx = Math.max(-1, Math.min(1, (qbFlowPoint.x - qbPoint.x) / 180));
        const flowDy = Math.max(-1, Math.min(1, (qbFlowPoint.y - qbPoint.y) / 150));
        const profilePull = ((profile.aggressiveness || .5) * .42)
          + ((1 - (profile.discipline || .7)) * .35)
          + ((profile.mistakeRate || 0) * .22);
        const depthGuard = isDeepSafety ? .28 : isFlatDefender || isCurlFlat ? .74 : .58;
        return {
          x: flowDx * 34 * profilePull * depthGuard,
          y: flowDy * 18 * profilePull * depthGuard
        };
      })()
    : null;
  const findWorkLimit = isDeepSafety
    ? 2.1
    : isFlatDefender || isCurlFlat
      ? 2.45
      : 1.85;
  const visionPullChance = Math.min(
    profile.testMode ? .34 : .76,
    (profile.testMode ? .05 : .12)
      + ((profile.aggressiveness || .5) * (profile.testMode ? .18 : .34))
      + ((profile.mistakeRate || 0) * (profile.testMode ? .34 : .42))
      + ((1 - (profile.discipline || .7)) * (profile.testMode ? .16 : .3))
  );
  const threats = receiverCandidates
    .filter(receiver => {
      const inZoneRange = receiver.zoneDistance <= zoneThreatLimit;
      const defenderSide = zone.x < fieldWidth / 2 ? "left" : "right";
      const receiverSide = receiver.x < fieldWidth / 2 ? "left" : "right";
      const middleZone = Math.abs(zone.x - fieldWidth / 2) < fieldWidth * .14;
      const sameSide = middleZone || defenderSide === receiverSide;
      const routeCanPullEyes = receiver.read.isVertical
        || receiver.read.isCrosser
        || receiver.read.isFlat
        || receiver.read.isComingBack;
      const findWorkPull = emptyZoneFindWork
        && receiver.vision?.visible
        && receiver.zoneDistance <= findWorkLimit
        && routeCanPullEyes;
      const visiblePull = receiver.vision?.clear
        && receiver.zoneDistance <= visionPullLimit
        && routeCanPullEyes
        && (sameSide || profile.assignmentMistake || emptyZoneFindWork)
        && (
          (!profile.testMode && (profile.eyes === "receiver" || profile.eyes === "nearest"))
          || profile.assignmentMistake
          || emptyZoneFindWork
          || profile.wrongChoice < visionPullChance
        );
      if (findWorkPull) {
        receiver.findWorkPull = true;
        receiver.threatScore += (isFlatDefender || isCurlFlat ? 42 : 28)
          + ((profile.awareness || .7) * 12)
          + ((receiver.vision?.score || 0) * 20);
      }
      return inZoneRange || visiblePull || findWorkPull;
    })
    .sort((a, b) => b.threatScore - a.threatScore);
  const roofThreat = roofDefender
    ? deepestRoofThreat(receiverCandidates, state, zone, roofDefender)
    : null;

  let target = { ...state.start };
  let mode = "spot";
  let carryingDeepThreat = false;
  const isLinebackerLevel = !isDeepSafety
    && state.start.y > lineOfScrimmage - 190
    && state.start.y < lineOfScrimmage - 65;
  const runFitBite = influence.runBite && isLinebackerLevel && elapsed < reactionTime + .46;
  if (isDeepSafety && !runFitBite) {
    mode = "midpoint";
    target = deepZonePedalTarget(state, zone, readLandmark, elapsed, roofDefender);
    if (roofDefender && roofThreat) {
      const roofCushion = Math.max(profile.cushion + 18, 56);
      const outsideLeverage = isOutsideDeepThird
        ? zone.x < fieldWidth / 2 ? -20 : 20
        : 0;
      target = {
        x: laneCapX(zone, roofThreat.x + outsideLeverage),
        y: Math.min(target.y, roofThreat.y - roofCushion)
      };
      if (isOutsideDeepThird) mode = "carry";
      state.primaryThreatId = roofThreat.id;
      state.deepThreatId = roofThreat.id;
    }
  } else if (elapsed > .55 && !threats.length) {
    target = {
      x: state.start.x + ((readLandmark.x - state.start.x) * .26) + (qbFlowLean?.x || 0),
      y: state.start.y + ((readLandmark.y - state.start.y) * (isDeepSafety ? .1 : .24)) + (qbFlowLean?.y || 0)
    };
  }
  if (runFitBite) {
    mode = "run-fit";
    target = {
      x: state.start.x + ((fieldWidth / 2 - state.start.x) * .12),
      y: Math.min(lineOfScrimmage - 24, state.start.y + 30)
    };
  }
  if (!runFitBite && !isDeepSafety && influence.falseStep && elapsed < reactionTime + .22) {
    mode = "bite";
    const stepDepth = isDeepSafety ? 18 : isHook ? 14 : 9;
    target = {
      x: state.start.x + ((readLandmark.x - state.start.x) * .1),
      y: Math.min(lineOfScrimmage - 20, state.start.y + stepDepth)
    };
  }
  if (!runFitBite && elapsed >= reactionTime && isDeepSafety) {
    let verticalThreats = receiverCandidates
      .filter(receiver => {
        const sameOutsideSide = zone.x < fieldWidth / 2
          ? receiver.x < fieldWidth * .58
          : receiver.x > fieldWidth * .42;
        const trueVertical = receiver.read.isVertical
          && !receiver.read.isFlat
          && !receiver.read.isComingBack;
        const deepBreaker = receiver.read.routeDepth > (isOutsideDeepThird ? 132 : 74)
          && !receiver.read.isComingBack
          && !receiver.read.isFlat;
        return receiver.y <= deepThreatLine + (roofDefender ? 135 : 80)
          && receiver.vy < 18
          && (!isOutsideDeepThird || sameOutsideSide)
          && (!isOutsideDeepThird || trueVertical || deepBreaker)
          && (
            roofDefender
            || Math.abs(receiver.x - readLandmark.x) <= radii.x * 1.65
            || (receiver.vision?.clear && receiver.zoneDistance <= 2.15)
          );
      })
      .sort((a, b) => {
        const depthDiff = a.y - b.y;
        if (Math.abs(depthDiff) > 18) return depthDiff;
        if (isOutsideDeepThird) {
          const aTrueVertical = a.read.isVertical && !a.read.isFlat && !a.read.isComingBack;
          const bTrueVertical = b.read.isVertical && !b.read.isFlat && !b.read.isComingBack;
          if (aTrueVertical !== bTrueVertical) return aTrueVertical ? -1 : 1;
        }
        return (b.vision?.score || 0) - (a.vision?.score || 0);
      });
    const rareRoofBust = roofDefender
      && influence.wrongChoice
      && (profile.wrongChoice || 0) < Math.max(.015, (profile.mistakeRate || 0) * .16);
    if (influence.wrongChoice && !roofDefender && verticalThreats.length > 1) {
      const second = verticalThreats.find(receiver => receiver.y <= verticalThreats[0].y + 65);
      if (second) verticalThreats = [second, ...verticalThreats.filter(receiver => receiver.id !== second.id)];
    }
    if (verticalThreats.length) {
      const deepestThreat = verticalThreats[0];
      const nearbyVerticals = verticalThreats.filter(receiver =>
        receiver.y <= deepestThreat.y + 80
      );
      const outsideLaneVerticals = isOutsideDeepThird
        ? nearbyVerticals.filter(receiver =>
            receiver.zoneDistance <= 1.95
            && receiver.read.isVertical
            && !receiver.read.isFlat
            && !receiver.read.isComingBack
            && (
              zone.x < fieldWidth / 2
                ? receiver.x < fieldWidth * .58
                : receiver.x > fieldWidth * .42
            )
          )
        : [];
      const soloOutsideThirdThreat = outsideLaneVerticals.length === 1
        ? outsideLaneVerticals[0]
        : null;
      const leftmost = nearbyVerticals.reduce((left, receiver) =>
        receiver.x < left.x ? receiver : left, deepestThreat);
      const rightmost = nearbyVerticals.reduce((right, receiver) =>
        receiver.x > right.x ? receiver : right, deepestThreat);
      const unclaimedVerticals = nearbyVerticals.filter(receiver =>
        !(coverageClaims.get(receiver.id) || 0)
      );
      const claimedVerticals = nearbyVerticals.filter(receiver =>
        (coverageClaims.get(receiver.id) || 0) > 0
      );
      const allVerticalsAlreadyClaimed = claimedVerticals.length === nearbyVerticals.length;
      const safetyMode = chooseSafetyMode(
        profile,
        nearbyVerticals.length,
        hasDeepHelp,
        technique,
        allVerticalsAlreadyClaimed
      );
      const testRoofPool = profile.testMode && roofDefender && nearbyVerticals.length > 1
        ? nearbyVerticals.filter(receiver =>
            nearbyVerticals[0].threatScore - receiver.threatScore <= 140
          )
        : [];
      const testRoofThreat = testRoofPool.length > 1
        ? testRoofPool[Math.floor((profile.repSalt || Math.random()) * testRoofPool.length) % testRoofPool.length]
        : null;
      const selectedThreat = soloOutsideThirdThreat
        || testRoofThreat
        || (roofDefender && roofThreat && !profile.testMode
          ? roofThreat
          : null)
        || (safetyMode === "attach-left"
        ? leftmost
        : safetyMode === "attach-right"
          ? rightmost
          : safetyMode === "jump-near"
            ? nearbyVerticals.reduce((nearest, receiver) =>
                Math.abs(receiver.x - state.x) < Math.abs(nearest.x - state.x)
                  ? receiver
                  : nearest, deepestThreat)
            : unclaimedVerticals[0] || deepestThreat);
      const splitX = nearbyVerticals.length > 1
        ? (leftmost.x + rightmost.x) / 2
        : deepestThreat.x;
      const outsideLeverage = isOutsideDeepThird
        ? zone.x < fieldWidth / 2 ? -22 : 22
        : 0;
      const outsideThirdMidpoint = isOutsideDeepThird
        && nearbyVerticals.length > 1
        && safetyMode === "midpoint";
      const targetX = soloOutsideThirdThreat
        ? selectedThreat.x + outsideLeverage
        : roofDefender && roofThreat && !profile.testMode && !outsideThirdMidpoint
        ? roofThreat.x
        : safetyMode === "midpoint"
        ? splitX
        : selectedThreat.x + ((profile.leverageNoise || 0) * .25);
      const roofCushion = Math.max(profile.cushion + 16, 52);
      const targetCushion = soloOutsideThirdThreat
        ? Math.max(roofCushion, 60)
        : roofDefender
        ? roofCushion
        : safetyMode === "midpoint"
        ? profile.cushion
        : safetyMode === "late"
          ? profile.cushion * .35
          : profile.cushion * .9;
      const downhillMistake = influence.falseStep && elapsed < reactionTime + .42;
      const frozenEyes = influence.flatFoot && elapsed < reactionTime + .42;
      const lateSafety = roofDefender
        ? rareRoofBust && (downhillMistake || frozenEyes || safetyMode === "late")
        : downhillMistake || frozenEyes || safetyMode === "late";
      const cushionToThreat = selectedThreat.y - state.y;
      const verticalHasDeclared = selectedThreat.y < state.start.y - 34
        || cushionToThreat < Math.max(roofDefender ? 44 : 28, targetCushion * (roofDefender ? .92 : .62))
        || elapsed > reactionTime + .72;
      const pedalFirst = !lateSafety
        && safetyMode !== "midpoint"
        && !verticalHasDeclared
        && technique !== "matchVertical";
      const outsideThirdCarry = Boolean(soloOutsideThirdThreat) && !lateSafety;
      carryingDeepThreat = outsideThirdCarry || (!lateSafety && !pedalFirst);
      mode = outsideThirdCarry
        ? "carry"
        : roofDefender && !lateSafety
        ? "midpoint"
        : lateSafety
        ? "recover"
        : safetyMode === "midpoint" || (frozenEyes && !roofDefender) || pedalFirst
          ? "midpoint"
          : "carry";
      state.deepThreatId = selectedThreat.id;
      state.primaryThreatId = selectedThreat.id;
      const pedalDepth = (roofDefender ? 38 : 24) + Math.min(40, Math.max(0, state.start.y - selectedThreat.y) * (roofDefender ? .42 : .28));
      const pedalCapY = Math.min(state.start.y - pedalDepth, selectedThreat.y - Math.max(roofDefender ? 46 : 28, targetCushion * (roofDefender ? .95 : .82)));
      target = {
        x: roofDefender
          ? laneCapX(zone, targetX)
          : readLandmark.x + ((targetX - readLandmark.x) * (
            safetyMode === "midpoint" ? (hasDeepHelp ? .52 : .76) : .9
          )),
        y: outsideThirdCarry
          ? Math.min(deepThreatLine, selectedThreat.y - targetCushion)
          : safetyMode === "midpoint" || (frozenEyes && !roofDefender) || pedalFirst
          ? Math.min(state.start.y, pedalFirst ? pedalCapY : deepThreatLine)
          : Math.min(deepThreatLine, selectedThreat.y - targetCushion)
      };
      coverageClaims.set(
        selectedThreat.id,
        (coverageClaims.get(selectedThreat.id) || 0) + 1
      );
    }
  }
  if (!runFitBite && !carryingDeepThreat && elapsed >= reactionTime && threats.length && !isDeepSafety) {
    const roofThreats = roofDefender
      ? threats.filter(threat =>
          threat.read.isVertical
          || threat.y <= state.start.y + 54
          || threat.read.routeDepth > 82
        )
      : threats;
    if (roofDefender && !roofThreats.length) {
      state.primaryThreatId = null;
    }
    const primary = roofThreats.length
      ? committedThreat(roofThreats, state, profile, influence, elapsed, 24) || roofThreats[0]
      : null;
    if (!primary) {
      if (roofDefender) {
        target = {
          x: state.start.x + ((readLandmark.x - state.start.x) * .18),
          y: Math.min(state.start.y - 26, deepThreatLine)
        };
      }
    } else {
    state.primaryThreatId = primary.id;
    coverageClaims.set(primary.id, (coverageClaims.get(primary.id) || 0) + 1);
    const primaryOutsideZone = primary.zoneDistance > 1.08;
    const eyePullAmount = primaryOutsideZone
      ? Math.min(
          primary.findWorkPull ? .82 : .62,
          .18
            + ((primary.vision?.score || 0) * .24)
            + ((profile.aggressiveness || .5) * .12)
            + ((1 - (profile.discipline || .7)) * .18)
            + (primary.findWorkPull ? .22 : 0)
        )
      : 1;
    if (isDeepSafety) {
      const attach = technique === "matchVertical"
        || (technique !== "keepDepth" && technique !== "midpoint" && (primaryOutsideZone || (profile.safetyChoice > .42 && threats.length > 1)));
      const cushionToThreat = primary.y - state.y;
      const roofCushion = roofDefender ? Math.max(profile.cushion + 16, 52) : profile.cushion;
      const verticalHasDeclared = primary.y < state.start.y - 34
        || cushionToThreat < Math.max(roofDefender ? 44 : 28, roofCushion * (roofDefender ? .92 : .62))
        || elapsed > reactionTime + .72;
      const pedalFirst = attach && !verticalHasDeclared && technique !== "matchVertical";
      mode = attach && !pedalFirst ? "carry" : "midpoint";
      const pedalDepth = (roofDefender ? 38 : 24) + Math.min(40, Math.max(0, state.start.y - primary.y) * (roofDefender ? .42 : .28));
      const pedalCapY = Math.min(state.start.y - pedalDepth, primary.y - Math.max(roofDefender ? 46 : 28, roofCushion * (roofDefender ? .95 : .74)));
      target = {
        x: attach && !pedalFirst
          ? primary.x + ((profile.leverageNoise || 0) * .2)
          : readLandmark.x + ((primary.x - readLandmark.x + (profile.leverageNoise || 0)) * .48),
        y: attach && !pedalFirst
          ? Math.min(deepThreatLine, primary.y - roofCushion)
          : Math.min(state.start.y, pedalFirst ? pedalCapY : deepThreatLine)
      };
    } else {
      const splitZone = profile.testMode
        && inZoneThreatCount > 1
        && !profile.assignmentMistake
        && technique !== "matchVertical"
        && technique !== "jumpFirst";
      const singleZoneThreat = profile.testMode
        && inZoneThreatCount === 1
        && primary.zoneDistance <= zoneThreatLimit;
      const conceptPartner = primary.conceptPartnerId
        ? receiverCandidates.find(receiver => receiver.id === primary.conceptPartnerId)
        : null;
      const conceptLabels = primary.conceptLabels || [];
      const highLowConcept = conceptPartner
        && (conceptLabels.some(label => label.startsWith("smash") || label.startsWith("flood")))
        && conceptPartner.zoneDistance <= (isFlatDefender || isCurlFlat ? 2.35 : 1.85);
      const shouldConceptMidpoint = highLowConcept
        && !profile.assignmentMistake
        && technique !== "jumpFirst"
        && technique !== "matchVertical"
        && !primary.settledInZone
        && (isFlatDefender || isCurlFlat || isHook);
      const shouldRallyFlat = (isFlatDefender || isCurlFlat)
        && primary.read.isFlat
        && technique !== "keepDepth"
        && technique !== "matchVertical"
        && (primary.zoneDistance < 1.08 || primary.vision?.clear || profile.flatRally > .56 || technique === "jumpFirst" || (influence.rpo && profile.jumpShort < profile.mistakeRate + .3));
      const shouldContestZoneThreat = !primary.read.isVertical
        && primary.zoneDistance <= (isFlatDefender || isCurlFlat ? 1.16 : 1.05)
        && !shouldConceptMidpoint
        && !splitZone
        && technique !== "keepDepth";
      const shouldCarryVertical = !splitZone && primary.read.isVertical
        && (technique === "matchVertical" || !hasDeepHelp || profile.matchTendency > .62 || profile.overCarry < profile.mistakeRate)
        && (primary.y < readLandmark.y + radii.y * .28 || (primaryOutsideZone && primary.vision?.clear));
      const shouldWallCrosser = (isHook || technique === "wallCrosser" || technique === "robInside")
        && primary.read.isCrosser;
      const meshThreats = inZoneThreats.filter(threat =>
        threat.conceptLabels?.includes("mesh-crosser")
      );
      const shouldMeshMidpoint = meshThreats.length > 1
        && isHook
        && !profile.assignmentMistake
        && technique !== "jumpFirst"
        && profile.overCarry >= profile.mistakeRate + .08;
      const passOffVertical = hasDeepHelp
        && technique !== "matchVertical"
        && primary.read.routeDepth > 120
        && primary.y < readLandmark.y - radii.y * .45;
      const overCarryMistake = shouldCarryVertical && hasDeepHelp && profile.overCarry < profile.mistakeRate + .16;
      if (shouldMeshMidpoint) {
        mode = "midpoint";
        const sortedMesh = [...meshThreats].sort((a, b) => a.x - b.x);
        const left = sortedMesh[0];
        const right = sortedMesh[sortedMesh.length - 1];
        const nearestDepth = sortedMesh.reduce((best, threat) =>
          Math.abs(threat.y - state.y) < Math.abs(best.y - state.y) ? threat : best, sortedMesh[0]);
        target = {
          x: (left.x + right.x) / 2,
          y: Math.min(readLandmark.y + radii.y * .22, nearestDepth.y - 4)
        };
      } else if (shouldConceptMidpoint) {
        mode = "midpoint";
        const high = primary.read.routeDepth >= (conceptPartner.read?.routeDepth || 0)
          ? primary
          : conceptPartner;
        const low = high.id === primary.id ? conceptPartner : primary;
        const midpointPull = isFlatDefender ? .42 : isCurlFlat ? .55 : .62;
        target = {
          x: low.x + ((high.x - low.x) * midpointPull),
          y: Math.min(readLandmark.y + radii.y * .16, low.y + ((high.y - low.y) * midpointPull))
        };
      } else if (shouldContestZoneThreat) {
        mode = "rally";
        const ballSideLeverage = primary.x < state.x ? 8 : -8;
        const routeCushion = primary.read.isComingBack || primary.settledInZone ? 2 : 6;
        target = {
          x: primary.x + ballSideLeverage,
          y: primary.y - routeCushion
        };
      } else if (shouldCarryVertical) {
        mode = "carry";
        target = {
          x: zone.x + ((primary.x - zone.x) * (overCarryMistake || technique === "matchVertical" ? .78 : hasDeepHelp ? .42 : .62)),
          y: passOffVertical
            ? Math.max(readLandmark.y - radii.y * .25, primary.y + 26)
            : hasDeepHelp && !overCarryMistake
            ? Math.max(readLandmark.y - radii.y * .45, primary.y + 18)
            : Math.min(deepThreatLine + 40, primary.y - 10)
        };
      } else if (shouldRallyFlat) {
        mode = "rally";
        const outsideLeverage = (primary.x < readLandmark.x ? 18 : -18) + ((profile.leverageNoise || 0) * .35);
        const settledClose = primary.settledInZone ? 5 : 0;
        target = {
          x: primary.x + outsideLeverage,
          y: primary.y - 6 + settledClose
        };
      } else if (shouldWallCrosser) {
        mode = "wall";
        target = {
          x: readLandmark.x + ((primary.x - readLandmark.x) * .58),
          y: Math.min(readLandmark.y + radii.y * .22, primary.y - 10)
        };
      } else if (splitZone) {
        mode = "midpoint";
        const sortedZoneThreats = [...inZoneThreats].sort((a, b) => a.x - b.x);
        const left = sortedZoneThreats[0];
        const right = sortedZoneThreats[sortedZoneThreats.length - 1];
        const deepest = sortedZoneThreats.reduce((best, threat) =>
          threat.y < best.y ? threat : best, sortedZoneThreats[0]);
        target = {
          x: (left.x + right.x) / 2,
          y: Math.min(readLandmark.y + radii.y * .18, deepest.y + 16)
        };
      } else if (singleZoneThreat) {
        mode = primary.read.isVertical ? "carry" : "rally";
        const cushion = primary.read.isVertical ? Math.max(18, profile.cushion * .65) : primary.settledInZone ? 3 : 8;
        target = {
          x: primary.x + ((profile.leverageNoise || 0) * .16),
          y: primary.read.isVertical
            ? Math.min(readLandmark.y, primary.y - cushion)
            : primary.y - 6
        };
      } else {
        mode = "spot";
        const lean = Math.max(.14, Math.min(.48, .22 + ((profile.aggressiveness || .5) * .18) + (profile.leanNoise || 0)));
        target = {
          x: readLandmark.x + (qbFlowLean?.x || 0) + ((primary.x - readLandmark.x) * lean * eyePullAmount),
          y: readLandmark.y + (qbFlowLean?.y || 0) + ((primary.y - readLandmark.y) * Math.min(.28, lean * eyePullAmount))
        };
      }
    }
    }
  } else if (!threats.length && state.primaryThreatId) {
    state.primaryThreatId = null;
  }
  const assignedThreat = state.primaryThreatId
    ? threats.find(threat => threat.id === state.primaryThreatId)
    : null;
  const pulledByVision = assignedThreat?.zoneDistance > 1.08
    && (assignedThreat?.vision?.clear || assignedThreat?.findWorkPull);
  if (!roofDefender && !carryingDeepThreat && mode !== "carry" && mode !== "rally" && !pulledByVision) target = clampToZone(target, zone);
  if (isDeepSafety && mode !== "recover" && mode !== "bite") {
    const roofCushion = roofDefender ? Math.max(profile.cushion + 18, 56) : profile.cushion;
    const roofControlThreat = isOutsideDeepThird && assignedThreat
      ? assignedThreat
      : roofThreat;
    if (roofDefender && roofControlThreat) {
      target.x = laneCapX(zone, target.x);
      target.y = Math.min(target.y, roofControlThreat.y - roofCushion);
    }
    target.y = Math.min(target.y, roofDefender ? target.y : deepThreatLine);
    if (mode === "midpoint") target.y = Math.min(target.y, state.start.y);
  } else if (mode !== "carry" && mode !== "rally" && mode !== "run-fit") {
    const pullPad = pulledByVision ? .34 + ((1 - (profile.discipline || .7)) * .34) : 0;
    target.x = Math.max(zone.x - radii.x * (.82 + pullPad), Math.min(zone.x + radii.x * (.82 + pullPad), target.x));
    target.y = Math.max(zone.y - radii.y * (.7 + pullPad), Math.min(zone.y + radii.y * (.7 + pullPad), target.y));
  }

  const gapX = target.x - state.x;
  const gapY = target.y - state.y;
  const separation = Math.hypot(gapX, gapY);
  const nextPosture = bodyPostureForMode(mode, gapX, gapY, isDeepSafety);
  let eyeTarget = readLandmark;
  let eyeTargetId = "";
  let eyeMode = mode;
  let eyeFacing = null;
  if (runFitBite || mode === "bite") {
    eyeMode = "backfield";
  } else if (state.primaryThreatId) {
    const primaryEye = receiverCandidates.find(receiver => receiver.id === state.primaryThreatId)
      || state.lastSeenThreats?.[state.primaryThreatId];
    if (primaryEye) {
      eyeTarget = primaryEye;
      eyeTargetId = state.primaryThreatId;
      eyeMode = mode === "spot" ? "lean" : mode;
    }
  } else if (!threats.length && elapsed > reactionTime) {
    const scanAmount = Math.sin(elapsed * (isDeepSafety ? .95 : 1.25) + (profile.scanNoise || 0)) * (isDeepSafety ? .22 : .2);
    eyeFacing = isDeepSafety
      ? deepRouteScanVector(state, receiverCandidates, readLandmark, elapsed, profile)
      : rotateVector(ballFacingVector(state), scanAmount);
    eyeMode = "scan";
  }
  if (isDeepSafety && (eyeMode === "midpoint" || eyeMode === "scan") && !influence.flatFoot && !influence.backfieldRead) {
    eyeFacing = deepRouteScanVector(state, receiverCandidates, readLandmark, elapsed, profile);
  }
  setDefenderEyeState(
    state,
    eyeFacing || postureEyeVector(state, nextPosture, eyeMode, eyeTarget, gapX, gapY, { isDeepSafety }),
    eyeTargetId,
    eyeMode
  );
  const settleDistance = mode === "spot" || mode === "midpoint" ? 4.5 : 2.2;
  if (separation < settleDistance && Math.hypot(state.vx, state.vy) < 18) {
    state.vx = 0;
    state.vy = 0;
    state.x += gapX * .18;
    state.y += gapY * .18;
    state.lastMode = "settled";
    return { x: state.x, y: state.y };
  }
  const speedBoost = .86 + ((profile.aggressiveness || .5) * .32);
  const bodyProfile = bodyMovementProfile(state.body, nextPosture, gapX, gapY, safeDelta);
  const traffic = trafficSlowdown(state, receivers);
  const earlyDeepDrop = isDeepSafety && nextPosture === "backpedal" && elapsed < 1.15;
  const earlyDropBoost = earlyDeepDrop ? (roofDefender ? 1.34 : 1.2) : 1;
  const movementMultiplier = mode === "carry" || mode === "recover"
    ? (roofDefender ? 1.12 : 1)
    : mode === "run-fit"
      ? .86
      : isDeepSafety && (mode === "midpoint" || nextPosture === "backpedal")
        ? (roofDefender ? 1.08 : .92)
      : gapY < -8
        ? .68
        : Math.abs(gapX) > Math.abs(gapY) * 1.2
          ? .72
          : .62;
  const maxSpeed = (
    mode === "carry" ? 134
      : mode === "recover" ? 150
      : mode === "run-fit" ? 108
      : mode === "rally" ? 120
        : mode === "wall" ? 104
          : isDeepSafety ? (roofDefender ? 124 : 98)
            : isFlatDefender ? 92
              : 86
  ) * speedBoost * movementMultiplier * earlyDropBoost * bodyProfile.speed * traffic;
  const phaseBrake = phaseChangeBrake(state, mode, safeDelta);
  const controlledSpeed = approachSpeedLimit(
    maxSpeed,
    separation,
    mode === "carry" || mode === "recover" ? 26 : 34
  );
  const desiredVx = separation ? (gapX / separation) * controlledSpeed : 0;
  const desiredVy = separation ? (gapY / separation) * controlledSpeed : 0;
  const acceleration = (
    mode === "carry" ? 650
      : mode === "recover" ? 780
      : mode === "run-fit" ? 520
      : mode === "rally" ? 540
        : mode === "wall" ? 500
          : isDeepSafety ? (roofDefender ? 560 : 440)
            : 420
  ) * speedBoost * movementMultiplier * earlyDropBoost * bodyProfile.accel * traffic;
  const velocityChange = Math.hypot(desiredVx - state.vx, desiredVy - state.vy);
  const maxVelocityChange = acceleration * phaseBrake * safeDelta;
  const velocityRatio = velocityChange
    ? Math.min(1, maxVelocityChange / velocityChange)
    : 0;

  state.vx += (desiredVx - state.vx) * velocityRatio;
  state.vy += (desiredVy - state.vy) * velocityRatio;
  const proposedDx = state.vx * safeDelta;
  const proposedDy = state.vy * safeDelta;
  const proposedDistance = Math.hypot(proposedDx, proposedDy);
  const maxFrameDistance = maxSpeed * safeDelta;
  const frameRatio = proposedDistance
    ? Math.min(1, maxFrameDistance / proposedDistance)
    : 0;
  state.x += proposedDx * frameRatio;
  state.y += proposedDy * frameRatio;
  state.x = Math.max(fieldPadding, Math.min(fieldWidth - fieldPadding, state.x));
  state.y = Math.max(fieldPadding, Math.min(fieldHeight - fieldPadding, state.y));
  const finalRoofThreat = isOutsideDeepThird && state.primaryThreatId
    ? receiverCandidates.find(receiver => receiver.id === state.primaryThreatId) || roofThreat
    : roofThreat;
  if (roofDefender && finalRoofThreat && mode !== "bite" && mode !== "recover") {
    const roofCushion = Math.max(profile.cushion + 18, 56);
    const maxRoofY = finalRoofThreat.y - roofCushion;
    state.x = laneCapX(zone, state.x);
    if (state.y > maxRoofY) {
      state.y = maxRoofY;
      state.vy = Math.min(0, state.vy);
    }
  } else if (isDeepSafety && mode !== "bite" && state.y > deepThreatLine) {
    state.y = deepThreatLine;
    state.vy = Math.min(0, state.vy);
  }
  state.lastMode = mode;
  return { x: state.x, y: state.y };
}

function stopAnimationPlayback() {
  if (animationFrame) cancelAnimationFrame(animationFrame);
  animationFrame = null;
  animationState = null;
  animationPlayback = null;
  updatePlaybackUi();
}

function resetAnimation() {
  stopAnimationPlayback();
  render();
}

document.querySelector("#resetPlayButton").addEventListener("click", resetAnimation);

document.querySelector("#addNoteButton").addEventListener("click", () => {
  if (appTab !== "create") return;
  currentNoteOwner().notes ||= [];
  currentNoteOwner().notes.push(createNote());
  saveAllLibraries();
  renderNotes();
  els.notes.querySelector(".field-note-box:last-child textarea")?.focus();
});

function previewMovement(scope) {
  stopAnimationPlayback();
  animationState = { offense: {}, defense: {} };
  const startedAt = performance.now();
  const defensiveRepId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const baseSpeed = 115;
  const playbackScale = scope === "run" || scope === "test" ? runSpeed : 1;
  const animateOffense = scope === "run" || scope === "test" || scope === "play";
  const animateDefense = scope === "defense"
    || (scope === "run" && runDefenseMovement)
    || scope === "test";
  const offenseEntries = scope === "play"
    ? routeableOffense.map(position => [position.id, editorOffensePositions()[position.id]])
    : Object.entries(editorOffensePositions());
  const offensePaths = animateOffense
    ? offenseEntries.map(([id, start]) => {
        const motion = currentMotion(id);
        const snapStart = motionEnd(start, motion);
        const drawnRoute = scope === "play"
          ? createPreviewRoute(id, start)
          : postSnapRoute(id, start);
        return {
          id,
          start,
          motion,
          snapStart,
          route: extendRouteToBoundary(snapStart, drawnRoute)
        };
      })
    : [];
  if (scope === "run" || scope === "test") {
    if (!runScenario) resetRunScenario();
    runScenario.playIntent = normalizePlayIntent(currentPlay().intent);
    runScenario.defenseRealism = normalizeDefenseRealism(currentDefense().realism);
  }
  const activePlayIntent = scope === "run" || scope === "test"
    ? normalizePlayIntent(runScenario?.playIntent || currentPlay().intent)
    : normalizePlayIntent(currentPlay().intent);
  const activeDefenseRealism = scope === "run" || scope === "test"
    ? normalizeDefenseRealism(runScenario?.defenseRealism || currentDefense().realism)
    : normalizeDefenseRealism(currentDefense().realism);
  const defensePaths = animateDefense
    ? Object.entries(defenderStarts).map(([id, start]) => {
        const route = scope === "run" || scope === "test"
          ? runScenarioRoute("defense", id)
          : (currentDefense().routes[id] || []);
        const manTarget = currentManAssignments()[id];
        const manTargetStart = editorOffensePositions()[manTarget] || start;
        const zoneAssignment = currentZoneAssignments()[id];
        const technique = normalizeDefenderTechnique(currentDefenderTechniques()[id]);
        const assignmentStyle = zoneAssignment
          ? zoneStyle(zoneAssignment, { start })
          : null;
        const repDelay = scope === "run" || scope === "test"
          ? assignmentStyle?.isDeepSafety ? 0 : Math.random() * .28
          : 0;
        const repTempo = scope === "run" || scope === "test"
          ? .82 + (Math.random() * .34)
          : 1;
        const animatedRoute = route.map((point, index) => ({
          ...point,
          x: point.x + ((Math.random() - .5) * Math.min(10, 3 + index * 1.5)),
          y: point.y + ((Math.random() - .5) * Math.min(8, 2 + index * 1.2))
        }));
        const pathSnapStart = defensivePreSnapPathTarget(start, animatedRoute) || start;
        const routeDuration = pathDuration(pathSnapStart, animatedRoute, baseSpeed * repTempo);
        const zoneStart = animatedRoute.length
          ? { ...animatedRoute[animatedRoute.length - 1] }
          : { ...start };
        return {
          id,
          start,
          pathSnapStart,
          pathLiveStart: null,
          route: animatedRoute,
          routeDuration,
          repDelay,
          repTempo,
          passRushDelay: 4 + (Math.random() * 2),
          manTarget,
          zoneAssignment,
          assignmentStyle,
          manState: {
            x: start.x,
            y: start.y,
            vx: 0,
            vy: 0,
            postSnapStarted: false,
            start: { ...start },
            receiverStart: { ...manTargetStart },
            initialCushion: Math.max(18, manTargetStart.y - start.y),
            horizontalLeverage: start.x - manTargetStart.x,
            phase: "mirror",
            deepThreatened: false,
            breakConfirmed: false,
            breakEvidence: 0,
            verticalRecoveryTime: 0,
            lastReceiver: {
              ...manTargetStart
            },
            lastDirection: { x: 0, y: -1 },
            leverage: Math.sign(start.x - (editorOffensePositions()[currentManAssignments()[id]]?.x ?? start.x)) || 1,
            technique,
            body: initializeBodyState("shuffle"),
            profile: createDefenderAiProfile(
              start,
              zoneAssignment,
              manTarget,
              activeDefenseRealism,
              `${defensiveRepId}-${id}-man`
            )
          },
          zoneState: {
            x: zoneStart.x,
            y: zoneStart.y,
            vx: 0,
            vy: 0,
            postSnapStarted: false,
            start: zoneStart,
            technique,
            body: initializeBodyState(assignmentStyle?.isDeepSafety ? "backpedal" : "shuffle"),
            profile: createDefenderAiProfile(
              zoneStart,
              zoneAssignment,
              manTarget,
              activeDefenseRealism,
              `${defensiveRepId}-${id}`
            ),
            primaryThreatId: null,
            deepThreatId: null,
            commitUntil: 0
          }
        };
      })
    : [];
  offensePaths.forEach(({ id, start }) => {
    animationState.offense[id] = { ...start };
  });
  defensePaths.forEach(({ id, start }) => {
    animationState.defense[id] = { ...start };
  });
  const maxOffenseMotionDuration = Math.max(
    0,
    ...offensePaths.map(path => pathDuration(path.start, path.motion, baseSpeed))
  );
  const motionPressures = preSnapMotionPressures(offensePaths);
  const defensivePreSnapDuration = animateDefense && defensePaths.some(path => path.route.length)
    ? .85
    : 0;
  const maxMotionDuration = Math.max(maxOffenseMotionDuration, defensivePreSnapDuration);
  const maxPostSnapDuration = Math.max(
    0,
    ...offensePaths.map(path => pathDuration(path.snapStart, path.route, baseSpeed)),
    ...defensePaths.map(path =>
      path.repDelay + path.routeDuration + (path.zoneAssignment && !path.manTarget ? 5 : 0)
    )
  );
  const totalDuration = maxMotionDuration + maxPostSnapDuration;
  const testSackDeadline = scope === "test"
    ? maxMotionDuration + Math.max(
        0,
        ...defensePaths
          .filter(path => isDefensiveLinePlayer(path.id))
          .map(path => path.passRushDelay || 0)
      )
    : 0;
  animationPlayback = {
    scope,
    paused: false,
    snapReleased: scope !== "test",
    snapHold: false,
    snapHoldStartedAt: 0,
    snapPointSeconds: maxMotionDuration,
    pauseStartedAt: 0,
    pausedDuration: 0,
    startedAt,
    lastFrameAt: startedAt,
    defenderEyes: {},
    receiverHistory: Object.fromEntries(
      skillPositions.map(position => [
        position.id,
        { ...(animationState.offense[position.id] || editorOffensePositions()[position.id]) }
      ])
    ),
    animate: null
  };
  updatePlaybackUi();

  function animate(now) {
    if (!animationPlayback || animationPlayback.paused || animationPlayback.snapHold) return;
    const rawElapsed = (
      (now - animationPlayback.startedAt - animationPlayback.pausedDuration) / 1000
    ) * playbackScale;
    const shouldHoldForSnap = !animationPlayback.snapReleased
      && rawElapsed >= animationPlayback.snapPointSeconds;
    const elapsed = shouldHoldForSnap
      ? animationPlayback.snapPointSeconds
      : rawElapsed;
    const deltaSeconds = Math.min(
      .05,
      ((now - animationPlayback.lastFrameAt) / 1000) * playbackScale
    );
    animationPlayback.lastFrameAt = now;
    if (animateOffense) {
      offensePaths.forEach(({ id, start, motion, snapStart, route }) => {
        animationState.offense[id] = elapsed < maxMotionDuration
          ? interpolateTimedPath(start, motion, elapsed, baseSpeed)
          : interpolateTimedPath(snapStart, route, elapsed - maxMotionDuration, baseSpeed);
      });
    }
    if (scope === "test" && completedTestCatchActive()) {
      advanceTestCatchRun(deltaSeconds);
    }
    const receiverSnapshots = skillPositions.map(position => {
      const current = animationState.offense[position.id]
        || editorOffensePositions()[position.id];
      const previous = animationPlayback.receiverHistory[position.id] || current;
      return {
        id: position.id,
        ...current,
        vx: safeVelocity(current.x - previous.x, deltaSeconds),
        vy: safeVelocity(current.y - previous.y, deltaSeconds),
        zoneDistancePrevious: 0
      };
    });
    const coverageClaims = new Map();
    const qbFlowPoint = qbFlowPointFromPlayback(activePlayIntent);
    const framePlayIntent = scope === "test"
      ? { ...activePlayIntent, qbLookPoint: currentTestQbLookPoint(), qbFlowPoint, testMode: true }
      : { ...activePlayIntent, qbFlowPoint };
    if (animateDefense) {
      defensePaths.forEach(({
        id,
        start,
        pathSnapStart,
        route,
        routeDuration,
        repDelay,
        repTempo,
        passRushDelay,
        manTarget,
        zoneAssignment,
        assignmentStyle,
        manState,
        zoneState
      }) => {
        const postSnapElapsed = elapsed - maxMotionDuration;
        const defenderElapsed = postSnapElapsed - repDelay;
        const defenderDelta = deltaSeconds * repTempo;
        const defensivePathPoint = route.length && maxMotionDuration > 0
          ? interpolateDefensivePreSnap(start, route, elapsed, maxMotionDuration)
          : { ...start };
        const motionAdjustment = maxMotionDuration > 0
          ? defensiveMotionAdjustment(start, motionPressures, elapsed, maxMotionDuration, assignmentStyle || {})
          : { x: 0, y: 0 };
        const preSnapPoint = {
          x: defensivePathPoint.x + motionAdjustment.x,
          y: defensivePathPoint.y + motionAdjustment.y
        };
        if (scope === "test" && testPlayDead()) {
          return;
        }
        if (scope === "test" && testThrowState && !testThrowState.resolved) {
          const landingPoint = currentTestThrowLandingPoint();
          const qbPoint = animationState.offense.QB || offensePosition("QB");
          const current = animationState.defense[id] || start;
          if (shouldDefenderBreakOnThrow(id, current, landingPoint, qbPoint)) {
            const broken = breakDefenderOnThrow(id, current, landingPoint, defenderDelta, repTempo);
            animationState.defense[id] = broken;
            animationPlayback.defenderEyes[id] = {
              facing: vectorToward(broken, landingPoint),
              mode: "break",
              targetId: testThrowState.receiverId || ""
            };
            return;
          }
        }
        if (scope === "test" && completedTestCatchActive()) {
          const ballPoint = testThrowState.catchRun.current;
          const current = animationState.defense[id] || start;
          const rallied = rallyDefenderToBall(id, current, ballPoint, defenderDelta, repTempo);
          animationState.defense[id] = rallied;
          animationPlayback.defenderEyes[id] = {
            facing: vectorToward(rallied, ballPoint),
            mode: "rally",
            targetId: testThrowState.receiverId || ""
          };
          return;
        }
        if (scope === "test"
          && isDefensiveLinePlayer(id)
          && postSnapElapsed >= 0
          && !testThrowState
          && !testPlayDead()) {
          const qbPoint = animationState.offense.QB || offensePosition("QB");
          const current = animationState.defense[id] || start;
          const sackNow = postSnapElapsed >= passRushDelay;
          const rushed = rushDefenderToQb(id, current, qbPoint, defenderDelta, !sackNow);
          animationState.defense[id] = sackNow ? {
            x: qbPoint.x + ((start.x < qbPoint.x ? -1 : 1) * 14),
            y: qbPoint.y - 4
          } : rushed;
          animationPlayback.defenderEyes[id] = {
            facing: vectorToward(animationState.defense[id], qbPoint),
            mode: sackNow ? "sack" : "rush",
            targetId: "QB"
          };
          if (sackNow) resolveTestQbSack(id);
          return;
        }
        if (!manTarget && postSnapElapsed < 0) {
          animationState.defense[id] = { ...preSnapPoint };
          animationPlayback.defenderEyes[id] = {
            facing: route.length
              ? vectorToward(preSnapPoint, route[0])
              : ballFacingVector(preSnapPoint),
            mode: route.length ? "pre-snap-movement" : "landmark",
            targetId: ""
          };
          return;
        }
        if (manTarget) {
          const targetStart = editorOffensePositions()[manTarget];
          const targetPosition = { id: manTarget, ...(animationState.offense[manTarget] || targetStart) };
          if (postSnapElapsed < 0) {
            const current = animationState.defense[id] || start;
            const motionTarget = {
              x: preSnapPoint.x + (targetPosition.x - targetStart.x),
              y: preSnapPoint.y
            };
            animationState.defense[id] = smoothPointToward(current, motionTarget, 14 + (defenderDelta * 120));
            animationPlayback.defenderEyes[id] = {
              facing: vectorToward(animationState.defense[id], targetPosition),
              mode: "motion-man",
              targetId: manTarget
            };
            return;
          }
          if (defenderElapsed < 0) {
            const current = animationState.defense[id] || start;
            const motionTarget = {
              x: preSnapPoint.x + (targetPosition.x - targetStart.x),
              y: preSnapPoint.y
            };
            animationState.defense[id] = smoothPointToward(current, motionTarget, 14 + (defenderDelta * 120));
            animationPlayback.defenderEyes[id] = {
              facing: vectorToward(animationState.defense[id], targetPosition),
              mode: "motion-man",
              targetId: manTarget
            };
            return;
          }
          if (!manState.postSnapStarted) {
            const liveStart = animationState.defense[id] || {
              x: preSnapPoint.x + (targetPosition.x - targetStart.x),
              y: preSnapPoint.y
            };
            manState.x = liveStart.x;
            manState.y = liveStart.y;
            manState.vx = 0;
            manState.vy = 0;
            manState.start = { x: manState.x, y: manState.y };
            manState.receiverStart = { ...targetPosition };
            manState.initialCushion = Math.max(18, Math.min(72, targetPosition.y - manState.y));
            manState.horizontalLeverage = manState.x - targetPosition.x;
            manState.phase = "mirror";
            manState.deepThreatened = false;
            manState.breakConfirmed = false;
            manState.breakEvidence = 0;
            manState.verticalRecoveryTime = 0;
            manState.lastReceiver = { ...targetPosition };
            manState.lastDirection = { x: 0, y: -1 };
            manState.postSnapStarted = true;
          }
          animationState.defense[id] = moveManDefender(
            manState,
            targetPosition,
            defenderElapsed,
            defenderDelta
          );
          animationPlayback.defenderEyes[id] = {
            facing: manState.facing,
            mode: manState.eyeMode || "man",
            targetId: manTarget
          };
        } else if (zoneAssignment && postSnapElapsed >= 0) {
          if (defenderElapsed < 0) {
            animationState.defense[id] = { ...preSnapPoint };
            animationPlayback.defenderEyes[id] = {
              facing: route.length
                ? vectorToward(preSnapPoint, route[0])
                : ballFacingVector(preSnapPoint),
              mode: route.length ? "pre-snap-movement" : "landmark",
              targetId: ""
            };
            return;
          }
          if (route.length && defenderElapsed < routeDuration) {
            zoneState.pathLiveStart ||= animationState.defense[id] || pathSnapStart;
            const livePathStart = zoneState.pathLiveStart;
            animationState.defense[id] = interpolateTimedPath(
              livePathStart,
              route,
              defenderElapsed,
              baseSpeed * repTempo
            );
            animationPlayback.defenderEyes[id] = {
              facing: routeMovementEyeVector(
                animationState.defense[id],
                livePathStart,
                route,
                defenderElapsed,
                baseSpeed * repTempo
              ),
              mode: "movement-landmark",
              targetId: ""
            };
            return;
          }
          zoneState.pathLiveStart = null;
          const receivers = receiverSnapshots.map(receiver => ({
            ...receiver,
            zoneDistancePrevious: zoneDistance(
              animationPlayback.receiverHistory[receiver.id] || receiver,
              zoneAssignment
            )
          }));
          const hasDeepHelp = defensePaths.some(other =>
            other.id !== id
            && other.zoneAssignment
            && other.zoneState.start.y < zoneState.start.y - 40
            && Math.abs(other.zoneAssignment.x - zoneAssignment.x)
              <= (zoneRadii(other.zoneAssignment).x + zoneRadii(zoneAssignment).x)
          );
          if (!zoneState.postSnapStarted) {
            const liveStart = animationState.defense[id] || zoneState.start || start;
            zoneState.x = liveStart.x;
            zoneState.y = liveStart.y;
            zoneState.vx = 0;
            zoneState.vy = 0;
            zoneState.start = { ...liveStart };
            zoneState.body = initializeBodyState(assignmentStyle?.isDeepSafety ? "backpedal" : "shuffle");
            zoneState.profile = createDefenderAiProfile(
              liveStart,
              zoneAssignment,
              manTarget,
              activeDefenseRealism,
              `${defensiveRepId}-${id}-zone-live`
            );
            zoneState.primaryThreatId = null;
            zoneState.deepThreatId = null;
            zoneState.commitUntil = 0;
            zoneState.postSnapStarted = true;
          }
          animationState.defense[id] = moveZoneDefender(
            zoneState,
            zoneAssignment,
            receivers,
            Math.max(0, defenderElapsed - routeDuration),
            defenderDelta,
            hasDeepHelp,
            coverageClaims,
            framePlayIntent
          );
          animationPlayback.defenderEyes[id] = {
            facing: zoneState.facing,
            mode: zoneState.eyeMode || "zone",
            targetId: zoneState.eyeTargetId || ""
          };
        } else if (postSnapElapsed >= 0) {
          if (defenderElapsed < 0) {
            animationState.defense[id] = { ...preSnapPoint };
            return;
          }
          zoneState.pathLiveStart ||= animationState.defense[id] || pathSnapStart;
          animationState.defense[id] = interpolateTimedPath(
            zoneState.pathLiveStart,
            route,
            defenderElapsed,
            baseSpeed * repTempo
          );
        }
      });
    }
    if (scope === "test" && completedTestCatchActive()) {
      resolveTestCatchTackle();
    }
    receiverSnapshots.forEach(receiver => {
      animationPlayback.receiverHistory[receiver.id] = {
        x: receiver.x,
        y: receiver.y
      };
    });
    renderRoutesAndPlayers();
    renderDefense();
    if (shouldHoldForSnap) {
      animationPlayback.snapHold = true;
      animationPlayback.snapHoldStartedAt = now;
      animationPlayback.lastFrameAt = now;
      animationFrame = null;
      updatePlaybackUi();
      return;
    }
    const keepAnimatingTestCatch = scope === "test" && completedTestCatchActive();
    const keepAnimatingTestThrow = scope === "test" && testThrowState && !testThrowState.resolved;
    if (!testPlayDead() && (elapsed < Math.max(totalDuration, testSackDeadline) || keepAnimatingTestCatch || keepAnimatingTestThrow)) {
      animationFrame = requestAnimationFrame(animate);
    } else {
      animationFrame = null;
      animationPlayback = null;
      updatePlaybackUi();
    }
  }

  animationPlayback.animate = animate;
  animationFrame = requestAnimationFrame(animate);
}

function updatePlaybackUi() {
  const paused = Boolean(animationPlayback?.paused);
  const snapHold = Boolean(animationPlayback?.snapHold);
  els.fieldCard?.classList.toggle("playback-paused", paused);
  const runButton = document.querySelector("#runPlayButton");
  if (runButton) runButton.textContent = paused ? "Resume" : "Play";
  const testButton = document.querySelector("#runTestButton");
  if (testButton) testButton.textContent = paused
    ? "Resume Test"
    : snapHold ? "Snap" : animationPlayback?.scope === "test" ? "Setting..." : "Set";
}

function releasePlaybackSnap() {
  if (!animationPlayback?.snapHold || !animationPlayback.animate) return false;
  const now = performance.now();
  animationPlayback.pausedDuration += now - animationPlayback.snapHoldStartedAt;
  animationPlayback.snapReleased = true;
  animationPlayback.snapHold = false;
  animationPlayback.snapHoldStartedAt = 0;
  animationPlayback.lastFrameAt = now;
  animationFrame = requestAnimationFrame(animationPlayback.animate);
  updatePlaybackUi();
  return true;
}

function toggleRunPlayback() {
  if (!isRunLikeMode() || !animationPlayback) return false;
  if (animationPlayback.snapHold) return appTab === "test" ? releasePlaybackSnap() : false;
  if (animationPlayback.paused) {
    const resumedAt = performance.now();
    animationPlayback.pausedDuration += resumedAt - animationPlayback.pauseStartedAt;
    animationPlayback.lastFrameAt = resumedAt;
    animationPlayback.paused = false;
    animationFrame = requestAnimationFrame(animationPlayback.animate);
  } else {
    animationPlayback.paused = true;
    animationPlayback.pauseStartedAt = performance.now();
    if (animationFrame) cancelAnimationFrame(animationFrame);
    animationFrame = null;
  }
  updatePlaybackUi();
  return true;
}

els.field.addEventListener("click", event => {
  if (!animationPlayback || appTab !== "run") return;
  event.preventDefault();
  event.stopImmediatePropagation();
  toggleRunPlayback();
}, true);

document.querySelector("#runPlayButton").addEventListener("click", () => {
  if (animationPlayback?.paused) {
    toggleRunPlayback();
    return;
  }
  previewMovement("run");
});

els.testSourceSelect.addEventListener("change", event => {
  testSourceId = event.target.value;
  resetTestSession();
  render();
});

els.testPlayOptions.addEventListener("change", event => {
  const playId = event.target.dataset.testPlay;
  const formationId = event.target.dataset.testFormation;
  if (playId) {
    if (event.target.checked) {
      testPlayIds.add(playId);
    } else {
      testPlayIds.delete(playId);
    }
  } else if (formationId) {
    plays
      .filter(play => play.formationId === formationId)
      .forEach(play => {
        if (event.target.checked) {
          testPlayIds.add(play.id);
        } else {
          testPlayIds.delete(play.id);
        }
      });
  } else {
    return;
  }
  resetTestSession();
  refreshTestPlaySelectionUi();
  els.testStatus.textContent = "Play selection updated. Start the test.";
});

document.querySelector("#selectAllTestPlays").addEventListener("click", () => {
  testPlayIds = new Set(plays.map(play => play.id));
  resetTestSession();
  refreshTestPlaySelectionUi();
  els.testStatus.textContent = "All plays selected. Start the test.";
});

document.querySelector("#clearTestPlays").addEventListener("click", () => {
  testPlayIds.clear();
  resetTestSession();
  refreshTestPlaySelectionUi();
  els.testStatus.textContent = "No plays selected.";
});

els.testSpeedSelect.addEventListener("change", event => {
  runSpeed = Number(event.target.value) || 1;
  resetAnimation();
});

els.testDefenseOptions.addEventListener("change", event => {
  if (!event.target.matches('input[type="checkbox"]')) return;
  if (event.target.checked) {
    testDefenseIds.add(event.target.value);
  } else {
    testDefenseIds.delete(event.target.value);
  }
  resetTestSession();
  renderTestControls();
});

document.querySelector("#selectAllTestDefenses").addEventListener("click", () => {
  testDefenseIds = new Set(defenses.map(defense => defense.id));
  resetTestSession();
  renderTestControls();
});

document.querySelector("#clearTestDefenses").addEventListener("click", () => {
  testDefenseIds.clear();
  resetTestSession();
  renderTestControls();
});

document.querySelector("#newTestRoundButton").addEventListener("click", loadNextTestPlay);

function snapTestBall() {
  if (!testRoundReady) return;
  if (releasePlaybackSnap()) return;
  if (animationPlayback?.paused) {
    toggleRunPlayback();
    return;
  }
  stopAnimationPlayback();
  resetTestInteraction();
  testAnswerRevealed = false;
  render();
  previewMovement("test");
}

document.querySelector("#runTestButton").addEventListener("click", snapTestBall);

document.addEventListener("keydown", event => {
  const target = event.target;
  if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
  if (appTab === "playbook" && (event.code === "ArrowLeft" || event.code === "ArrowRight")) {
    const moved = stepLibraryPreview(event.code === "ArrowLeft" ? "previous" : "next");
    if (!moved) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  if (event.code !== "Space" || !["run", "test"].includes(appTab)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if (appTab === "test") {
    if (!testRoundReady) return;
    snapTestBall();
  } else {
    if (animationPlayback?.paused) {
      toggleRunPlayback();
      return;
    }
    previewMovement("run");
  }
}, true);

document.querySelector("#resetTestButton").addEventListener("click", () => {
  if (!testRoundReady) return;
  resetTestInteraction();
  resetAnimation();
});

document.querySelector("#revealTestButton").addEventListener("click", () => {
  if (!testRoundReady) return;
  stopAnimationPlayback();
  resetTestInteraction();
  testAnswerRevealed = !testAnswerRevealed;
  render();
});

document.querySelector("#previewMovementButton").addEventListener("click", () => {
  if (appTab !== "create" || createScreen === "formation") return;
  previewMovement(createScreen);
});

function finishPlayerDrag() {
  if (!dragState) return;
  els.field.classList.remove("scrimmage-snapping");
  if (dragState.side === "path-point"
    || dragState.side === "zone-resize"
    || dragState.side === "zone-move") {
    suppressFieldClickUntil = Date.now() + 300;
    if (dragState.side === "path-point" && !dragState.moved) dragState.onTap?.();
  }
  if (els.field.hasPointerCapture(dragState.pointerId)) {
    els.field.releasePointerCapture(dragState.pointerId);
  }
  dragState = null;
  if (appTab === "create") saveAllLibraries();
  render();
}

els.field.addEventListener("pointerup", finishPlayerDrag);
els.field.addEventListener("pointercancel", finishPlayerDrag);
els.field.addEventListener("pointerleave", event => {
  els.routes.querySelector(".drawing-guide")?.remove();
  if (event.buttons === 0) finishPlayerDrag();
});

document.querySelector("#undoPointButton").addEventListener("click", () => {
  if (activeRouteSide === "defense" && createScreen === "defense" && defenseAssignmentMode === "man") {
    delete currentDefense().manAssignments[activeRouteId];
    saveDefenses();
    render();
    return;
  }
  const selectedRoute = activeRouteSide === "offense"
    ? (createScreen === "play" && playPathType === "motion"
        ? currentMotion(activeRouteId)
        : editablePlayRoute(activeRouteId))
    : currentDefense().routes[activeRouteId];
  if (!Array.isArray(selectedRoute) || !selectedRoute.length) return;
  selectedRoute.splice(selectedRoute.length - 1, 1);
  saveAllLibraries();
  render();
});

document.querySelectorAll(".board-mode-button").forEach(button => {
  button.addEventListener("click", () => {
    boardMode = button.dataset.boardMode;
    if (boardMode === "draw" && activeRouteSide === "offense"
      && !isRouteableOffense(activeRouteId)) {
      activeRouteId = "X";
    }
    dragState = null;
    document.querySelectorAll(".board-mode-button").forEach(modeButton => {
      modeButton.classList.toggle("active", modeButton === button);
    });
    render();
  });
});

document.querySelector("#clearRouteButton").addEventListener("click", () => {
  if (activeRouteSide === "offense") {
    if (createScreen === "play" && playPathType === "motion") {
      currentPlay().motions[activeRouteId] = [];
    } else {
      const route = editablePlayRoute(activeRouteId);
      route.splice(0, route.length);
    }
  } else {
    if (createScreen === "defense" && defenseAssignmentMode === "man") {
      delete currentDefense().manAssignments[activeRouteId];
    } else if (createScreen === "defense" && defenseAssignmentMode === "zone") {
      delete currentDefense().zoneAssignments[activeRouteId];
    } else {
      currentDefense().routes[activeRouteId] = [];
    }
  }
  saveAllLibraries();
  render();
});

document.querySelector("#drawRouteButton").addEventListener("click", () => {
  playPathType = "route";
  render();
});

document.querySelector("#drawMotionButton").addEventListener("click", () => {
  if (activeRouteId === "QB") return;
  playPathType = "motion";
  render();
});

document.querySelector("#addRouteOptionButton").addEventListener("click", () => {
  if (createScreen !== "play" || activeRouteSide !== "offense"
    || !isSkillPosition(activeRouteId)) return;
  const options = routeOptionsFor(currentPlay(), activeRouteId);
  const option = {
    id: crypto.randomUUID(),
    name: `Option ${options.length + 1}`,
    defenseIds: [],
    anchor: null,
    points: []
  };
  options.push(option);
  selectedRouteOptionId = option.id;
  playPathType = "route";
  renderPlayControls();
  render();
  els.routeOptionName.focus();
  els.routeOptionName.select();
});

els.routeOptionSelect.addEventListener("change", event => {
  selectedRouteOptionId = event.target.value;
  playPathType = "route";
  renderPlayControls();
  render();
});

els.routeOptionName.addEventListener("input", event => {
  const option = selectedRouteOption();
  if (!option) return;
  option.name = event.target.value.trimStart() || "Untitled Option";
  const selectedEntry = [...els.routeOptionSelect.options]
    .find(entry => entry.value === option.id);
  if (selectedEntry) selectedEntry.textContent = option.name;
  els.activeRouteLabel.textContent = activeRouteDisplayLabel();
});

els.routeOptionDefense.addEventListener("change", event => {
  const option = selectedRouteOption();
  if (!option) return;
  const selectedDefenseIds = [...els.routeOptionDefense.querySelectorAll("input:checked")]
    .map(input => input.value);
  const usedByOtherOptions = new Set(
    routeOptionsFor(currentPlay(), activeRouteId)
      .filter(candidate => candidate.id !== option.id)
      .flatMap(candidate => candidate.defenseIds)
  );
  const conflicts = selectedDefenseIds.filter(defenseId => usedByOtherOptions.has(defenseId));
  if (conflicts.length) {
    const conflictNames = conflicts
      .map(defenseId => defenses.find(defense => defense.id === defenseId)?.name)
      .filter(Boolean)
      .join(", ");
    window.alert(`${offenseLabel(activeRouteId)} already has another option assigned to ${conflictNames}.`);
    els.routeOptionDefense.querySelectorAll("input").forEach(input => {
      input.checked = option.defenseIds.includes(input.value);
    });
    return;
  }
  option.defenseIds = selectedDefenseIds;
});

document.querySelector("#deleteRouteOptionButton").addEventListener("click", () => {
  const option = selectedRouteOption();
  if (!option || !window.confirm(`Delete route option "${option.name}"?`)) return;
  currentPlay().routeOptions[activeRouteId] = routeOptionsFor(currentPlay(), activeRouteId)
    .filter(candidate => candidate.id !== option.id);
  selectedRouteOptionId = "base";
  renderPlayControls();
  render();
});

document.querySelector("#editScenarioButton").addEventListener("click", () => {
  if (!runScenario) resetRunScenario();
  scenarioEditing = !scenarioEditing;
  stopAnimationPlayback();
  render();
});

document.querySelector("#scenarioMoveButton").addEventListener("click", () => {
  scenarioTool = "move";
  render();
});

document.querySelector("#scenarioDrawButton").addEventListener("click", () => {
  scenarioTool = "draw";
  render();
});

document.querySelector("#scenarioZoneButton").addEventListener("click", () => {
  scenarioTool = "zone";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  render();
});

document.querySelector("#scenarioManButton").addEventListener("click", () => {
  scenarioTool = "man";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  render();
});

document.querySelector("#scenarioUndoButton").addEventListener("click", () => {
  if (scenarioTool === "zone" && activeRouteSide === "defense") {
    delete currentZoneAssignments()[activeRouteId];
    render();
    return;
  }
  if (scenarioTool === "man" && activeRouteSide === "defense") {
    delete currentManAssignments()[activeRouteId];
    render();
    return;
  }
  const route = runScenarioRoute(activeRouteSide, activeRouteId);
  if (route.length) route.pop();
  render();
});

document.querySelector("#scenarioClearButton").addEventListener("click", () => {
  if (activeRouteSide === "defense") {
    clearDefenderAssignment(activeRouteId);
  } else {
    const route = runScenarioRoute(activeRouteSide, activeRouteId);
    route.splice(0, route.length);
  }
  render();
});

document.querySelector("#defensePathModeButton").addEventListener("click", () => {
  defenseAssignmentMode = "path";
  boardMode = "draw";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  render();
});

document.querySelector("#defenseZoneModeButton").addEventListener("click", () => {
  defenseAssignmentMode = "zone";
  boardMode = "draw";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  render();
});

function updateSelectedZoneSize(value) {
  const zone = appTab === "run"
    ? currentZoneAssignments()[activeRouteId]
    : currentDefense().zoneAssignments?.[activeRouteId];
  if (!zone) return;
  const size = Math.max(40, Math.min(300, Number(value) || 130));
  const radii = zoneRadii(zone);
  const currentSize = Math.max(radii.x, radii.y);
  const scale = size / currentSize;
  zone.radiusX = Math.max(40, Math.min(300, radii.x * scale));
  zone.radiusY = Math.max(40, Math.min(300, radii.y * scale));
  delete zone.radius;
  els.zoneSizeRange.value = String(size);
  els.zoneSizeInput.value = String(size);
  if (appTab === "create") saveDefenses();
  renderDefense();
}

els.zoneSizeRange.addEventListener("input", event => {
  updateSelectedZoneSize(event.target.value);
});

els.zoneSizeInput.addEventListener("input", event => {
  if (event.target.value === "") return;
  updateSelectedZoneSize(event.target.value);
});

els.zoneSizeInput.addEventListener("change", event => {
  updateSelectedZoneSize(event.target.value);
});

function updateScenarioZoneSize(value) {
  if (appTab !== "run" || !scenarioEditing || scenarioTool !== "zone") return;
  updateSelectedZoneSize(value);
  const zone = currentZoneAssignments()[activeRouteId];
  if (!zone) return;
  const size = String(Math.round(Math.max(zoneRadii(zone).x, zoneRadii(zone).y)));
  els.scenarioZoneSizeRange.value = size;
  els.scenarioZoneSizeInput.value = size;
}

els.scenarioZoneSizeRange.addEventListener("input", event => {
  updateScenarioZoneSize(event.target.value);
});

els.scenarioZoneSizeInput.addEventListener("input", event => {
  if (event.target.value === "") return;
  updateScenarioZoneSize(event.target.value);
});

els.scenarioZoneSizeInput.addEventListener("change", event => {
  updateScenarioZoneSize(event.target.value);
});

document.querySelector("#defenseManModeButton").addEventListener("click", () => {
  defenseAssignmentMode = "man";
  boardMode = "draw";
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  render();
});

document.querySelector("#defenseNoMovementButton").addEventListener("click", () => {
  activeRouteSide = "defense";
  if (!String(activeRouteId).startsWith("D")) activeRouteId = "D0";
  clearDefenderAssignment(activeRouteId);
  saveDefenses();
  render();
});

document.querySelector("#scenarioResetButton").addEventListener("click", () => {
  resetRunScenario();
  render();
});

els.trenchesFrontSelect?.addEventListener("change", event => {
  cancelAnimationFrame(trenchesAnimationFrame);
  trenchesAnimationFrame = null;
  trenchesAnimation = null;
  trenchesState.frontId = event.target.value;
  if (trenchesState.selectedPlayId) trenchesState.selectedPlayId = null;
  const positions = trenchesPositions(trenchesState.frontId);
  if (trenchesState.selectedSide === "defense" && !positions.defense.some(player => player.id === trenchesState.selectedId)) {
    trenchesState.selectedSide = "offense";
    trenchesState.selectedId = "LT";
  }
  saveTrenchesState();
  renderTrenches();
});

els.trenchesFrontSelectMirror?.addEventListener("change", event => {
  els.trenchesFrontSelect.value = event.target.value;
  els.trenchesFrontSelect.dispatchEvent(new Event("change"));
});

els.trenchesFrontName?.addEventListener("input", () => {
  if (trenchesState.customFronts?.[trenchesState.frontId]) {
    saveCurrentTrenchesFront(els.trenchesFrontName.value);
  }
});

els.trenchesPlayName?.addEventListener("input", () => {
  trenchesState.playName = els.trenchesPlayName.value;
  saveTrenchesState();
});

els.trenchesPlaySelect?.addEventListener("change", event => {
  if (event.target.value) loadTrenchesPlay(event.target.value);
});

els.newTrenchesPlayButton?.addEventListener("click", () => {
  resetTrenchesRun();
  trenchesState.selectedPlayId = null;
  trenchesState.playName = "";
  trenchesState.assignments = defaultTrenchesAssignments();
  trenchesState.defensePaths = {};
  trenchesState.fronts = {};
  trenchesState.notes = [];
  trenchesState.selectedSide = "offense";
  trenchesState.selectedId = "LT";
  saveTrenchesState();
  renderTrenches();
  showSaveSuccess("New trench play ready");
});

els.saveTrenchesPlayButton?.addEventListener("click", () => {
  const play = saveTrenchesPlayFromState();
  renderTrenches();
  showSaveSuccess(`${play.name} saved`);
});

els.trenchesMoveButton?.addEventListener("click", () => setTrenchesMode("move"));
els.trenchesDrawButton?.addEventListener("click", () => setTrenchesMode("draw"));
document.querySelectorAll("[data-trenches-panel-tab]").forEach(button => {
  button.addEventListener("click", () => setTrenchesPanelTab(button.dataset.trenchesPanelTab));
});

els.trenchesSpeedSelect?.addEventListener("change", () => {
  trenchesState.playbackSpeed = Number(els.trenchesSpeedSelect.value) || 1;
  saveTrenchesState();
  renderTrenches();
});

els.addTrenchesNoteButton?.addEventListener("click", () => {
  trenchesState.notes ||= [];
  trenchesState.notes.push(createNote("", 350, 155));
  saveTrenchesState();
  renderTrenches();
  els.trenchesBoard.querySelector(".trenches-note:last-child textarea")?.focus();
});

els.newTrenchesFrontButton?.addEventListener("click", () => {
  resetTrenchesRun();
  const current = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
  const name = els.trenchesFrontName?.value?.trim() || `${current.name} Copy`;
  createCustomTrenchesFront(name);
  renderTrenches();
  showSaveSuccess("Front created");
});

els.saveTrenchesFrontButton?.addEventListener("click", () => {
  resetTrenchesRun();
  const current = trenchesFrontOptions()[trenchesState.frontId] || trenchesFronts.starter;
  const name = els.trenchesFrontName?.value?.trim() || current.name || "Custom Front";
  if (trenchesState.customFronts?.[trenchesState.frontId]) {
    saveCurrentTrenchesFront(name);
  } else {
    createCustomTrenchesFront(name);
  }
  renderTrenches();
  showSaveSuccess("Front saved");
});

els.deleteTrenchesFrontButton?.addEventListener("click", deleteCurrentTrenchesFront);

els.addTrenchesOffenseButton?.addEventListener("click", () => {
  resetTrenchesRun();
  const positions = trenchesPositions(trenchesState.frontId);
  const count = positions.offense.filter(player => String(player.id).startsWith("O")).length + 1;
  const newPlayer = {
    id: `O${crypto.randomUUID().slice(0, 8)}`,
    label: `O${count}`,
    x: 450,
    y: 360
  };
  positions.offense.push(newPlayer);
  setTrenchesPositions(trenchesState.frontId, positions);
  trenchesState.assignments[newPlayer.id] = { path: [], targetId: "", speed: 1 };
  updateTrenchesSelection(newPlayer.id, "offense");
  renderTrenches();
  showSaveSuccess("Offensive player added");
});

els.addTrenchesDefenderButton?.addEventListener("click", () => addTrenchesDefender({ saveTemplate: false }));
els.addTrenchesFrontDefenderButton?.addEventListener("click", () => addTrenchesDefender({ saveTemplate: true }));

els.resetTrenchesButton?.addEventListener("click", () => {
  resetTrenchesRun();
  trenchesState.assignments = defaultTrenchesAssignments();
  trenchesState.defensePaths = {};
  saveTrenchesState();
  renderTrenches();
  showSaveSuccess("Trenches paths cleared");
});
els.resetTrenchesAlignmentButton?.addEventListener("click", () => {
  resetTrenchesRun();
  trenchesState.fronts ||= {};
  delete trenchesState.fronts[trenchesState.frontId];
  saveTrenchesState();
  renderTrenches();
  showSaveSuccess("Trenches alignment reset");
});
els.runTrenchesButton?.addEventListener("click", runTrenchesPlay);
els.resetTrenchesPlayButton?.addEventListener("click", resetTrenchesRun);
els.undoTrenchesPointButton?.addEventListener("click", () => {
  selectedTrenchesMovement().path?.pop();
  saveTrenchesState();
  renderTrenches();
});
els.clearTrenchesPathButton?.addEventListener("click", () => {
  selectedTrenchesMovement().path = [];
  if (trenchesState.selectedSide === "offense") selectedTrenchesMovement().targetId = "";
  saveTrenchesState();
  renderTrenches();
});
els.clearTrenchesOffenseButton?.addEventListener("click", () => {
  Object.values(trenchesState.assignments).forEach(assignment => {
    assignment.path = [];
    assignment.targetId = "";
  });
  saveTrenchesState();
  renderTrenches();
});
els.undoTrenchesDefensePointButton?.addEventListener("click", () => {
  if (trenchesState.selectedSide !== "defense") return;
  selectedTrenchesMovement().path?.pop();
  saveTrenchesState();
  renderTrenches();
});
els.clearTrenchesDefensePathButton?.addEventListener("click", () => {
  if (trenchesState.selectedSide !== "defense") return;
  selectedTrenchesMovement().path = [];
  saveTrenchesState();
  renderTrenches();
});
els.clearTrenchesDefenseButton?.addEventListener("click", () => {
  trenchesState.defensePaths = {};
  saveTrenchesState();
  renderTrenches();
});
els.trenchesBoard?.addEventListener("click", event => {
  if (trenchesAnimationFrame || trenchesDrag) return;
  if (trenchesState.mode !== "draw") return;
  if (event.target.closest("[data-trenches-lineman], [data-trenches-defender], [data-trenches-point], [data-trenches-note]")) return;
  const point = trenchesPointFromEvent(event);
  const movement = selectedTrenchesMovement();
  movement.path ||= [];
  movement.path.push({ ...point, rounded: false });
  saveTrenchesState();
  renderTrenches();
});
els.trenchesBoard?.addEventListener("pointermove", updateTrenchesDrag);
els.trenchesBoard?.addEventListener("pointerup", finishTrenchesDrag);
els.trenchesBoard?.addEventListener("pointercancel", finishTrenchesDrag);

document.querySelectorAll("[data-app-tab]").forEach(button => {
  button.addEventListener("click", () => {
    stopAnimationPlayback();
    appTab = button.dataset.appTab;
    if (appTab !== "create") defenseAlignmentMode = false;
    if (appTab === "create" && createScreen === "play") {
      if (!draftPlay) {
        draftPlay = createBlankPlay("");
        draftPlay.formationId = selectedFormationId;
        draftPlay.offensePositions = structuredClone(normalizedOffensePositions(currentFormation().offensePositions));
        draftPlay.labels = structuredClone(currentFormation().labels);
        emptyPlayPaths(draftPlay);
      }
      playPathType = "route";
      selectedRouteOptionId = "base";
      activeRouteSide = "offense";
      activeRouteId = "X";
      boardMode = "draw";
    }
    if (appTab === "run") resetRunScenario();
    if (appTab === "test" && testRoundReady) resetRunScenario();
    if (appTab !== "run") scenarioEditing = false;
    syncTabButtons();
    render();
  });
});

document.querySelectorAll("[data-create-screen]").forEach(button => {
  button.addEventListener("click", () => {
    createScreen = button.dataset.createScreen;
    if (createScreen !== "defense") defenseAlignmentMode = false;
    animationState = null;
    activeRouteSide = createScreen === "defense" ? "defense" : "offense";
    activeRouteId = createScreen === "defense" ? "D0" : "X";
    boardMode = createScreen === "play" ? "draw" : "move";
    if (createScreen === "defense") defenseAssignmentMode = "path";
    if (createScreen === "play") {
      if (!draftPlay) {
        draftPlay = createBlankPlay("");
        draftPlay.formationId = selectedFormationId;
        draftPlay.offensePositions = structuredClone(normalizedOffensePositions(currentFormation().offensePositions));
        draftPlay.labels = structuredClone(currentFormation().labels);
        emptyPlayPaths(draftPlay);
      }
      playPathType = "route";
      selectedRouteOptionId = "base";
    }
    document.querySelectorAll("[data-create-screen]").forEach(tab => {
      tab.classList.toggle("active", tab === button);
    });
    renderPlayControls();
    render();
  });
});

["input", "change", "click"].forEach(eventName => {
  document.addEventListener(eventName, () => scheduleAutosave());
});

let persistentStorageRequested = false;
document.addEventListener("click", () => {
  if (persistentStorageRequested || !navigator.storage?.persist) return;
  persistentStorageRequested = true;
  navigator.storage.persist().catch(() => false);
}, { once: true });

window.addEventListener("beforeunload", () => {
  clearTimeout(autosaveTimer);
  persistPlaybook();
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") {
    clearTimeout(autosaveTimer);
    persistPlaybook();
  }
});

setInterval(() => persistPlaybook(), 15000);

async function initializeApp() {
  const hasLocalData = Boolean(
    readJsonStorage(storageKeys.plays)?.length
    || recoverySnapshot()?.plays?.length
  );
  if (!hasLocalData) {
    const indexedBackup = await readIndexedDbSnapshot();
    if (indexedBackup?.plays?.length
      && indexedBackup?.formations?.length
      && indexedBackup?.defenses?.length) {
      plays = indexedBackup.plays.map(normalizePlay);
      formations = indexedBackup.formations;
      defenses = indexedBackup.defenses.map(normalizeDefense);
      libraryFolders = normalizeLibraryFolders(indexedBackup.libraryFolders);
      libraryAssignments = normalizeLibraryAssignments(indexedBackup.libraryAssignments);
      draftPlay = indexedBackup.draftPlay
        ? normalizePlay(indexedBackup.draftPlay)
        : null;
      selectedPlayId = plays[0].id;
      selectedFormationId = draftPlay?.formationId
        || plays[0].formationId
        || formations[0].id;
      selectedDefenseId = defenses[0].id;
      createScreen = draftPlay ? "play" : "formation";
      if (fieldStandards[indexedBackup.fieldStandard]) {
        fieldStandard = indexedBackup.fieldStandard;
        localStorage.setItem("readroute-field-standard", fieldStandard);
      }
      showSaveSuccess("Playbook recovered from backup");
    }
  }
  renderMarkings();
  syncTabButtons();
  renderPlayControls();
  render();
  lastSavedSignature = "";
  persistPlaybook({ rotateBackup: false });
}

function applySharedPlaybook(snapshot) {
  if (!Array.isArray(snapshot?.formations) || !snapshot.formations.length
    || !Array.isArray(snapshot?.plays) || !snapshot.plays.length
    || !Array.isArray(snapshot?.defenses) || !snapshot.defenses.length) {
    return false;
  }
  try {
    localStorage.setItem(
      storageKeys.previousSnapshot,
      JSON.stringify(playbookSnapshot())
    );
  } catch (error) {
    console.warn("Could not preserve the pre-cloud recovery snapshot", error);
  }
  formations = snapshot.formations.map(formation => ({
    ...formation,
    labels: formation.labels || { X: "X", H: "H", Y: "Y", Z: "Z", RB: "RB" },
    offensePositions: normalizedOffensePositions(formation.offensePositions),
    notes: Array.isArray(formation.notes) ? formation.notes : []
  }));
  plays = snapshot.plays.map(normalizePlay);
  defenses = snapshot.defenses.map(normalizeDefense);
  libraryFolders = normalizeLibraryFolders(snapshot.libraryFolders);
  libraryAssignments = normalizeLibraryAssignments(snapshot.libraryAssignments);
  draftPlay = snapshot.draftPlay ? normalizePlay(snapshot.draftPlay) : null;
  selectedPlayId = plays.some(play => play.id === selectedPlayId)
    ? selectedPlayId
    : plays[0].id;
  selectedFormationId = formations.some(formation => formation.id === selectedFormationId)
    ? selectedFormationId
    : (currentPlay().formationId || formations[0].id);
  selectedDefenseId = defenses.some(defense => defense.id === selectedDefenseId)
    ? selectedDefenseId
    : defenses[0].id;
  if (fieldStandards[snapshot.fieldStandard]) {
    fieldStandard = snapshot.fieldStandard;
    localStorage.setItem("readroute-field-standard", fieldStandard);
  }
  lastSavedSignature = "";
  persistPlaybook({ rotateBackup: false });
  renderMarkings();
  renderPlayControls();
  render();
  return true;
}

window.ReadRouteCloud = {
  getSnapshot: () => playbookSnapshot(),
  getSavedAt: () => localStorage.getItem(storageKeys.savedAt) || "",
  applySnapshot: applySharedPlaybook,
  setAccessRole: role => {
    cloudAccessRole = ["owner", "editor", "viewer"].includes(role) ? role : "viewer";
    document.body.classList.toggle("workspace-viewer", cloudAccessRole === "viewer");
    if (cloudAccessRole === "viewer" && appTab === "create") {
      appTab = "playbook";
      syncTabButtons();
      render();
    }
  }
};

initializeApp();
